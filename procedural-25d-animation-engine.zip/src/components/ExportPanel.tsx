import { useEffect, useRef, useState } from "react";
import { FilmEngine, type EngineSettings } from "../engine/render";
import { SoundEngine, DEFAULT_MIX } from "../engine/audio";
import { FILM_DURATION, SHOTS, STYLE_PRESETS, formatTC } from "../engine/data";
import { Badge, Toggle } from "./ui";
import { Check, Download, Film, Loader2, Settings2, ShieldCheck, Waves, X } from "lucide-react";
import { cn } from "../utils/cn";

const RESOLUTIONS = [
  { id: "1080", label: "Full HD", dims: "1920 × 1080", w: 1920, h: 1080, note: "Delivery" },
  { id: "1440", label: "QHD", dims: "2560 × 1440", w: 2560, h: 1440, note: "Master" },
  { id: "2160", label: "4K UHD", dims: "3840 × 2160", w: 3840, h: 2160, note: "Archive" },
] as const;

const BITRATES = [
  { id: "web", label: "Web", mbps: 12, note: "small / fast" },
  { id: "high", label: "High", mbps: 28, note: "balanced" },
  { id: "master", label: "Master", mbps: 48, note: "highest quality" },
] as const;

type Resolution = (typeof RESOLUTIONS)[number]["id"];
type Bitrate = (typeof BITRATES)[number]["id"];
type Format = "webm" | "mp4";
type Status = "idle" | "rendering" | "encoding" | "complete" | "error";

interface Props {
  open: boolean;
  settings: EngineSettings;
  onClose: () => void;
  onOpenStyles: () => void;
}

export default function ExportPanel({ open, settings, onClose, onOpenStyles }: Props) {
  const [resolution, setResolution] = useState<Resolution>("1080");
  const [fps, setFps] = useState<30 | 60>(30);
  const [bitrate, setBitrate] = useState<Bitrate>("high");
  const [format, setFormat] = useState<Format>("webm");
  const [audio, setAudio] = useState(true);
  const [status, setStatus] = useState<Status>("idle");
  const [progress, setProgress] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");
  const [framesDone, setFramesDone] = useState(0);
  const previewRef = useRef<HTMLCanvasElement | null>(null);
  const previewEngine = useRef<FilmEngine | null>(null);
  const rafRef = useRef(0);
  const stopRef = useRef<(() => void) | null>(null);
  const res = RESOLUTIONS.find((r) => r.id === resolution)!;
  const rate = BITRATES.find((b) => b.id === bitrate)!;
  const style = STYLE_PRESETS.find((s) => s.id === settings.styleId) ?? STYLE_PRESETS[0];

  useEffect(() => {
    if (!open) return;
    const canvas = previewRef.current;
    if (!canvas) return;
    if (!previewEngine.current) previewEngine.current = new FilmEngine();
    const ctx = canvas.getContext("2d");
    if (ctx) previewEngine.current.render(ctx, canvas.width, canvas.height, 6.55, settings);
  }, [open, settings]);

  useEffect(() => {
    if (!open) {
      cancelAnimationFrame(rafRef.current);
      stopRef.current?.();
    }
  }, [open]);

  if (!open) return null;

  const pickMime = (): string => {
    const candidates =
      format === "mp4"
        ? ["video/mp4;codecs=h264,aac", "video/mp4;codecs=avc1", "video/mp4", "video/webm;codecs=vp9,opus", "video/webm"]
        : ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
    return candidates.find((type) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(type)) ?? "";
  };

  const startRender = async () => {
    if (status === "rendering" || status === "encoding") return;
    setError("");
    setDownloadUrl(null);
    setStatus("rendering");
    setProgress(0);
    setFramesDone(0);
    const canvas = document.createElement("canvas");
    canvas.width = res.w;
    canvas.height = res.h;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) {
      setStatus("error");
      setError("Canvas context unavailable.");
      return;
    }
    const engine = new FilmEngine();
    const mime = pickMime();
    if (!mime) {
      setStatus("error");
      setError("This browser cannot encode the selected format. Try WebM.");
      return;
    }
    // Render the first frame before capture so the stream starts with real pixels.
    engine.render(ctx, canvas.width, canvas.height, 0, settings);
    const videoStream = canvas.captureStream(fps);
    let sound: SoundEngine | null = null;
    let audioStream: MediaStream | null = null;
    if (audio) {
      sound = new SoundEngine();
      await sound.startAt(0, { ...DEFAULT_MIX, muted: false, master: 0.9 });
      audioStream = sound.configureStream();
    }
    const tracks: MediaStreamTrack[] = [...videoStream.getVideoTracks()];
    if (audioStream) tracks.push(...audioStream.getAudioTracks());
    const stream = new MediaStream(tracks);
    const chunks: Blob[] = [];
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(stream, {
        mimeType: mime,
        videoBitsPerSecond: rate.mbps * 1_000_000,
        audioBitsPerSecond: 160_000,
      });
    } catch {
      setStatus("error");
      setError("MediaRecorder could not start with these settings.");
      sound?.stop();
      return;
    }
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunks.push(event.data);
    };
    recorder.onstop = () => {
      const type = mime.includes("mp4") ? "video/mp4" : "video/webm";
      const blob = new Blob(chunks, { type });
      const url = URL.createObjectURL(blob);
      const ext = type.includes("mp4") ? "mp4" : "webm";
      const name = `the-last-15-seconds_${res.w}x${res.h}_${fps}fps.${ext}`;
      setDownloadUrl(url);
      setFileName(name);
      setStatus("complete");
      setProgress(100);
      sound?.stop();
      videoStream.getTracks().forEach((track) => track.stop());
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = name;
      anchor.click();
    };
    recorder.start(250);
    const start = performance.now();
    stopRef.current = () => {
      cancelAnimationFrame(rafRef.current);
      if (recorder.state !== "inactive") recorder.stop();
      sound?.stop();
    };
    const tick = () => {
      const elapsed = (performance.now() - start) / 1000;
      const t = Math.min(FILM_DURATION, elapsed);
      engine.render(ctx, canvas.width, canvas.height, t, settings);
      setProgress(Math.min(100, (t / FILM_DURATION) * 100));
      setFramesDone(Math.floor(t * fps));
      if (t >= FILM_DURATION) {
        setStatus("encoding");
        window.setTimeout(() => {
          if (recorder.state !== "inactive") recorder.stop();
        }, 140);
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  };

  const estimated = ((rate.mbps * FILM_DURATION) / 8).toFixed(1);
  const isBusy = status === "rendering" || status === "encoding";
  const browserMime = pickMime();
  const actualFormat = browserMime.includes("mp4") ? "MP4" : "WebM";

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/75 px-4 py-[5vh] backdrop-blur-[6px]">
      <div className="slide-up w-full max-w-[920px] overflow-hidden rounded-xl border border-white/10 bg-[#0b0d10] shadow-[0_40px_120px_rgba(0,0,0,0.7)]">
        <header className="flex items-start justify-between gap-4 border-b border-white/[0.07] px-5 py-4">
          <div>
            <div className="mb-1.5 flex items-center gap-2">
              <Badge color="signal" dot>
                Final render
              </Badge>
              <span className="mono text-[8px] tracking-[0.12em] text-white/30 uppercase">Engine-native capture · no screen recording</span>
            </div>
            <h2 className="text-[22px] leading-tight font-semibold tracking-[-0.02em] text-[#efeae0]">Export the film.</h2>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onOpenStyles} className="btn hidden border border-white/10 px-2.5 py-1.5 text-[9.5px] text-[#a9abb1] hover:bg-white/[0.04] sm:inline-flex">
              <Settings2 size={12} /> Style
            </button>
            <button onClick={onClose} aria-label="Close export" className="rounded-md border border-white/10 p-2 text-[#8b8e94] hover:text-white">
              <X size={15} />
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_330px]">
          <div className="space-y-5 border-b border-white/[0.07] p-5 lg:border-r lg:border-b-0">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow text-[#a5a7ad]">Resolution</span>
                <span className="mono text-[7.5px] tracking-[0.1em] text-white/25 uppercase">Output independent of preview</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {RESOLUTIONS.map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setResolution(option.id)}
                    className={cn(
                      "rounded-md border p-2.5 text-left transition-colors",
                      resolution === option.id ? "border-[#ff6a3d]/55 bg-[#ff6a3d]/[0.07]" : "border-white/[0.08] bg-white/[0.02] hover:border-white/20"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-medium text-[#e5e0d6]">{option.label}</span>
                      {resolution === option.id && <Check size={10} className="text-[#ff8a62]" />}
                    </div>
                    <div className="mono mt-1 text-[8px] tracking-[0.02em] text-[#85888f]">{option.dims}</div>
                    <div className="mono mt-1.5 text-[7px] tracking-[0.1em] text-white/25 uppercase">{option.note}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-5">
              <div>
                <span className="eyebrow mb-2 block text-[#a5a7ad]">Frame rate</span>
                <div className="grid grid-cols-2 gap-2">
                  {[30, 60].map((value) => (
                    <button
                      key={value}
                      onClick={() => setFps(value as 30 | 60)}
                      className={cn(
                        "mono rounded-md border py-2 text-[9px] tracking-[0.08em] transition-colors",
                        fps === value ? "border-[#ff6a3d]/55 bg-[#ff6a3d]/[0.07] text-[#ffb49c]" : "border-white/[0.08] text-[#85888f] hover:border-white/20"
                      )}
                    >
                      {value} FPS
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <span className="eyebrow mb-2 block text-[#a5a7ad]">Format</span>
                <div className="grid grid-cols-2 gap-2">
                  {(["webm", "mp4"] as Format[]).map((value) => (
                    <button
                      key={value}
                      onClick={() => setFormat(value)}
                      className={cn(
                        "mono rounded-md border py-2 text-[9px] tracking-[0.08em] uppercase transition-colors",
                        format === value ? "border-[#ff6a3d]/55 bg-[#ff6a3d]/[0.07] text-[#ffb49c]" : "border-white/[0.08] text-[#85888f] hover:border-white/20"
                      )}
                    >
                      {value}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow text-[#a5a7ad]">Bitrate</span>
                <span className="mono text-[8px] text-white/30">{rate.mbps} Mbps · est. {estimated} MB</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {BITRATES.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setBitrate(option.id)}
                    className={cn(
                      "rounded-md border px-2.5 py-2 text-left transition-colors",
                      bitrate === option.id ? "border-[#ff6a3d]/55 bg-[#ff6a3d]/[0.07]" : "border-white/[0.08] bg-white/[0.02] hover:border-white/20"
                    )}
                  >
                    <span className="block text-[10.5px] font-medium text-[#e5e0d6]">{option.label}</span>
                    <span className="mono mt-0.5 block text-[7px] tracking-[0.06em] text-white/30 uppercase">{option.note}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-md border border-white/[0.07] bg-white/[0.018] px-3 py-2">
              <Toggle label="Include procedural sound design" checked={audio} onChange={setAudio} hint="Non-vocal score, ambience and Foley only" />
              <div className="mt-1 flex items-center gap-1.5 border-t border-white/[0.05] pt-2">
                <ShieldCheck size={10} className="text-[#8fa8a2]" />
                <span className="mono text-[7.5px] leading-relaxed tracking-[0.04em] text-white/30 uppercase">
                  Subtitles burned in · camera radar & editor UI excluded
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "Story duration", value: "15.00 s", icon: Film },
                { label: "Timeline", value: `${SHOTS.length} cuts`, icon: SparkIcon },
                { label: "Frames", value: `${Math.round(FILM_DURATION * fps)}`, icon: Waves },
              ].map((item) => (
                <div key={item.label} className="rounded-md border border-white/[0.07] bg-[#0a0c0f] px-2.5 py-2">
                  <span className="mono block text-[6.5px] tracking-[0.1em] text-white/25 uppercase">{item.label}</span>
                  <span className="mono mt-1 block text-[10px] text-[#ddd8cd]">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <aside className="flex flex-col gap-3.5 bg-black/20 p-5">
            <div className="overflow-hidden rounded-md border border-white/[0.08]">
              <canvas ref={previewRef} width={420} height={236} className="block w-full bg-black" />
              <div className="flex items-center justify-between border-t border-white/[0.06] bg-black/30 px-2.5 py-1.5">
                <span className="mono text-[7.5px] tracking-[0.08em] text-white/40 uppercase">Look frame · 06.55s</span>
                <Badge color="mint">{style.name}</Badge>
              </div>
            </div>

            <div className="rounded-md border border-white/[0.07] bg-[#0a0c0f] p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow">Render manifest</span>
                <span className="mono text-[7px] tracking-[0.08em] text-[#a7c4a0] uppercase">Ready</span>
              </div>
              {[
                ["Project", "The Last 15 Seconds"],
                ["Picture", `${res.dims} · ${actualFormat}`],
                ["Frame rate", `${fps} fps · deterministic loop`],
                ["Color", `${settings.mood ?? "Auto"} grade · ${style.tag.toLowerCase()}`],
                ["Audio", audio ? "Procedural mix · non-vocal" : "Muted"],
                ["In point", formatTC(0, fps)],
                ["Out point", formatTC(15, fps)],
              ].map(([k, v]) => (
                <div key={k} className="flex items-start justify-between gap-3 border-b border-white/[0.04] py-1.5 last:border-0">
                  <span className="mono text-[7.5px] tracking-[0.08em] text-white/30 uppercase">{k}</span>
                  <span className="mono text-right text-[8px] leading-[1.4] text-[#c6c1b7]">{v}</span>
                </div>
              ))}
            </div>

            {status === "rendering" || status === "encoding" ? (
              <div className="mt-auto rounded-md border border-[#ff6a3d]/25 bg-[#ff6a3d]/[0.06] p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="mono flex items-center gap-1.5 text-[8px] tracking-[0.1em] text-[#ffb49c] uppercase">
                    <Loader2 size={10} className="spin-slow" />
                    {status === "rendering" ? "Capturing engine frames" : "Muxing + encoding"}
                  </span>
                  <span className="mono text-[9px] text-[#ffd7c8]">{progress.toFixed(0)}%</span>
                </div>
                <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-[#ff6a3d] transition-[width]" style={{ width: `${progress}%` }} />
                </div>
                <div className="mono mt-2 flex justify-between text-[7px] tracking-[0.04em] text-white/35 uppercase">
                  <span>{framesDone} / {Math.round(FILM_DURATION * fps)} frames</span>
                  <span>{formatTC(Math.min(FILM_DURATION, (progress / 100) * FILM_DURATION), fps)}</span>
                </div>
              </div>
            ) : status === "complete" && downloadUrl ? (
              <div className="mt-auto rounded-md border border-[#a7c4a0]/25 bg-[#a7c4a0]/[0.06] p-3">
                <div className="flex items-center gap-1.5 text-[10px] font-medium text-[#c0dab8]">
                  <Check size={12} /> Render complete
                </div>
                <p className="mt-1 truncate text-[9px] text-[#9aa39a]">{fileName}</p>
                <a
                  href={downloadUrl}
                  download={fileName}
                  className="btn mt-2 w-full border border-[#a7c4a0]/30 bg-[#a7c4a0]/10 py-2 text-[9.5px] text-[#c4dabf] hover:bg-[#a7c4a0]/20"
                >
                  <Download size={11} /> Download again
                </a>
              </div>
            ) : status === "error" ? (
              <div className="mt-auto rounded-md border border-[#d4574b]/30 bg-[#d4574b]/[0.08] p-3 text-[9.5px] leading-relaxed text-[#e0a399]">{error}</div>
            ) : (
              <div className="mt-auto">
                <p className="mono mb-2 text-[7.5px] leading-[1.7] tracking-[0.03em] text-white/30 uppercase">
                  Export is captured directly from the film engine at {res.dims}, independent of the preview window. {format === "mp4" && actualFormat === "WebM" ? "MP4 encoding is unavailable here — WebM will be delivered." : "Your browser will deliver " + actualFormat + "."}
                </p>
              </div>
            )}

            <button
              type="button"
              disabled={isBusy}
              onClick={startRender}
              className={cn(
                "btn w-full py-2.5 text-[11px] font-semibold",
                isBusy ? "cursor-not-allowed bg-[#3a2721] text-[#a8887e]" : "bg-[#ff6a3d] text-[#160b07] hover:bg-[#ff7d55]"
              )}
            >
              {isBusy ? <Loader2 size={12} className="spin-slow" /> : <Download size={12} />}
              {isBusy ? "Rendering…" : `Render ${res.w} × ${res.h} · ${actualFormat}`}
            </button>
          </aside>
        </div>
      </div>
    </div>
  );
}

function SparkIcon({ size = 12, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}>
      <path d="M3 7h18M3 12h12M3 17h18" />
      <circle cx="19" cy="12" r="2" />
    </svg>
  );
}
