import CameraRadar from "./CameraRadar";
import { MOODS, type MoodId, type Shot } from "../engine/data";
import type { EngineSettings, Telemetry } from "../engine/render";
import { Badge, Divider, Slider, Toggle } from "./ui";
import { Camera, Crosshair, Eye, Gauge, Move3d, Palette, Radio, RotateCcw, Sparkles, Sun, Wind } from "lucide-react";
import { cn } from "../utils/cn";

interface Props {
  settings: EngineSettings;
  telemetry: Telemetry;
  shot: Shot;
  time: number;
  onCameraChange: (patch: Partial<EngineSettings["camera"]>) => void;
  onGradeChange: (patch: Partial<EngineSettings["grade"]>) => void;
  onFxChange: (patch: Partial<EngineSettings["fx"]>) => void;
  onCustomChange: (patch: Partial<EngineSettings["custom"]>) => void;
  onMood: (mood: MoodId | null) => void;
  onResetCamera: () => void;
}

function Group({
  title,
  icon,
  right,
  children,
}: {
  title: string;
  icon?: React.ReactNode;
  right?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-[10px] border border-white/[0.08] bg-[#0d0f12]">
      <header className="flex items-center justify-between border-b border-white/[0.06] px-3 py-2">
        <div className="flex items-center gap-1.5 text-[#a5a7ad]">
          {icon}
          <span className="eyebrow text-[#a5a7ad]">{title}</span>
        </div>
        {right}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

function Readout({ label, value, unit, accent }: { label: string; value: string; unit?: string; accent?: boolean }) {
  return (
    <div className="rounded-[4px] border border-white/[0.06] bg-black/25 px-1.5 py-1">
      <span className="mono block text-[6px] tracking-[0.1em] text-white/25 uppercase">{label}</span>
      <span className={cn("mono mt-0.5 block text-[9px] leading-none tracking-[0.02em]", accent ? "text-[#ffb49c]" : "text-[#d8d3c9]")}>
        {value}
        {unit && <span className="ml-0.5 text-[6px] text-white/25">{unit}</span>}
      </span>
    </div>
  );
}

function CameraPath({ shot, progress }: { shot: Shot; progress: number }) {
  const w = 268;
  const h = 48;
  const points = shot.camera.map((key, i) => {
    const x = 6 + key.at * (w - 12);
    const y = h / 2 - key.pitch * 0.55 - (key.x + key.y) * 2.2 - i * 1.5;
    return [x, Math.max(6, Math.min(h - 6, y))] as [number, number];
  });
  const d = points.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const markers = shot.camera.map((key) => ({
    x: 6 + key.at * (w - 12),
    at: key.at,
  }));
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} className="mt-1 block overflow-visible">
      <defs>
        <linearGradient id="cam-path" x1="0" x2="1">
          <stop offset="0" stopColor="#ff6a3d" stopOpacity="0.2" />
          <stop offset="1" stopColor="#ff6a3d" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      {[12, 24, 36].map((y) => (
        <line key={y} x1="0" x2={w} y1={y} y2={y} stroke="rgba(255,255,255,0.05)" strokeDasharray="2 4" />
      ))}
      <path d={d} fill="none" stroke="url(#cam-path)" strokeWidth="1.6" />
      {markers.map((m, i) => (
        <circle key={i} cx={m.x} cy={points[i][1]} r="2" fill={m.at <= progress ? "#ff6a3d" : "#5b5e64"} />
      ))}
      <circle cx={6 + Math.min(1, progress) * (w - 12)} cy={points[Math.min(points.length - 1, Math.round(progress * (points.length - 1)))][1]} r="3.4" fill="#f0e7d7" stroke="#ff6a3d" strokeWidth="1.4" />
    </svg>
  );
}

export default function RightRail({
  settings,
  telemetry,
  shot,
  time,
  onCameraChange,
  onGradeChange,
  onFxChange,
  onCustomChange,
  onMood,
  onResetCamera,
}: Props) {
  const cam = telemetry.camera;
  const progress = Math.max(0, Math.min(1, (time - shot.start) / (shot.end - shot.start)));
  const mood = settings.mood ?? shot.mood;

  return (
    <aside className="flex h-full min-h-0 flex-col gap-2 overflow-y-auto border-l border-white/[0.06] bg-[#090b0d] p-2.5 pl-2 scroll-thin">
      {/* radar */}
      <section className="overflow-hidden rounded-[10px] border border-white/[0.08] bg-[#0d0f12]">
        <header className="flex items-center justify-between border-b border-white/[0.06] px-3 py-2">
          <div className="flex items-center gap-1.5">
            <Radio size={11} className="text-[#ff8a62]" />
            <span className="eyebrow text-[#a5a7ad]">Camera radar</span>
          </div>
          <span className="mono flex items-center gap-1 text-[7px] tracking-[0.1em] text-[#a7c4a0] uppercase">
            <span className="h-1 w-1 animate-pulse rounded-full bg-[#a7c4a0]" /> Live
          </span>
        </header>
        <div className="dotgrid relative h-[152px] w-full border-b border-white/[0.05] bg-[#0a0c0f]">
          <CameraRadar telemetry={telemetry} className="absolute inset-0" />
        </div>
        <div className="grid grid-cols-3 gap-1 border-b border-white/[0.05] p-2">
          <Readout label="Cam · X" value={cam.x >= 0 ? `+${cam.x.toFixed(2)}` : cam.x.toFixed(2)} unit="m" />
          <Readout label="Cam · Y" value={cam.y >= 0 ? `+${cam.y.toFixed(2)}` : cam.y.toFixed(2)} unit="m" accent />
          <Readout label="Cam · Z" value={`${cam.z.toFixed(2)}`} unit="m" />
        </div>
        <div className="grid grid-cols-4 gap-1 px-2 py-2">
          <Readout label="Yaw" value={`${cam.yaw.toFixed(0)}°`} />
          <Readout label="Pitch" value={`${cam.pitch.toFixed(0)}°`} />
          <Readout label="Roll" value={`${cam.roll.toFixed(0)}°`} />
          <Readout label="FOV" value={`${cam.fov.toFixed(0)}°`} />
        </div>
        <div className="space-y-1 px-2 pb-2">
          {telemetry.layerBands.map((band) => (
            <div key={band.name} className="flex items-center gap-1.5">
              <span className="mono w-[62px] text-[6px] tracking-[0.08em]" style={{ color: band.color }}>
                {band.name}
              </span>
              <span className="relative h-[3px] flex-1 rounded-full bg-white/[0.06]">
                <span className="absolute top-0 h-full rounded-full" style={{ background: band.color, width: `${(band.z / 12) * 100}%`, opacity: 0.7 }} />
              </span>
              <span className="mono w-[34px] text-right text-[6px] text-white/30">z {band.z.toFixed(1)}</span>
            </div>
          ))}
        </div>
        <footer className="flex items-center justify-between border-t border-white/[0.05] px-2.5 py-1.5">
          <span className="mono flex items-center gap-1 text-[6.5px] tracking-[0.06em] text-white/25 uppercase">
            <Eye size={8} /> Radar excluded from export
          </span>
          <button
            type="button"
            onClick={() => onCameraChange({ auto: !settings.camera.auto })}
            className={cn(
              "mono rounded-[3px] border px-1.5 py-0.5 text-[6.5px] tracking-[0.08em] uppercase",
              settings.camera.auto ? "border-[#ff6a3d]/30 bg-[#ff6a3d]/10 text-[#ffb49c]" : "border-white/15 text-white/50"
            )}
          >
            {settings.camera.auto ? "Auto" : "Manual"}
          </button>
        </footer>
      </section>

      {/* camera */}
      <Group
        title="Camera"
        icon={<Camera size={11} className="text-[#9fc8cf]" />}
        right={
          <button onClick={onResetCamera} className="mono flex items-center gap-1 text-[6.5px] tracking-[0.08em] text-white/30 uppercase hover:text-white/70">
            <RotateCcw size={8} /> Reset
          </button>
        }
      >
        <div className="mb-2 flex items-center gap-1 rounded border border-white/[0.07] bg-black/20 p-0.5">
          {[
            { id: true, label: "Auto-direct" },
            { id: false, label: "Manual rig" },
          ].map((mode) => (
            <button
              key={String(mode.id)}
              onClick={() => onCameraChange({ auto: mode.id })}
              className={cn(
                "mono flex-1 rounded-[3px] py-1 text-[7.5px] tracking-[0.08em] uppercase transition-colors",
                settings.camera.auto === mode.id ? "bg-white/[0.09] text-[#efeae0]" : "text-white/30 hover:text-white/60"
              )}
            >
              {mode.label}
            </button>
          ))}
        </div>
        <div className="mb-2 rounded border border-white/[0.06] bg-black/20 px-2 py-1.5">
          <div className="mb-0.5 flex items-center justify-between">
            <span className="mono text-[6.5px] tracking-[0.08em] text-white/30 uppercase">Story camera path</span>
            <span className="mono text-[6.5px] text-[#ffb49c]">
              {shot.focus} · {shot.camera.length} keys
            </span>
          </div>
          <CameraPath shot={shot} progress={progress} />
        </div>
        {settings.camera.auto ? (
          <div className="space-y-2.5">
            <div className="grid grid-cols-3 gap-1">
              <Readout label="Move" value={`${(progress * 100).toFixed(0)}%`} />
              <Readout label="Mode" value={shot.motion ? "track" : shot.focus === "close" ? "push" : "dolly"} />
              <Readout label="Aperture" value={`f/2.${(1 + Math.round(cam.fov / 12)).toString().padStart(2, "0")}`} />
            </div>
            <Slider label="Dolly speed" value={settings.camera.speed} min={0.4} max={1.8} step={0.01} onChange={(v) => onCameraChange({ speed: v })} suffix="×" icon={<Gauge size={10} />} />
            <Slider label="Camera shake" value={settings.camera.shake} min={0} max={1} step={0.01} onChange={(v) => onCameraChange({ shake: v })} icon={<Move3d size={10} />} />
            <Slider label="FOV" value={settings.camera.fov} min={24} max={80} step={1} onChange={(v) => onCameraChange({ fov: v })} suffix="°" icon={<Crosshair size={10} />} />
            <p className="mono text-[6.5px] leading-[1.6] tracking-[0.03em] text-white/20 uppercase">
              Auto-direct reads the story beat. Manual overrides apply to every shot.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-x-3 gap-y-2">
            <Slider label="Cam X" value={settings.camera.x} min={-6} max={6} step={0.1} onChange={(v) => onCameraChange({ x: v })} />
            <Slider label="Cam Y" value={settings.camera.y} min={-4} max={4} step={0.1} onChange={(v) => onCameraChange({ y: v })} />
            <Slider label="Dolly Z" value={settings.camera.z} min={0} max={10} step={0.1} onChange={(v) => onCameraChange({ z: v })} />
            <Slider label="Yaw" value={settings.camera.yaw} min={-40} max={40} step={1} onChange={(v) => onCameraChange({ yaw: v })} suffix="°" />
            <Slider label="Pitch" value={settings.camera.pitch} min={-45} max={30} step={1} onChange={(v) => onCameraChange({ pitch: v })} suffix="°" />
            <Slider label="FOV" value={settings.camera.fov} min={24} max={80} step={1} onChange={(v) => onCameraChange({ fov: v })} suffix="°" />
            <div className="col-span-2">
              <Slider label="Shake" value={settings.camera.shake} min={0} max={1} step={0.01} onChange={(v) => onCameraChange({ shake: v })} />
            </div>
          </div>
        )}
      </Group>

      {/* grade */}
      <Group
        title="Color grade"
        icon={<Palette size={11} className="text-[#c6a380]" />}
        right={<Badge color="signal">Story-aware</Badge>}
      >
        <div className="mb-2 grid grid-cols-4 gap-1">
          <button
            onClick={() => onMood(null)}
            className={cn(
              "mono col-span-1 rounded-[3px] border px-1 py-1 text-[6.5px] tracking-[0.05em] uppercase",
              settings.mood === null ? "border-[#ff6a3d]/50 bg-[#ff6a3d]/10 text-[#ffb49c]" : "border-white/10 text-white/35 hover:text-white/70"
            )}
          >
            Auto
          </button>
          {MOODS.slice(0, 3).map((m) => (
            <button
              key={m.id}
              onClick={() => onMood(m.id)}
              className={cn(
                "mono rounded-[3px] border px-1 py-1 text-[6.5px] tracking-[0.05em] uppercase",
                mood === m.id ? "border-white/25 bg-white/[0.07] text-[#eee8dd]" : "border-white/10 text-white/35 hover:text-white/70"
              )}
            >
              {m.name.slice(0, 7)}
            </button>
          ))}
        </div>
        <div className="mb-2 flex flex-wrap gap-1">
          {MOODS.slice(3).map((m) => (
            <button
              key={m.id}
              onClick={() => onMood(m.id)}
              className={cn(
                "mono flex items-center gap-1 rounded-full border px-1.5 py-[2px] text-[6.5px] tracking-[0.05em] uppercase",
                mood === m.id ? "border-white/25 bg-white/[0.07] text-[#eee8dd]" : "border-white/10 text-white/35 hover:text-white/70"
              )}
            >
              <span className="h-1 w-1 rounded-full" style={{ background: m.tint }} />
              {m.name}
            </button>
          ))}
        </div>
        <div className="mb-2.5 flex items-center justify-between rounded border border-white/[0.06] bg-black/20 px-2 py-1.5">
          <span className="mono text-[6.5px] tracking-[0.08em] text-white/30 uppercase">Scene temperature</span>
          <div className="flex items-center gap-1.5">
            <span className="mono text-[7px] text-[#7fa4b8]">COLD</span>
            <span className="relative h-[3px] w-16 rounded-full bg-gradient-to-r from-[#6b9ab8] via-[#d9cbb4] to-[#f08a54]">
              <span className="absolute top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black/40 bg-white" style={{ left: `${((settings.grade.temperature + 1) / 2) * 100}%` }} />
            </span>
            <span className="mono text-[7px] text-[#e5a77d]">WARM</span>
          </div>
        </div>
        <div className="space-y-2">
          <Slider label="Saturation" value={settings.grade.saturation} min={0} max={1.6} step={0.01} onChange={(v) => onGradeChange({ saturation: v })} />
          <Slider label="Contrast" value={settings.grade.contrast} min={0.6} max={1.6} step={0.01} onChange={(v) => onGradeChange({ contrast: v })} />
          <Slider label="Brightness" value={settings.grade.brightness} min={0.6} max={1.3} step={0.01} onChange={(v) => onGradeChange({ brightness: v })} />
          <Slider label="Temperature" value={settings.grade.temperature} min={-1} max={1} step={0.01} onChange={(v) => onGradeChange({ temperature: v })} />
        </div>
        <div className="mt-2.5 flex items-center justify-between border-t border-white/[0.06] pt-2">
          <span className="mono text-[6.5px] tracking-[0.08em] text-white/30 uppercase">Lift / tint</span>
          <div className="flex items-center gap-1">
            {["#ff6a3d", "#e04a3a", "#8f7ad6", "#6e8faa", "#a8c0a2", "#f0b45c"].map((color) => (
              <button
                key={color}
                onClick={() => onGradeChange({ tint: color })}
                aria-label={`Tint ${color}`}
                className={cn("h-3 w-3 rounded-full border transition-transform hover:scale-110", settings.grade.tint === color ? "border-white" : "border-black/40")}
                style={{ background: color }}
              />
            ))}
          </div>
        </div>
      </Group>

      {/* light + fx */}
      <Group title="Light & atmosphere" icon={<Sun size={11} className="text-[#e5b578]" />} right={<span className="mono text-[6.5px] tracking-[0.08em] text-white/25 uppercase">HDR</span>}>
        <div className="space-y-2">
          <Slider label="Bloom threshold" value={settings.fx.bloom} min={0} max={1} step={0.01} onChange={(v) => onFxChange({ bloom: v })} icon={<Sparkles size={10} />} />
          <Slider label="Global exposure" value={settings.fx.light} min={0.4} max={1.6} step={0.01} onChange={(v) => onFxChange({ light: v })} />
        </div>
        <Divider className="my-2.5" />
        <div className="grid grid-cols-2 gap-x-3">
          <Toggle label="Sun rays" checked={settings.fx.rays} onChange={(v) => onFxChange({ rays: v })} />
          <Toggle label="Fog / haze" checked={settings.fx.fog} onChange={(v) => onFxChange({ fog: v })} />
          <Toggle label="Rain" checked={settings.fx.rain} onChange={(v) => onFxChange({ rain: v })} />
          <Toggle label="Particles" checked={settings.fx.particles} onChange={(v) => onFxChange({ particles: v })} />
          <Toggle label="Shadows" checked={settings.fx.shadows} onChange={(v) => onFxChange({ shadows: v })} />
          <Toggle label="3D props" checked={settings.fx.threeD} onChange={(v) => onFxChange({ threeD: v })} />
          <Toggle label="Grain" checked={settings.fx.grain} onChange={(v) => onFxChange({ grain: v })} />
          <Toggle label="Letterbox" checked={settings.fx.letterbox} onChange={(v) => onFxChange({ letterbox: v })} />
          <Toggle label="Subtitles" checked={settings.fx.subtitles} onChange={(v) => onFxChange({ subtitles: v })} />
          <Toggle label="Whip FX" checked={settings.fx.speedFx} onChange={(v) => onFxChange({ speedFx: v })} />
        </div>
      </Group>

      {/* wobble */}
      <Group title="Character & environment sway" icon={<Wind size={11} className="text-[#a8c3bd]" />} right={<span className="mono text-[6.5px] text-white/25">{Math.round(settings.custom.wobble * 100)}%</span>}>
        <div className="space-y-2">
          <Slider label="Body / limb wobble" value={settings.custom.wobble} min={0} max={1.3} step={0.01} onChange={(v) => onCustomChange({ wobble: v })} />
          <Slider label="Vegetation / prop sway" value={settings.custom.envWobble} min={0} max={1.3} step={0.01} onChange={(v) => onCustomChange({ envWobble: v })} />
          <Slider label="Wobble frequency" value={settings.custom.wobbleSpeed} min={0.3} max={2} step={0.01} onChange={(v) => onCustomChange({ wobbleSpeed: v })} suffix="h" />
        </div>
        <div className="mono mt-2 flex items-center gap-1.5 text-[6px] leading-tight tracking-[0.04em] text-white/20 uppercase">
          <Eye size={7} /> Proportions locked · secondary motion only
        </div>
      </Group>

      <div className="mono flex items-center justify-between px-1 py-1 text-[6px] tracking-[0.1em] text-white/20 uppercase">
        <span>{telemetry.shotId} / 29</span>
        <span>{telemetry.crop}</span>
      </div>
    </aside>
  );
}
