import { useEffect, useRef } from "react";
import { FilmEngine, type EngineSettings, type Telemetry } from "../engine/render";
import { formatTC, shotAt, STYLE_PRESETS } from "../engine/data";

interface StageProps {
  engine: FilmEngine;
  timeRef: React.MutableRefObject<number>;
  playing: boolean;
  settings: EngineSettings;
  time: number;
  onTelemetry?: (telemetry: Telemetry) => void;
}

export default function Stage({ engine, timeRef, playing, settings, time, onTelemetry }: StageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const settingsRef = useRef(settings);
  const shot = shotAt(time);
  const style = STYLE_PRESETS.find((s) => s.id === settings.styleId) ?? STYLE_PRESETS[0];

  settingsRef.current = settings;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let raf = 0;
    let lastTelemetry = 0;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(320, Math.round(rect.width * dpr));
      const height = Math.max(180, Math.round(rect.height * dpr));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
    };
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();
    const loop = (now: number) => {
      const ctx = canvas.getContext("2d");
      if (ctx) engine.render(ctx, canvas.width, canvas.height, timeRef.current, settingsRef.current);
      if (onTelemetry && now - lastTelemetry > 220) {
        lastTelemetry = now;
        onTelemetry(engine.telemetryAt(timeRef.current, settingsRef.current));
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [engine, timeRef, onTelemetry]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#050607]">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-label="2.5D film viewport" />
      <div className="grain-overlay opacity-[0.13]" />
      {/* viewport vignette + crop marks */}
      <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-white/[0.06]">
        <span className="absolute left-3 top-3 h-3 w-3 border-l border-t border-white/25" />
        <span className="absolute right-3 top-3 h-3 w-3 border-r border-t border-white/25" />
        <span className="absolute bottom-3 left-3 h-3 w-3 border-b border-l border-white/25" />
        <span className="absolute bottom-3 right-3 h-3 w-3 border-b border-r border-white/25" />
      </div>
      {/* top HUD */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-4">
        <div className="flex items-center gap-2.5">
          <span className="mono flex items-center gap-1.5 rounded-[3px] border border-[#ff6a3d]/30 bg-black/45 px-1.5 py-1 text-[8.5px] tracking-[0.12em] text-[#ff9a76] uppercase backdrop-blur-sm">
            <span className="rec-dot h-1.5 w-1.5 rounded-full bg-[#ff5a3d]" />
            {playing ? "Live preview" : "Paused"}
          </span>
          <span className="mono rounded-[3px] border border-white/10 bg-black/40 px-1.5 py-1 text-[8.5px] tracking-[0.08em] text-[#d7d2c7] backdrop-blur-sm">
            {formatTC(time, 30)}
          </span>
          <span className="mono hidden px-1 text-[8.5px] tracking-[0.1em] text-white/40 uppercase sm:inline">{shot.id}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="mono rounded-[3px] border border-white/10 bg-black/40 px-1.5 py-1 text-[8.5px] tracking-[0.08em] text-[#c8c4ba] uppercase backdrop-blur-sm">
            2.5D · {style.name}
          </span>
          <span className="mono rounded-[3px] border border-[#a7c4a0]/25 bg-[#a7c4a0]/10 px-1.5 py-1 text-[8.5px] tracking-[0.08em] text-[#bad7b1] uppercase backdrop-blur-sm">
            Auto camera
          </span>
        </div>
      </div>
      {/* bottom HUD */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
        <div className="mono flex items-center gap-2 rounded-[3px] border border-white/10 bg-black/35 px-2 py-1 text-[8px] tracking-[0.08em] text-white/45 uppercase backdrop-blur-sm">
          <span>{shot.scene}</span>
          <span className="text-white/20">/</span>
          <span>{shot.title}</span>
        </div>
        <div className="mono flex items-center gap-2 rounded-[3px] border border-white/10 bg-black/35 px-2 py-1 text-[8px] tracking-[0.08em] text-white/40 uppercase backdrop-blur-sm">
          <span>1920 × 1080</span>
          <span className="text-white/20">·</span>
          <span>30 fp</span>
          <span className="text-white/20">·</span>
          <span>Procedural</span>
        </div>
      </div>
      {!playing && time < 0.04 && (
        <div className="pointer-events-none absolute inset-x-0 top-[62%] flex justify-center">
          <div className="mono flex items-center gap-2 rounded-full border border-white/15 bg-black/50 px-3 py-1.5 text-[9px] tracking-[0.14em] text-white/70 uppercase backdrop-blur">
            <span className="h-1 w-1 rounded-full bg-[#ff6a3d]" /> Press space to roll film
          </div>
        </div>
      )}
    </div>
  );
}
