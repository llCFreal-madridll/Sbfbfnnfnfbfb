import { useEffect, useRef } from "react";
import { FilmEngine, type EngineSettings } from "../engine/render";
import {
  AUDIO_CUES,
  CAST,
  SHOTS,
  STORY_BEATS,
  STYLE_PRESETS,
  type AudioCue,
  type CueCategory,
} from "../engine/data";
import type { MixSettings } from "../engine/audio";
import { Badge, Slider, Toggle } from "./ui";
import { AudioLines, Clock, Layers, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import { cn } from "../utils/cn";

let thumbEngine: FilmEngine | null = null;
function getThumbEngine() {
  if (!thumbEngine) thumbEngine = new FilmEngine();
  return thumbEngine;
}

function ShotThumbnail({ index, settings }: { index: number; settings: EngineSettings }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const shot = SHOTS[index];
    const t = shot.start + (shot.end - shot.start) * 0.55;
    const id = requestAnimationFrame(() => getThumbEngine().render(ctx, canvas.width, canvas.height, t, settings));
    return () => cancelAnimationFrame(id);
  }, [index, settings]);
  return <canvas ref={ref} width={320} height={180} className="h-full w-full" />;
}

export function StoryboardPanel({
  open,
  onClose,
  onSeek,
  time,
  settings,
}: {
  open: boolean;
  onClose: () => void;
  onSeek: (t: number) => void;
  time: number;
  settings: EngineSettings;
}) {
  if (!open) return null;
  const currentIndex = SHOTS.findIndex((shot) => time >= shot.start && time < shot.end);
  const style = STYLE_PRESETS.find((s) => s.id === settings.styleId);
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/80 px-4 py-[4vh] backdrop-blur-md">
      <div className="slide-up w-full max-w-[1240px] overflow-hidden rounded-xl border border-white/10 bg-[#0b0d10]">
        <header className="flex items-start justify-between gap-4 border-b border-white/[0.07] px-5 py-4">
          <div>
            <div className="mb-1.5 flex items-center gap-2">
              <Badge color="mint" dot>
                Storyboard
              </Badge>
              <span className="mono text-[8px] tracking-[0.12em] text-white/30 uppercase">{SHOTS.length} cuts · 15.00 s · {style?.name}</span>
            </div>
            <h2 className="text-[22px] leading-tight font-semibold tracking-[-0.02em] text-[#efeae0]">The Last 15 Seconds, cut by cut.</h2>
          </div>
          <button onClick={onClose} aria-label="Close storyboard" className="rounded-md border border-white/10 p-2 text-[#8b8e94] hover:text-white">
            <X size={15} />
          </button>
        </header>
        <div className="max-h-[74vh] overflow-y-auto p-4 scroll-thin">
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-5">
            {SHOTS.map((shot, i) => (
              <button
                key={shot.id}
                type="button"
                onClick={() => {
                  onSeek(shot.start + 0.001);
                }}
                className={cn(
                  "group overflow-hidden rounded-md border text-left transition-all",
                  i === currentIndex ? "border-[#ff6a3d]/70 shadow-[0_0_18px_rgba(255,106,61,0.16)]" : "border-white/[0.08] hover:border-white/25"
                )}
              >
                <div className="relative aspect-video overflow-hidden bg-black">
                  <ShotThumbnail index={i} settings={settings} />
                  <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-black/80 to-transparent px-1.5 pt-4 pb-1">
                    <span className="mono text-[6.5px] tracking-[0.04em] text-white/65">
                      {shot.start.toFixed(2)}–{shot.end.toFixed(2)}
                    </span>
                    <span className="mono text-[6px] tracking-[0.06em] text-[#ffb49c] uppercase">{shot.focus}</span>
                  </div>
                  {i === currentIndex && <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-[#ff6a3d]" />}
                </div>
                <div className="p-2">
                  <div className="flex items-center gap-1">
                    <span className="mono text-[6.5px] tracking-[0.08em] text-[#ff9a76]">{shot.id}</span>
                    <span className="mono text-[6px] tracking-[0.03em] text-white/25 uppercase">· {shot.transition}</span>
                  </div>
                  <p className="mt-1 truncate text-[9px] leading-none font-medium text-[#d9d4ca]">{shot.title}</p>
                  <p className="mono mt-1 truncate text-[6px] tracking-[0.05em] text-white/25 uppercase">{shot.motion ?? shot.scene}</p>
                </div>
              </button>
            ))}
          </div>
          <div className="mt-5 grid grid-cols-2 gap-2 border-t border-white/[0.06] pt-4 sm:grid-cols-5">
            {STORY_BEATS.map((beat) => (
              <div key={beat.id} className="rounded-md border border-white/[0.06] bg-black/20 p-2.5">
                <div className="mono mb-1.5 flex items-center justify-between text-[6.5px] tracking-[0.06em] text-white/30 uppercase">
                  <span>{beat.start.toFixed(1)}s</span>
                  <span>{beat.end.toFixed(1)}s</span>
                </div>
                <p className="text-[9.5px] leading-tight font-medium text-[#d6d1c7]">{beat.headline}</p>
                <p className="mono mt-1.5 text-[6.5px] leading-relaxed tracking-[0.02em] text-white/25">{beat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const CAT_COLORS: Record<CueCategory, string> = {
  ambience: "#7d9696",
  foley: "#bd9a6b",
  impact: "#d96547",
  engine: "#9d8bc0",
  music: "#8ea58b",
  alert: "#d9a64b",
};

function CueRow({ cue, onSeek }: { cue: AudioCue; onSeek: (t: number) => void }) {
  return (
    <button
      type="button"
      onClick={() => onSeek(cue.t)}
      className="group flex w-full items-center gap-2.5 border-b border-white/[0.04] px-1 py-[5px] text-left last:border-0 hover:bg-white/[0.03]"
    >
      <span className="mono w-9 shrink-0 text-[7.5px] text-[#ffb49c]/80">{cue.t.toFixed(2)}</span>
      <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: CAT_COLORS[cue.category] }} />
      <span className="flex-1 truncate text-[9px] text-[#b3b0a8] group-hover:text-[#e4dfd5]">{cue.label}</span>
      <span className="mono text-[6.5px] tracking-[0.06em] text-white/25 uppercase">{cue.category}</span>
    </button>
  );
}

export function SoundPanel({
  open,
  onClose,
  onSeek,
  mix,
  onMix,
  audioOn,
  onToggleAudio,
}: {
  open: boolean;
  onClose: () => void;
  onSeek: (t: number) => void;
  mix: MixSettings;
  onMix: (mix: MixSettings) => void;
  audioOn: boolean;
  onToggleAudio: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/80 px-4 py-[5vh] backdrop-blur-md">
      <div className="slide-up w-full max-w-[880px] overflow-hidden rounded-xl border border-white/10 bg-[#0b0d10]">
        <header className="flex items-start justify-between gap-4 border-b border-white/[0.07] px-5 py-4">
          <div>
            <div className="mb-1.5 flex items-center gap-2">
              <Badge color="cool" dot>
                Sound design
              </Badge>
              <span className="mono text-[8px] tracking-[0.12em] text-white/30 uppercase">Web Audio API · fully synthesized · no samples</span>
            </div>
            <h2 className="text-[22px] leading-tight font-semibold tracking-[-0.02em] text-[#efeae0]">Non-vocal. Fully procedural.</h2>
            <p className="mt-1 max-w-[520px] text-[10.5px] leading-relaxed text-[#85888f]">
              Every footstep, impact, siren and score note is generated at runtime. Dialogue lives in subtitles only — this mix contains no voices or narration.
            </p>
          </div>
          <button onClick={onClose} aria-label="Close sound" className="rounded-md border border-white/10 p-2 text-[#8b8e94] hover:text-white">
            <X size={15} />
          </button>
        </header>
        <div className="grid grid-cols-1 gap-0 md:grid-cols-[1.2fr_1fr]">
          <div className="border-b border-white/[0.07] p-5 md:border-r md:border-b-0">
            <div className="mb-3 flex items-center justify-between">
              <span className="eyebrow text-[#a5a7ad]">Cue sheet · 15.00 s</span>
              <button
                type="button"
                onClick={onToggleAudio}
                className={cn(
                  "btn border px-2.5 py-1.5 text-[9px]",
                  audioOn ? "border-[#a7c4a0]/30 bg-[#a7c4a0]/10 text-[#c4dabf]" : "border-white/10 text-[#a9abb1] hover:bg-white/[0.04]"
                )}
              >
                {audioOn ? <Volume2 size={11} /> : <VolumeX size={11} />}
                {audioOn ? "Audio on" : "Audition mix"}
              </button>
            </div>
            <div className="max-h-[420px] overflow-y-auto pr-1 scroll-thin">
              {AUDIO_CUES.map((cue) => (
                <CueRow key={cue.id} cue={cue} onSeek={onSeek} />
              ))}
            </div>
          </div>
          <div className="space-y-5 p-5">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="eyebrow text-[#a5a7ad]">Mixer</span>
                <Badge color="cool">
                  <AudioLines size={9} /> 3 buses
                </Badge>
              </div>
              <div className="space-y-3 rounded-md border border-white/[0.07] bg-black/20 p-3">
                <Slider label="Master" value={mix.master} onChange={(v) => onMix({ ...mix, master: v })} />
                <Slider label="Score" value={mix.music} onChange={(v) => onMix({ ...mix, music: v })} />
                <Slider label="Sound FX / Foley" value={mix.sfx} onChange={(v) => onMix({ ...mix, sfx: v })} />
                <Slider label="Ambience" value={mix.ambience} onChange={(v) => onMix({ ...mix, ambience: v })} />
                <Toggle label="Mute output" checked={mix.muted} onChange={(v) => onMix({ ...mix, muted: v })} />
              </div>
            </div>
            <div className="rounded-md border border-white/[0.07] bg-black/20 p-3">
              <div className="mb-2 flex items-center gap-1.5">
                <Sparkles size={10} className="text-[#ff8a62]" />
                <span className="eyebrow text-[#a5a7ad]">Design rules</span>
              </div>
              <ul className="space-y-1.5 text-[9px] leading-relaxed text-[#85888f]">
                <li className="flex gap-2"><span className="text-[#ff8a62]">—</span> Cues are timestamp-locked to the edit.</li>
                <li className="flex gap-2"><span className="text-[#ff8a62]">—</span> Foley responds to footsteps, doors, glass and metal.</li>
                <li className="flex gap-2"><span className="text-[#ff8a62]">—</span> Score and ambience remain fully instrumental.</li>
                <li className="flex gap-2"><span className="text-[#ff8a62]">—</span> Export records the same synthesized mix in sync.</li>
              </ul>
            </div>
            <div className="rounded-md border border-white/[0.05] p-3">
              <div className="mb-2 flex items-center gap-1.5">
                <Layers size={10} className="text-[#7d9696]" />
                <span className="eyebrow text-[#a5a7ad]">Cast locks</span>
              </div>
              {CAST.map((member) => (
                <div key={member.key} className="flex items-center justify-between border-b border-white/[0.04] py-1.5 last:border-0">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: member.coat }} />
                    <span className="text-[9px] text-[#b8b4ab]">{member.name}</span>
                  </div>
                  <span className="mono text-[6.5px] tracking-[0.06em] text-white/25 uppercase">{member.role}</span>
                </div>
              ))}
            </div>
            <div className="mono flex items-center gap-2 text-[7px] tracking-[0.08em] text-white/25 uppercase">
              <Clock size={9} /> Film duration locked to story · 15.00 s
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
