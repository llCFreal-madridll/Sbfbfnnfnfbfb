import { useRef } from "react";
import {
  AUDIO_CUES,
  DIALOGUE,
  FILM_DURATION,
  SHOTS,
  type MoodId,
} from "../engine/data";
import { cn } from "../utils/cn";

const MOOD_COLORS: Record<MoodId, string> = {
  action: "#a94b32",
  suspense: "#7a4036",
  mysterious: "#5b4a78",
  peaceful: "#647e68",
  sad: "#4f6b86",
  happy: "#a17b43",
};

const TRACKS = [
  { id: "video", label: "VIDEO", meta: "29 cuts", height: 36 },
  { id: "camera", label: "CAMERA", meta: "2.5D", height: 20 },
  { id: "dialogue", label: "DIALOGUE", meta: "8 lines", height: 20 },
  { id: "sfx", label: "SOUND FX", meta: "29 cues", height: 22 },
  { id: "music", label: "SCORE", meta: "non-vocal", height: 18 },
];

const CUE_COLORS: Record<string, string> = {
  ambience: "#7d9696",
  foley: "#bd9a6b",
  impact: "#d96547",
  engine: "#9d8bc0",
  music: "#7f8e7a",
  alert: "#d9a64b",
};

export default function Timeline({
  time,
  onSeek,
  currentShotId,
}: {
  time: number;
  onSeek: (time: number) => void;
  currentShotId: string;
}) {
  const laneRef = useRef<HTMLDivElement | null>(null);
  const pct = (time / FILM_DURATION) * 100;
  const scrubbing = useRef(false);

  const seekFromEvent = (clientX: number) => {
    const el = laneRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    onSeek(ratio * FILM_DURATION);
  };

  const handlePointer = (e: React.PointerEvent) => {
    scrubbing.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
    seekFromEvent(e.clientX);
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#0c0e11]">
      <header className="flex h-9 shrink-0 items-center justify-between border-b border-white/[0.06] px-3.5">
        <div className="flex items-center gap-3">
          <span className="eyebrow text-[#a5a7ad]">Timeline</span>
          <span className="mono text-[8px] tracking-[0.08em] text-white/30 uppercase">{SHOTS.length} cuts · 15.00 s</span>
        </div>
        <div className="mono flex items-center gap-3 text-[8px] tracking-[0.08em] text-white/30 uppercase">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#ff6a3d]" /> Playhead {time.toFixed(2)}s
          </span>
          <span className="hidden md:inline">Snap on</span>
          <span className="hidden lg:inline">Zoom 100%</span>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 overflow-hidden">
        <div className="w-[92px] shrink-0 border-r border-white/[0.06] bg-[#0a0c0e]">
          <div className="h-[22px] border-b border-white/[0.05]">
            <span className="mono px-2 text-[7.5px] leading-[22px] tracking-[0.12em] text-white/25">TRACKS</span>
          </div>
          {TRACKS.map((track) => (
            <div
              key={track.id}
              style={{ height: track.height }}
              className="flex flex-col justify-center border-b border-white/[0.035] px-2.5"
            >
              <span className="mono text-[7.5px] leading-none tracking-[0.1em] text-[#8c8f95]">{track.label}</span>
              <span className="mono mt-0.5 text-[6.5px] leading-none tracking-[0.04em] text-white/20">{track.meta}</span>
            </div>
          ))}
        </div>

        <div className="relative min-w-0 flex-1">
          <div
            ref={laneRef}
            className="relative h-full cursor-crosshair touch-none select-none"
            onPointerDown={handlePointer}
            onPointerMove={(e) => {
              if (scrubbing.current) seekFromEvent(e.clientX);
            }}
            onPointerUp={() => {
              scrubbing.current = false;
            }}
          >
            {/* ruler */}
            <div className="relative h-[22px] border-b border-white/[0.05]">
              {Array.from({ length: 16 }).map((_, i) => (
                <div key={i} className="absolute top-0 bottom-0" style={{ left: `${(i / FILM_DURATION) * 100}%` }}>
                  <span className={cn("block", i % 2 === 0 ? "h-[7px]" : "h-[4px]", "w-px bg-white/20")} />
                  {i % 2 === 0 && (
                    <span className="mono absolute top-[7px] left-1 text-[6.5px] tracking-[0.04em] text-white/30">{i}s</span>
                  )}
                </div>
              ))}
              <div className="absolute inset-x-0 top-0 flex h-[3px]">
                {SHOTS.map((shot) => (
                  <span
                    key={shot.id}
                    className="h-full"
                    style={{ width: `${((shot.end - shot.start) / FILM_DURATION) * 100}%`, background: MOOD_COLORS[shot.mood], opacity: 0.7 }}
                  />
                ))}
              </div>
            </div>

            {/* shots row */}
            <div className="relative flex h-9 gap-px overflow-hidden border-b border-white/[0.035] p-px" style={{ height: TRACKS[0].height }}>
              {SHOTS.map((shot) => {
                const width = (shot.end - shot.start) / FILM_DURATION;
                const active = shot.id === currentShotId;
                return (
                  <button
                    key={shot.id}
                    type="button"
                    title={`${shot.id} · ${shot.start.toFixed(2)}–${shot.end.toFixed(2)} · ${shot.title}`}
                    onPointerDown={(e) => e.stopPropagation()}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSeek(shot.start + 0.001);
                    }}
                    className={cn(
                      "relative h-full overflow-hidden rounded-[2px] border text-left transition-all",
                      active ? "border-[#ff9a76] shadow-[0_0_12px_rgba(255,106,61,0.25)]" : "border-black/30 hover:brightness-125"
                    )}
                    style={{
                      width: `${width * 100}%`,
                      background: active
                        ? "linear-gradient(180deg, #ff7d52 0%, #c24f30 100%)"
                        : `linear-gradient(180deg, ${MOOD_COLORS[shot.mood]} 0%, ${MOOD_COLORS[shot.mood]}bb 100%)`,
                    }}
                  >
                    <span className={cn("mono absolute inset-x-1 top-[4px] truncate text-[6.5px] leading-none tracking-[0.04em]", active ? "text-[#1b0e09]" : "text-white/70")}>
                      {shot.index + 1 < 10 ? "0" : ""}
                      {shot.index + 1} {shot.scene.split(" ")[0]}
                    </span>
                    <span className={cn("mono absolute inset-x-1 bottom-[4px] truncate text-[6px] leading-none", active ? "text-[#3b1a10]/80" : "text-white/30")}>
                      {shot.start.toFixed(2)}s
                    </span>
                  </button>
                );
              })}
            </div>

            {/* camera track */}
            <div className="relative border-b border-white/[0.035]" style={{ height: TRACKS[1].height }}>
              <div className="absolute inset-x-0 top-1/2 h-px bg-white/[0.08]" />
              {SHOTS.map((shot) => (
                <div
                  key={shot.id}
                  className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${((shot.start + shot.end) / 2 / FILM_DURATION) * 100}%` }}
                >
                  <span
                    className="block h-[6px] w-[6px] rotate-45 border"
                    style={{
                      borderColor: shot.id === currentShotId ? "#ffd4c1" : "#8aa4a5",
                      background: shot.id === currentShotId ? "#ff6a3d" : "#314346",
                    }}
                  />
                </div>
              ))}
              {[0, 0.5].map((offset) => (
                <span key={offset} className="absolute top-[3px] left-0 h-1 w-full bg-gradient-to-r from-transparent via-[#ff6a3d]/20 to-transparent" style={{ transform: `translateY(${offset * 8}px)` }} />
              ))}
            </div>

            {/* dialogue */}
            <div className="relative border-b border-white/[0.035]" style={{ height: TRACKS[2].height }}>
              {DIALOGUE.map((line) => (
                <button
                  key={line.id}
                  type="button"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(line.start);
                  }}
                  title={`${line.speaker}: ${line.text}`}
                  className="absolute top-1/2 h-[11px] -translate-y-1/2 overflow-hidden rounded-[2px] border border-[#ffb98c]/25 bg-[#ffb98c]/15 px-1 transition-colors hover:bg-[#ffb98c]/25"
                  style={{
                    left: `${(line.start / FILM_DURATION) * 100}%`,
                    width: `${Math.max(1.2, ((line.end - line.start) / FILM_DURATION) * 100)}%`,
                  }}
                >
                  <span className="mono block truncate text-[5.5px] leading-[9px] tracking-[0.06em] text-[#ffc8a9]/80 uppercase">{line.speaker}</span>
                </button>
              ))}
            </div>

            {/* sfx */}
            <div className="relative border-b border-white/[0.035]" style={{ height: TRACKS[3].height }}>
              {AUDIO_CUES.map((cue) => (
                <button
                  key={cue.id}
                  type="button"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(cue.t);
                  }}
                  title={`${cue.label} · ${cue.category}`}
                  className="absolute top-1/2 h-[9px] w-[2px] -translate-y-1/2 hover:w-[4px]"
                  style={{ left: `${(cue.t / FILM_DURATION) * 100}%`, background: CUE_COLORS[cue.category] }}
                />
              ))}
              {AUDIO_CUES.filter((c) => c.category === "impact").map((cue) => (
                <span
                  key={cue.id}
                  className="mono absolute top-[2px] text-[5px] tracking-[0.04em] whitespace-nowrap text-white/20"
                  style={{ left: `${(cue.t / FILM_DURATION) * 100 + 0.3}%` }}
                >
                  {cue.label.slice(0, 10)}
                </span>
              ))}
            </div>

            {/* score */}
            <div className="relative" style={{ height: TRACKS[4].height }}>
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2">
                <div className="flex h-[12px] w-full items-center gap-[1px] overflow-hidden px-px">
                  {Array.from({ length: 120 }).map((_, i) => {
                    const env = Math.sin((i / 120) * Math.PI) * 0.55 + 0.35;
                    const h = Math.abs(Math.sin(i * 1.7) * Math.cos(i * 0.43)) * env * 11 + 1;
                    return (
                      <span
                        key={i}
                        className="flex-1 rounded-full bg-[#8ea58b]/40"
                        style={{ height: h, opacity: i / 120 < time / FILM_DURATION ? 0.9 : 0.4 }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>

            {/* playhead */}
            <div
              className="pointer-events-none absolute top-0 bottom-0 z-20"
              style={{ left: `${pct}%` }}
            >
              <div className="absolute top-0 -left-[1px] h-full w-[1.5px] bg-[#ff6a3d]" />
              <div className="absolute -top-0 -left-[5px] flex h-[10px] w-[11px] items-center justify-center rounded-b-[2px] bg-[#ff6a3d]">
                <span className="h-[3px] w-[3px] rounded-full bg-[#200c05]" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
