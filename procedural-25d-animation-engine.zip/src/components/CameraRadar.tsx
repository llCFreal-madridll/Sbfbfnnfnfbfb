import { useEffect, useRef } from "react";
import type { Telemetry } from "../engine/render";

const COLORS: Record<string, string> = {
  camera: "#ff6a3d",
  cast: "#f0e7d7",
  zombie: "#d4574b",
  vehicle: "#9fc3c8",
  prop3d: "#d4ad74",
  environment: "#6f8588",
};

export default function CameraRadar({ telemetry, className }: { telemetry: Telemetry; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    if (!parent) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = parent.getBoundingClientRect();
    const cw = Math.max(220, rect.width);
    const ch = Math.max(140, rect.height);
    canvas.width = cw * dpr;
    canvas.height = ch * dpr;
    canvas.style.width = `${cw}px`;
    canvas.style.height = `${ch}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    drawRadar(ctx, cw, ch, telemetry);
  }, [telemetry, className]);

  return <canvas ref={canvasRef} className={className} />;
}

function drawRadar(ctx: CanvasRenderingContext2D, w: number, h: number, data: Telemetry) {
  const pad = 22;
  const xTo = (x: number) => pad + ((Math.max(-6, Math.min(6, x)) + 6) / 12) * (w - pad * 2);
  const zTo = (z: number) => h - pad - (Math.max(0, Math.min(12, z)) / 12) * (h - pad * 2);
  ctx.clearRect(0, 0, w, h);

  // depth bands
  const bands = [
    { from: 0, to: 2.8, color: "rgba(255,106,61,0.055)", name: "FG" },
    { from: 2.8, to: 6.5, color: "rgba(168,195,189,0.05)", name: "MG" },
    { from: 6.5, to: 12, color: "rgba(86,106,112,0.055)", name: "BG" },
  ];
  bands.forEach((band) => {
    ctx.fillStyle = band.color;
    const y1 = zTo(band.to);
    const y2 = zTo(band.from);
    ctx.fillRect(pad, y1, w - pad * 2, y2 - y1);
  });

  // grid
  ctx.strokeStyle = "rgba(255,255,255,0.055)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 12; i++) {
    const x = pad + (i / 12) * (w - pad * 2);
    ctx.beginPath();
    ctx.moveTo(x, pad);
    ctx.lineTo(x, h - pad);
    ctx.stroke();
  }
  for (let i = 0; i <= 8; i++) {
    const y = pad + (i / 8) * (h - pad * 2);
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(w - pad, y);
    ctx.stroke();
  }
  // center axis
  ctx.strokeStyle = "rgba(255,255,255,0.13)";
  ctx.setLineDash([3, 4]);
  ctx.beginPath();
  ctx.moveTo(w / 2, pad);
  ctx.lineTo(w / 2, h - pad);
  ctx.moveTo(pad, h / 2);
  ctx.lineTo(w - pad, h / 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // depth bands outlines and labels
  bands.forEach((band, i) => {
    ctx.strokeStyle = i === 0 ? "rgba(255,106,61,0.18)" : "rgba(255,255,255,0.09)";
    ctx.strokeRect(pad, zTo(band.to), w - pad * 2, zTo(band.from) - zTo(band.to));
    ctx.fillStyle = i === 0 ? "rgba(255,138,98,0.55)" : "rgba(200,200,200,0.28)";
    ctx.font = '500 8px "JetBrains Mono", monospace';
    ctx.fillText(band.name, pad + 4, zTo(band.to) + 10);
  });

  // visible frustum from camera
  const cam = data.camera;
  const cx = xTo(cam.x);
  const cy = zTo(cam.z);
  const dir = ((cam.yaw - 90) * Math.PI) / 180;
  const half = ((cam.fov / 2) * Math.PI) / 180;
  const length = Math.min(w, h) * 0.62;
  const grad = ctx.createRadialGradient(cx, cy, 4, cx, cy, length);
  grad.addColorStop(0, "rgba(255,106,61,0.16)");
  grad.addColorStop(1, "rgba(255,106,61,0)");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.arc(cx, cy, length, dir - half, dir + half);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(255,106,61,0.42)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(dir - half) * length, cy + Math.sin(dir - half) * length);
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(dir + half) * length, cy + Math.sin(dir + half) * length);
  ctx.stroke();
  // centre view ray
  ctx.setLineDash([4, 5]);
  ctx.strokeStyle = "rgba(255,180,150,0.55)";
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(dir) * length, cy + Math.sin(dir) * length);
  ctx.stroke();
  ctx.setLineDash([]);

  // objects
  data.objects
    .filter((obj) => obj.type !== "camera")
    .forEach((obj) => {
      const x = xTo(obj.x);
      const y = zTo(obj.z);
      const color = COLORS[obj.type] ?? "#9a9a9a";
      ctx.save();
      ctx.translate(x, y);
      if (obj.type === "zombie") {
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.75;
        ctx.beginPath();
        ctx.moveTo(0, -4);
        ctx.lineTo(4, 3);
        ctx.lineTo(-4, 3);
        ctx.closePath();
        ctx.fill();
      } else if (obj.type === "prop3d") {
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.8;
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.strokeRect(-3, -3, 6, 6);
      } else if (obj.type === "vehicle") {
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.7;
        ctx.fillRect(-5, -2.5, 10, 5);
      } else if (obj.type === "cast") {
        ctx.fillStyle = "rgba(240,231,215,0.9)";
        ctx.beginPath();
        ctx.arc(0, 0, 2.7, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.25)";
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.6;
        ctx.beginPath();
        ctx.arc(0, 0, 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = "rgba(222,218,208,0.55)";
      ctx.font = '500 7px "JetBrains Mono", monospace';
      const labelX = Math.min(obj.x > 3 ? -8 : 8, w - x - 60);
      ctx.fillText(obj.label, labelX, -6);
      ctx.restore();
    });

  // camera marker
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(dir + Math.PI / 2);
  ctx.fillStyle = "#ff6a3d";
  ctx.shadowColor = "#ff6a3d";
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.moveTo(0, -7);
  ctx.lineTo(5, 5);
  ctx.lineTo(0, 2);
  ctx.lineTo(-5, 5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.strokeStyle = "rgba(255,106,61,0.35)";
  ctx.beginPath();
  ctx.arc(cx, cy, 11, 0, Math.PI * 2);
  ctx.stroke();

  // axis labels
  ctx.fillStyle = "rgba(255,255,255,0.3)";
  ctx.font = '500 7.5px "JetBrains Mono", monospace';
  ctx.fillText("−X", pad, h - 8);
  ctx.fillText("+X", w - pad - 14, h - 8);
  ctx.fillText("FAR", pad + 4, pad + 11);
  ctx.fillText("NEAR", pad + 4, h - pad - 5);
  ctx.fillStyle = "rgba(255,255,255,0.22)";
  ctx.fillText("TOP / PLAN · LIVE RIG", w - pad - 116, pad + 11);
  const t = data.time.toFixed(2).padStart(5, "0");
  ctx.fillStyle = "rgba(255,138,98,0.65)";
  ctx.fillText(`${data.shotId} · ${t}s`, w - pad - 114, h - pad - 5);
}
