import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export function Panel({
  children,
  className,
  title,
  right,
  dense,
}: {
  children: ReactNode;
  className?: string;
  title?: ReactNode;
  right?: ReactNode;
  dense?: boolean;
}) {
  return (
    <section className={cn("rounded-[10px] border border-white/[0.07] bg-[#0d0f12]", className)}>
      {title && (
        <header className="flex items-center justify-between gap-2 border-b border-white/[0.06] px-3.5 py-2.5">
          <div className="flex min-w-0 items-center gap-2">{title}</div>
          {right}
        </header>
      )}
      <div className={dense ? "" : "p-3.5"}>{children}</div>
    </section>
  );
}

export function SectionLabel({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn("eyebrow", className)}>{children}</span>;
}

export function Badge({
  children,
  color = "mute",
  className,
  dot,
}: {
  children: ReactNode;
  color?: "mute" | "signal" | "mint" | "cool" | "bone";
  className?: string;
  dot?: boolean;
}) {
  const colors: Record<string, string> = {
    mute: "text-[#9a9da3] border-white/10 bg-white/[0.035]",
    signal: "text-[#ff8a62] border-[#ff6a3d]/25 bg-[#ff6a3d]/[0.08]",
    mint: "text-[#b7d4ae] border-[#a7c4a0]/25 bg-[#a7c4a0]/[0.08]",
    cool: "text-[#9fc8cf] border-[#8fc4c9]/25 bg-[#8fc4c9]/[0.08]",
    bone: "text-[#e7e1d4] border-white/15 bg-white/[0.06]",
  };
  const dots: Record<string, string> = {
    mute: "bg-[#9a9da3]",
    signal: "bg-[#ff6a3d]",
    mint: "bg-[#a7c4a0]",
    cool: "bg-[#8fc4c9]",
    bone: "bg-[#e7e1d4]",
  };
  return (
    <span
      className={cn(
        "mono inline-flex items-center gap-1.5 rounded-[4px] border px-1.5 py-[3px] text-[8.5px] tracking-[0.12em] uppercase",
        colors[color],
        className
      )}
    >
      {dot && <span className={cn("h-1 w-1 rounded-full", dots[color])} />}
      {children}
    </span>
  );
}

export function Slider({
  label,
  value,
  min = 0,
  max = 1,
  step = 0.01,
  onChange,
  suffix,
  icon,
  disabled,
}: {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  suffix?: string;
  icon?: ReactNode;
  disabled?: boolean;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className={cn("group", disabled && "pointer-events-none opacity-40")}>
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-[10.5px] text-[#a9abb1]">
          {icon && <span className="text-[#6f737a]">{icon}</span>}
          {label}
        </div>
        <span className="mono text-[9.5px] text-[#e3ded4]">
          {typeof value === "number" ? (Number.isInteger(step) ? value : value.toFixed(step < 0.1 ? 2 : 1)) : value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        className="range"
        style={{ ["--pct" as string]: `${pct}%` }}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        aria-label={label}
      />
    </div>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
  hint,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  hint?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-2 rounded-md py-[5px] text-left"
    >
      <span className="text-[10.5px] text-[#a9abb1]">{label}</span>
      <span
        className={cn(
          "relative h-[15px] w-[26px] shrink-0 rounded-full border transition-colors",
          checked ? "border-[#ff6a3d]/40 bg-[#ff6a3d]/80" : "border-white/10 bg-white/[0.07]"
        )}
      >
        <span
          className={cn(
            "absolute top-[2px] h-[9px] w-[9px] rounded-full bg-[#f4efe4] transition-all",
            checked ? "left-[14px]" : "left-[2px] bg-[#83868d]"
          )}
        />
        {hint && <span className="sr-only">{hint}</span>}
      </span>
    </button>
  );
}

export function IconButton({
  children,
  onClick,
  active,
  title,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  active?: boolean;
  title?: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      className={cn(
        "flex h-6 w-6 items-center justify-center rounded-[4px] border transition-colors",
        active
          ? "border-[#ff6a3d]/30 bg-[#ff6a3d]/10 text-[#ff8a62]"
          : "border-white/[0.07] bg-white/[0.02] text-[#7f838a] hover:border-white/15 hover:text-[#d7d3c9]",
        className
      )}
    >
      {children}
    </button>
  );
}

export function Divider({ className }: { className?: string }) {
  return <div className={cn("h-px w-full bg-white/[0.06]", className)} />;
}

export function Tabs<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { id: T; label: string; count?: number }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex gap-0.5 rounded-md border border-white/[0.07] bg-black/20 p-0.5", className)}>
      {options.map((option) => (
        <button
          key={option.id}
          type="button"
          onClick={() => onChange(option.id)}
          className={cn(
            "mono flex-1 rounded-[4px] px-2 py-1 text-[8.5px] tracking-[0.1em] uppercase transition-colors",
            value === option.id ? "bg-white/[0.09] text-[#efeae0]" : "text-[#777b82] hover:text-[#c7c3ba]"
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
