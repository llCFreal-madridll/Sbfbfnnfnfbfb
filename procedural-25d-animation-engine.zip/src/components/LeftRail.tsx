import { useEffect, useRef } from "react";
import { FilmEngine, type EngineSettings } from "../engine/render";
import {
  CAST,
  STORY_BEATS,
  STYLE_PRESETS,
  type Shot,
  type StoryBeat,
} from "../engine/data";
import { Badge } from "./ui";
import { Box, ChevronRight, Layers, LockKeyhole, Palette, Sparkles, Wand2 } from "lucide-react";
import { cn } from "../utils/cn";

let miniEngine: FilmEngine | null = null;

function StyleMiniPreview({ settings }: { settings: EngineSettings }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    if (!miniEngine) miniEngine = new FilmEngine();
    const id = requestAnimationFrame(() => miniEngine!.render(ctx, canvas.width, canvas.height, 6.55, settings));
    return () => cancelAnimationFrame(id);
  }, [settings]);
  return <canvas ref={ref} width={600} height={338} className="h-full w-full" />;
}

interface Props {
  settings: EngineSettings;
  shot: Shot;
  beat: StoryBeat;
  time: number;
  onSeek: (time: number) => void;
  onOpenStyles: () => void;
}

export default function LeftRail({ settings, shot, beat, time, onSeek, onOpenStyles }: Props) {
  const style = STYLE_PRESETS.find((s) => s.id === settings.styleId) ?? STYLE_PRESETS[0];

  return (
    <aside className="flex h-full min-h-0 flex-col gap-2 overflow-y-auto border-r border-white/[0.06] bg-[#090b0d] p-2.5 pr-2 scroll-thin">
      {/* style selector */}
      <section className="overflow-hidden rounded-[10px] border border-white/[0.08] bg-[#0d0f12]">
        <header className="flex items-center justify-between border-b border-white/[0.06] px-3 py-2">
          <div className="flex items-center gap-1.5">
            <Palette size={11} className="text-[#ff8a62]" />
            <span className="eyebrow text-[#a5a7ad]">Animation style</span>
          </div>
          <Badge color="signal">{style.tag}</Badge>
        </header>
        <button type="button" onClick={onOpenStyles} className="group relative block w-full overflow-hidden border-b border-white/[0.06] bg-black text-left">
          <div className="aspect-[16/9]">
            <StyleMiniPreview settings={settings} />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          <div className="absolute inset-x-2.5 bottom-2 flex items-end justify-between">
            <div>
              <div className="mono text-[7px] tracking-[0.1em] text-white/45 uppercase">Preset 01 · applied to 29 shots</div>
              <div className="text-[12px] leading-tight font-medium text-[#f2ede2]">{style.name}</div>
            </div>
            <span className="flex h-6 w-6 items-center justify-center rounded-full border border-white/20 bg-black/40 text-white/70 transition-colors group-hover:border-[#ff6a3d]/60 group-hover:text-[#ffb49c]">
              <ChevronRight size={11} />
            </span>
          </div>
        </button>
        <div className="p-3">
          <p className="line-clamp-2 text-[9.5px] leading-[1.6] text-[#85888f]">{style.description}</p>
          <div className="mt-2 flex items-center justify-between">
            <div className="flex items-center gap-1">
              {style.swatches.map((swatch) => (
                <span key={swatch} className="h-3 w-3 rounded-[2px] border border-black/40" style={{ background: swatch }} />
              ))}
            </div>
            <button
              type="button"
              onClick={onOpenStyles}
              className="btn border border-white/10 bg-white/[0.03] px-2 py-1 text-[8.5px] text-[#c8c3ba] hover:border-[#ff6a3d]/30 hover:text-[#ffb49c]"
            >
              <Wand2 size={9} /> Change style
            </button>
          </div>
        </div>
      </section>

      {/* scene / story */}
      <section className="rounded-[10px] border border-white/[0.08] bg-[#0d0f12]">
        <header className="flex items-center justify-between border-b border-white/[0.06] px-3 py-2">
          <div className="flex items-center gap-1.5">
            <Sparkles size={11} className="text-[#9fc8cf]" />
            <span className="eyebrow text-[#a5a7ad]">Story direction</span>
          </div>
          <span className="mono text-[7px] tracking-[0.08em] text-white/25 uppercase">Auto</span>
        </header>
        <div className="p-3">
          <div className="mono mb-1 text-[7.5px] tracking-[0.1em] text-[#ff9a76] uppercase">{beat.label}</div>
          <h3 className="text-[11.5px] leading-[1.35] font-medium text-[#e9e4da]">{beat.headline}</h3>
          <p className="mt-1 text-[9px] leading-[1.55] text-[#7f838b]">{beat.summary}</p>
          <div className="mt-2.5 flex flex-wrap gap-1">
            <Badge>{shot.mood}</Badge>
            <Badge color="cool">{shot.focus}</Badge>
            <Badge>{shot.transition} cut</Badge>
          </div>
        </div>
        <div className="border-t border-white/[0.05] px-2 py-1.5">
          {STORY_BEATS.map((item) => {
            const active = item.id === beat.id;
            const past = time > item.end;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSeek(item.start + 0.001)}
                className={cn(
                  "group flex w-full items-center gap-2 rounded-[4px] px-1.5 py-[5px] text-left transition-colors",
                  active ? "bg-[#ff6a3d]/[0.09]" : "hover:bg-white/[0.03]"
                )}
              >
                <span
                  className={cn(
                    "h-1.5 w-1.5 shrink-0 rounded-full border",
                    active ? "border-[#ff6a3d] bg-[#ff6a3d]" : past ? "border-[#7f8b84] bg-[#7f8b84]/50" : "border-white/20 bg-transparent"
                  )}
                />
                <span className={cn("flex-1 truncate text-[9px]", active ? "text-[#f0e9dd]" : "text-[#888b92] group-hover:text-[#c8c4bb]")}>
                  {item.label.replace(/^\d+ · /, "")}
                </span>
                <span className="mono text-[6.5px] tracking-[0.04em] text-white/25">{item.start.toFixed(1)}s</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* cast + layers */}
      <section className="rounded-[10px] border border-white/[0.08] bg-[#0d0f12]">
        <header className="flex items-center justify-between border-b border-white/[0.06] px-3 py-2">
          <div className="flex items-center gap-1.5">
            <Layers size={11} className="text-[#a8c3bd]" />
            <span className="eyebrow text-[#a5a7ad]">Cast & layers</span>
          </div>
          <span className="mono flex items-center gap-1 text-[6.5px] tracking-[0.08em] text-white/25 uppercase">
            <LockKeyhole size={7} /> Locked
          </span>
        </header>
        <div className="px-2 py-1.5">
          {CAST.map((member) => (
            <div key={member.key} className="flex items-center gap-2 rounded-[4px] px-1.5 py-[5px]">
              <span className="h-4 w-4 rounded-full border border-white/15" style={{ background: member.hair }} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[9px] leading-tight text-[#d9d4ca]">{member.name}</div>
                <div className="mono text-[6.5px] leading-tight tracking-[0.04em] text-white/30 uppercase">{member.role}</div>
              </div>
              <span
                className="mono rounded-[2px] border px-1 py-0.5 text-[6px] tracking-[0.06em] uppercase"
                style={{ color: member.accent, borderColor: member.accent + "55", background: member.accent + "14" }}
              >
                {member.age}
              </span>
            </div>
          ))}
          <div className="my-1 h-px bg-white/[0.05]" />
          {[
            { label: "Horde / infected", value: "01 group", color: "#d4574b" },
            { label: "2.5D environment", value: "FG · MG · BG", color: "#7d9696" },
            { label: "Atmosphere / FX", value: "12 systems", color: "#bd9a6b" },
            { label: "3D primitives", value: "cube · cyl · sphere", color: "#d4ad74" },
          ].map((row) => (
            <div key={row.label} className="flex items-center gap-2 rounded-[4px] px-1.5 py-[5px]">
              <Box size={11} style={{ color: row.color }} />
              <span className="flex-1 truncate text-[9px] text-[#a9a6a0]">{row.label}</span>
              <span className="mono text-[6.5px] tracking-[0.04em] text-white/25">{row.value}</span>
            </div>
          ))}
        </div>
      </section>

      {/* direction analysis */}
      <section className="rounded-[10px] border border-white/[0.08] bg-[#0d0f12] p-3">
        <div className="mb-2 flex items-center justify-between">
          <span className="eyebrow text-[#a5a7ad]">Engine notes</span>
          <span className="mono text-[6.5px] tracking-[0.08em] text-[#a7c4a0] uppercase">Story-aware</span>
        </div>
        <div className="space-y-1.5">
          {[
            ["Camera", `${shot.motion ?? "story dolly"} / ${shot.focus}`],
            ["Grade", `${shot.mood} palette · cold / signal`],
            ["Atmosphere", shot.mood === "mysterious" ? "interior haze · dust" : "wind · smoke · rain"],
            ["Audio", "procedural · non-vocal"],
          ].map(([k, v]) => (
            <div key={k} className="flex items-start justify-between gap-2">
              <span className="mono shrink-0 text-[6.5px] tracking-[0.08em] text-white/25 uppercase">{k}</span>
              <span className="text-right text-[8px] leading-tight text-[#9fa1a7]">{v}</span>
            </div>
          ))}
        </div>
        <div className="mt-2 rounded border border-[#ff6a3d]/15 bg-[#ff6a3d]/[0.045] px-2 py-1.5">
          <p className="text-[8px] leading-[1.5] text-[#d0a493]">
            Story determines duration. Editing is locked to 15.00s and {shot.index + 1}/29.
          </p>
        </div>
      </section>
    </aside>
  );
}
