import { useEffect, useRef } from "react";
import { FilmEngine, type EngineSettings } from "../engine/render";
import { STYLE_PRESETS, type StyleId } from "../engine/data";
import { Badge, Slider } from "./ui";
import { Check, Sparkles, X } from "lucide-react";
import { cn } from "../utils/cn";

let previewEngine: FilmEngine | null = null;
function getPreviewEngine() {
  if (!previewEngine) previewEngine = new FilmEngine();
  return previewEngine;
}

function StylePreview({ styleId, settings }: { styleId: StyleId; settings: EngineSettings }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const engine = getPreviewEngine();
    const previewSettings: EngineSettings = {
      ...settings,
      styleId,
      custom: { ...settings.custom },
    };
    // choose a shot with characters, vehicles and atmosphere for the preview
    const previewTime = styleId === "minimal" || styleId === "flat" ? 3.95 : styleId === "sketch" ? 13.22 : 6.55;
    const raf = requestAnimationFrame(() => engine.render(ctx, canvas.width, canvas.height, previewTime, previewSettings));
    return () => cancelAnimationFrame(raf);
  }, [styleId, settings]);
  return <canvas ref={ref} width={360} height={202} className="h-full w-full" aria-label={`${styleId} style preview`} />;
}

interface Props {
  open: boolean;
  settings: EngineSettings;
  onClose: () => void;
  onStyleChange: (id: StyleId) => void;
  onCustomChange: (patch: Partial<EngineSettings["custom"]>) => void;
}

export default function StyleSelector({ open, settings, onClose, onStyleChange, onCustomChange }: Props) {
  if (!open) return null;
  const selected = STYLE_PRESETS.find((s) => s.id === settings.styleId) ?? STYLE_PRESETS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/75 px-4 py-[5vh] backdrop-blur-[6px]">
      <div className="slide-up w-full max-w-[1110px] overflow-hidden rounded-xl border border-white/10 bg-[#0b0d10] shadow-[0_40px_120px_rgba(0,0,0,0.7)]">
        <header className="flex items-start justify-between gap-6 border-b border-white/[0.07] px-6 py-5">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <Badge color="signal" dot>
                Animation style
              </Badge>
              <span className="mono text-[8.5px] tracking-[0.12em] text-white/30 uppercase">S-01 / Code-generated presets</span>
            </div>
            <h2 className="text-[24px] leading-tight font-semibold tracking-[-0.02em] text-[#efeae0]">Choose the language of the film.</h2>
            <p className="mt-1.5 max-w-[580px] text-[11.5px] leading-relaxed text-[#85888f]">
              Every preset rewires the engine&apos;s drawing system — characters, environments, typography, light and transitions included.
              Presets are a starting point; shape and motion remain fully editable.
            </p>
          </div>
          <button onClick={onClose} aria-label="Close style selector" className="rounded-md border border-white/10 p-2 text-[#8b8e94] hover:text-white">
            <X size={15} />
          </button>
        </header>

        <div className="grid grid-cols-1 gap-3 px-6 py-5 sm:grid-cols-2 lg:grid-cols-4">
          {STYLE_PRESETS.map((preset, i) => {
            const active = preset.id === settings.styleId;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onStyleChange(preset.id)}
                className={cn(
                  "group overflow-hidden rounded-lg border text-left transition-all",
                  active
                    ? "border-[#ff6a3d]/60 bg-[#ff6a3d]/[0.055] shadow-[0_0_0_1px_rgba(255,106,61,0.16),0_12px_30px_rgba(0,0,0,0.35)]"
                    : "border-white/[0.08] bg-white/[0.015] hover:border-white/20 hover:bg-white/[0.03]"
                )}
              >
                <div className="relative aspect-[16/9] overflow-hidden border-b border-white/[0.06] bg-black">
                  <StylePreview styleId={preset.id} settings={settings} />
                  <span className="mono absolute top-2 left-2 rounded-[3px] border border-white/15 bg-black/55 px-1.5 py-0.5 text-[7.5px] tracking-[0.12em] text-white/70 uppercase backdrop-blur">
                    S-{String(i + 1).padStart(2, "0")} / {preset.tag}
                  </span>
                  {active && (
                    <span className="absolute top-2 right-2 flex h-5 w-5 items-center justify-center rounded-full bg-[#ff6a3d] text-[#0a0b0d]">
                      <Check size={11} strokeWidth={3} />
                    </span>
                  )}
                  <div className="absolute inset-x-0 bottom-0 flex h-8 items-end gap-0 bg-gradient-to-t from-black/70 to-transparent px-2 pb-1.5">
                    {preset.swatches.map((swatch) => (
                      <span key={swatch} className="h-2 w-4 border border-black/25" style={{ background: swatch }} />
                    ))}
                  </div>
                </div>
                <div className="p-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[12.5px] font-medium text-[#e8e3d9]">{preset.name}</h3>
                    <span className="mono text-[7.5px] tracking-[0.1em] text-white/25">{preset.id === "claude" ? "DEFAULT" : ""}</span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[9.5px] leading-[1.5] text-[#797d84]">{preset.description}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 gap-6 border-t border-white/[0.07] px-6 py-5 lg:grid-cols-[1fr_1.1fr]">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <Sparkles size={12} className="text-[#ff8a62]" />
              <span className="eyebrow">Selected · {selected.name}</span>
              <Badge color="signal">{selected.tag}</Badge>
            </div>
            <p className="max-w-[520px] text-[10.5px] leading-relaxed text-[#9a9da3]">{selected.description}</p>
            <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5">
              {[
                ["Shapes", selected.lineWeight.toFixed(1)],
                ["Texture", `${Math.round(selected.grain * 100)}%`],
                ["Wobble", `${Math.round(selected.wobble * 100)}%`],
                ["Detail", `${Math.round(selected.detail * 100)}%`],
              ].map(([k, v]) => (
                <span key={k} className="mono text-[8.5px] tracking-[0.08em] text-[#6f737a] uppercase">
                  {k} <span className="text-[#d4cfc5]">{v}</span>
                </span>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-5 gap-y-3">
            <Slider label="Outline weight" value={settings.custom.outline} min={0} max={2} step={0.05} onChange={(v) => onCustomChange({ outline: v })} suffix="×" />
            <Slider label="Character scale" value={settings.custom.character} min={0.8} max={1.25} step={0.01} onChange={(v) => onCustomChange({ character: v })} suffix="×" />
            <Slider label="Texture / grain" value={settings.custom.texture} min={0} max={1} step={0.01} onChange={(v) => onCustomChange({ texture: v })} />
            <Slider label="Wobble intensity" value={settings.custom.wobble} min={0} max={1.4} step={0.01} onChange={(v) => onCustomChange({ wobble: v })} />
          </div>
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.07] bg-black/20 px-6 py-4">
          <div className="mono flex items-center gap-4 text-[8px] tracking-[0.11em] text-white/30 uppercase">
            <span className="flex items-center gap-1.5">
              <span className="h-1 w-1 rounded-full bg-[#a7c4a0]" /> Changes preview live
            </span>
            <span className="hidden sm:inline">Applies to all 29 shots</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="btn border border-white/10 px-3.5 py-2 text-[#a9abb1] hover:bg-white/[0.04]"
            >
              Close
            </button>
            <button type="button" onClick={onClose} className="btn bg-[#ff6a3d] px-4 py-2 font-medium text-[#160b07] hover:bg-[#ff7d55]">
              <Check size={12} strokeWidth={2.6} /> Use this style
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}


