import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Stage from "./components/Stage";
import LeftRail from "./components/LeftRail";
import RightRail from "./components/RightRail";
import Timeline from "./components/Timeline";
import StyleSelector from "./components/StyleSelector";
import ExportPanel from "./components/ExportPanel";
import { SoundPanel, StoryboardPanel } from "./components/Overlays";
import { Badge } from "./components/ui";
import {
  DEFAULT_SETTINGS,
  FilmEngine,
  type EngineSettings,
} from "./engine/render";
import { SoundEngine, DEFAULT_MIX, type MixSettings } from "./engine/audio";
import {
  FILM_DURATION,
  SHOTS,
  STYLE_PRESETS,
  beatAt,
  formatTC,
  shotAt,
  type MoodId,
  type StyleId,
} from "./engine/data";
import {
  AudioLines,
  Captions,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clapperboard,
  Download,
  Grid3x3,
  LayoutGrid,
  Maximize2,
  Pause,
  Play,
  Repeat,
  ScanLine,
  Settings2,
  SkipBack,
  SkipForward,
  Sparkles,
  Volume2,
  VolumeX,
} from "lucide-react";
import { cn } from "./utils/cn";

export default function App() {
  const engine = useMemo(() => new FilmEngine(), []);
  const [settings, setSettings] = useState<EngineSettings>(DEFAULT_SETTINGS);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loop, setLoop] = useState(true);
  const [guides, setGuides] = useState(false);
  const [styleOpen, setStyleOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [storyboardOpen, setStoryboardOpen] = useState(false);
  const [soundOpen, setSoundOpen] = useState(false);
  const [mix, setMix] = useState<MixSettings>({ ...DEFAULT_MIX });
  const timeRef = useRef(0);
  const mixRef = useRef(mix);
  const loopRef = useRef(loop);
  const soundRef = useRef<SoundEngine | null>(null);
  const stageShellRef = useRef<HTMLDivElement | null>(null);
  const wasPlayingRef = useRef(false);

  mixRef.current = mix;
  loopRef.current = loop;

  const shot = shotAt(time);
  const beat = beatAt(time);
  const style = STYLE_PRESETS.find((s) => s.id === settings.styleId) ?? STYLE_PRESETS[0];
  const telemetry = useMemo(() => engine.telemetryAt(time, settings), [engine, time, settings]);
  const progress = time / FILM_DURATION;

  const getSound = useCallback(() => {
    if (!soundRef.current) soundRef.current = new SoundEngine();
    return soundRef.current;
  }, []);

  const startAudio = useCallback(
    (at: number) => {
      const sound = getSound();
      void sound.startAt(at, { ...mixRef.current, muted: false });
    },
    [getSound]
  );

  const seek = useCallback(
    (next: number) => {
      const clamped = Math.max(0, Math.min(FILM_DURATION - 0.001, next));
      timeRef.current = clamped;
      setTime(clamped);
      if (playingRef.current) {
        if (!mixRef.current.muted) startAudio(clamped);
        else getSound().stop();
      }
    },
    [getSound, startAudio]
  );

  const playingRef = useRef(playing);
  playingRef.current = playing;

  // Playback clock. The engine reads timeRef directly; UI state is throttled.
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    let lastUi = 0;
    const tick = (now: number) => {
      const dt = Math.min(260, now - last);
      last = now;
      let next = timeRef.current + dt / 1000;
      if (next >= FILM_DURATION) {
        if (loopRef.current) {
          next = 0;
          timeRef.current = 0;
          setTime(0);
          if (!mixRef.current.muted) startAudio(0);
          raf = requestAnimationFrame(tick);
          return;
        }
        timeRef.current = FILM_DURATION;
        setTime(FILM_DURATION);
        setPlaying(false);
        getSound().stop();
        return;
      }
      timeRef.current = next;
      if (now - lastUi > 38) {
        lastUi = now;
        setTime(next);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
    };
  }, [playing, getSound, startAudio]);

  useEffect(() => {
    if (!playing) getSound().stop();
  }, [playing, getSound]);

  useEffect(() => () => getSound().stop(), [getSound]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(target.tagName)) return;
      if (event.code === "Space") {
        event.preventDefault();
        setPlaying((value) => {
          const next = !value;
          if (next) {
            if (timeRef.current >= FILM_DURATION - 0.01) {
              timeRef.current = 0;
              setTime(0);
            }
            if (!mixRef.current.muted) startAudio(timeRef.current);
          } else {
            getSound().stop();
          }
          return next;
        });
      }
      if (event.key === "ArrowRight") seek(timeRef.current + 1);
      if (event.key === "ArrowLeft") seek(timeRef.current - 1);
      if (event.key.toLowerCase() === "m") {
        setMix((current) => {
          const next = { ...current, muted: !current.muted };
          mixRef.current = next;
          if (next.muted) getSound().stop();
          else if (playingRef.current) startAudio(timeRef.current);
          return next;
        });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [getSound, seek, startAudio]);

  const togglePlay = () => {
    if (playing) {
      setPlaying(false);
      getSound().stop();
      return;
    }
    if (timeRef.current >= FILM_DURATION - 0.01) {
      timeRef.current = 0;
      setTime(0);
    }
    setPlaying(true);
    if (!mix.muted) startAudio(timeRef.current);
  };

  const toggleAudio = () => {
    setMix((current) => {
      const next = { ...current, muted: !current.muted };
      mixRef.current = next;
      if (next.muted) getSound().stop();
      else {
        getSound().setMix(next);
        if (playingRef.current) startAudio(timeRef.current);
      }
      return next;
    });
  };

  const jumpShot = (dir: number) => {
    const current = SHOTS.findIndex((item) => time >= item.start && time < item.end);
    const idx = Math.max(0, Math.min(SHOTS.length - 1, (current < 0 ? 0 : current) + dir));
    seek(SHOTS[idx].start + 0.001);
  };

  const updateCamera = (patch: Partial<EngineSettings["camera"]>) => setSettings((s) => ({ ...s, camera: { ...s.camera, ...patch } }));
  const updateGrade = (patch: Partial<EngineSettings["grade"]>) => setSettings((s) => ({ ...s, grade: { ...s.grade, ...patch } }));
  const updateFx = (patch: Partial<EngineSettings["fx"]>) => setSettings((s) => ({ ...s, fx: { ...s.fx, ...patch } }));
  const updateCustom = (patch: Partial<EngineSettings["custom"]>) => setSettings((s) => ({ ...s, custom: { ...s.custom, ...patch } }));
  const resetCamera = () => setSettings((s) => ({ ...s, camera: { ...DEFAULT_SETTINGS.camera } }));

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      stageShellRef.current?.requestFullscreen?.().catch(() => undefined);
    } else {
      document.exitFullscreen().catch(() => undefined);
    }
  };

  const openExport = () => {
    wasPlayingRef.current = playing;
    if (playing) {
      setPlaying(false);
      getSound().stop();
    }
    setExportOpen(true);
  };

  return (
    <div className="flex h-screen min-h-0 flex-col overflow-hidden bg-[#08090b] text-[#ece8df] selection:bg-[#ff6a3d]">
      {/* top chrome */}
      <header className="flex h-[54px] shrink-0 items-center gap-3 border-b border-white/[0.08] bg-[#0a0c0e] px-3">
        <div className="flex shrink-0 items-center gap-2.5">
          <div className="relative flex h-[27px] w-[27px] items-center justify-center overflow-hidden rounded-[6px] bg-[#ff6a3d]">
            <svg viewBox="0 0 28 28" className="h-[17px] w-[17px]" aria-hidden>
              <path d="M4 21 21 4h3L7 21H4Z" fill="#170b06" />
              <path d="M12 24 24 12v7l-5 5h-7Z" fill="#170b06" opacity="0.82" />
              <path d="M4 7h5L4 12V7Z" fill="#170b06" opacity="0.55" />
            </svg>
          </div>
          <div className="leading-none">
            <div className="text-[12.5px] font-semibold tracking-[0.2em] text-[#f0ebe0]">PARALLAX</div>
            <div className="mono mt-1 text-[6.5px] tracking-[0.2em] text-[#7f838b] uppercase">2.5D Film Engine</div>
          </div>
        </div>

        <div className="mx-1 h-6 w-px bg-white/[0.08]" />

        <div className="hidden min-w-0 items-center gap-2 md:flex">
          <span className="mono flex items-center gap-1 text-[8px] tracking-[0.08em] text-white/30 uppercase">
            Projects <ChevronRightIcon />
          </span>
          <div className="flex min-w-0 items-center gap-1.5">
            <span className="truncate text-[11px] font-medium tracking-[-0.01em] text-[#ddd8ce]">The Last 15 Seconds</span>
            <ChevronDown size={10} className="text-white/30" />
          </div>
          <Badge color="signal">15.0s</Badge>
        </div>

        <nav className="mx-auto hidden items-center gap-1 rounded-md border border-white/[0.07] bg-black/25 p-0.5 lg:flex">
          <button
            type="button"
            onClick={() => {
              setStoryboardOpen(false);
              setSoundOpen(false);
            }}
            className="mono rounded-[4px] bg-white/[0.08] px-2.5 py-1.5 text-[8px] tracking-[0.12em] text-[#eee9df] uppercase"
          >
            Studio
          </button>
          <button
            type="button"
            onClick={() => setStoryboardOpen(true)}
            className="mono flex items-center gap-1.5 rounded-[4px] px-2.5 py-1.5 text-[8px] tracking-[0.12em] text-[#7f838b] uppercase transition-colors hover:bg-white/[0.04] hover:text-[#d9d4ca]"
          >
            <LayoutGrid size={9} /> Storyboard
          </button>
          <button
            type="button"
            onClick={() => setSoundOpen(true)}
            className="mono flex items-center gap-1.5 rounded-[4px] px-2.5 py-1.5 text-[8px] tracking-[0.12em] text-[#7f838b] uppercase transition-colors hover:bg-white/[0.04] hover:text-[#d9d4ca]"
          >
            <AudioLines size={9} /> Sound
          </button>
        </nav>

        <div className="ml-auto flex shrink-0 items-center gap-2">
          <span className="mono hidden items-center gap-1.5 text-[7.5px] tracking-[0.08em] text-white/30 uppercase xl:flex">
            <span className="h-1 w-1 rounded-full bg-[#a7c4a0]" /> Engine ready
          </span>
          <div className="hidden h-6 w-px bg-white/[0.08] xl:block" />
          <kbd className="mono hidden rounded border border-white/10 bg-white/[0.03] px-1.5 py-1 text-[7px] tracking-[0.06em] text-white/35 xl:block">SPACE</kbd>
          <button
            type="button"
            onClick={openExport}
            className="btn bg-[#ff6a3d] px-3 py-1.5 text-[10.5px] font-semibold text-[#180c07] shadow-[0_0_20px_rgba(255,106,61,0.12)] hover:bg-[#ff7d55]"
          >
            <Download size={11} strokeWidth={2.4} /> Export film
          </button>
          <div className="ml-0.5 hidden h-[25px] w-[25px] items-center justify-center rounded-full border border-white/15 bg-[#1b1e22] text-[8px] font-semibold text-[#cfcabf] sm:flex">
            SJ
          </div>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-1 overflow-hidden xl:grid-cols-[250px_minmax(0,1fr)_322px]">
        <div className="hidden min-h-0 xl:block">
          <LeftRail settings={settings} shot={shot} beat={beat} time={time} onSeek={seek} onOpenStyles={() => setStyleOpen(true)} />
        </div>

        <main className="flex min-h-0 min-w-0 flex-col bg-[#08090b]">
          {/* viewport toolbar */}
          <div className="flex h-[36px] shrink-0 items-center justify-between border-b border-white/[0.06] bg-[#0b0d0f] px-3">
            <div className="flex min-w-0 items-center gap-2">
              <span className="mono shrink-0 text-[8px] tracking-[0.08em] text-[#ff8a62]">{String(shot.index + 1).padStart(2, "0")} / {SHOTS.length}</span>
              <span className="h-4 w-px bg-white/10" />
              <span className="truncate text-[10px] font-medium tracking-[0.02em] text-[#d8d3c9]">{shot.scene}</span>
              <span className="mono hidden truncate text-[8px] tracking-[0.04em] text-white/30 uppercase sm:inline">· {shot.title}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="mono mr-1 hidden items-center gap-1 text-[6.5px] tracking-[0.1em] text-white/25 uppercase lg:flex">
                <Clapperboard size={8} /> {SHOTS.length} cuts · 15.00s
              </span>
              <ToolbarButton label="Letterbox" active={settings.fx.letterbox} onClick={() => updateFx({ letterbox: !settings.fx.letterbox })}>
                <ScanLine size={11} />
              </ToolbarButton>
              <ToolbarButton label="Safe guides" active={guides} onClick={() => setGuides(!guides)}>
                <Grid3x3 size={11} />
              </ToolbarButton>
              <ToolbarButton label="Subtitles" active={settings.fx.subtitles} onClick={() => updateFx({ subtitles: !settings.fx.subtitles })}>
                <Captions size={11} />
              </ToolbarButton>
              <ToolbarButton label="Fullscreen preview" onClick={toggleFullscreen}>
                <Maximize2 size={11} />
              </ToolbarButton>
            </div>
          </div>

          {/* stage */}
          <div className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden bg-[#07080a] p-2.5">
            <div ref={stageShellRef} className="relative h-full w-full overflow-hidden rounded-[5px] border border-white/[0.09] bg-black shadow-[0_16px_50px_rgba(0,0,0,0.5)]">
              <Stage engine={engine} timeRef={timeRef} playing={playing} settings={settings} time={time} />
              {guides && (
                <div className="pointer-events-none absolute inset-0 z-10">
                  <div className="absolute inset-[5%] border border-dashed border-[#ff6a3d]/30">
                    <span className="mono absolute -top-3 left-0 bg-black/60 px-1 text-[6px] tracking-[0.1em] text-[#ffb49c]/70 uppercase">Safe 90%</span>
                  </div>
                  <div className="absolute inset-y-0 left-1/3 w-px bg-white/[0.07]" />
                  <div className="absolute inset-y-0 left-2/3 w-px bg-white/[0.07]" />
                  <div className="absolute inset-x-0 top-1/3 h-px bg-white/[0.07]" />
                  <div className="absolute inset-x-0 top-2/3 h-px bg-white/[0.07]" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/20">+</div>
                </div>
              )}
            </div>
          </div>

          {/* transport */}
          <div className="flex h-[50px] shrink-0 items-center gap-2 border-t border-white/[0.07] bg-[#0b0d10] px-3">
            <button
              type="button"
              onClick={togglePlay}
              aria-label={playing ? "Pause film" : "Play film"}
              className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-full bg-[#ff6a3d] text-[#170b06] shadow-[0_0_16px_rgba(255,106,61,0.18)] transition-transform hover:scale-[1.04]"
            >
              {playing ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" className="ml-[1px]" />}
            </button>
            <div className="flex shrink-0 items-center">
              <button onClick={() => jumpShot(-1)} aria-label="Previous cut" className="flex h-6 w-6 items-center justify-center rounded text-white/40 hover:bg-white/[0.05] hover:text-white">
                <SkipBack size={12} />
              </button>
              <button onClick={() => jumpShot(1)} aria-label="Next cut" className="flex h-6 w-6 items-center justify-center rounded text-white/40 hover:bg-white/[0.05] hover:text-white">
                <SkipForward size={12} />
              </button>
            </div>
            <div className="mono flex shrink-0 items-baseline gap-1 text-[9px] tracking-[0.04em]">
              <span className="text-[#f0eae0]">{formatTC(time, 30)}</span>
              <span className="text-white/25">/</span>
              <span className="text-white/30">{formatTC(FILM_DURATION, 30)}</span>
            </div>

            <div className="relative mx-1 flex h-full min-w-0 flex-1 items-center">
              <div className="pointer-events-none absolute inset-x-0 top-[22px] h-[3px] overflow-hidden rounded-full bg-white/[0.08]">
                <div className="h-full rounded-full bg-gradient-to-r from-[#b24128] to-[#ff6a3d]" style={{ width: `${progress * 100}%` }} />
                {SHOTS.map((item) => (
                  <span key={item.id} className="absolute top-0 h-full w-px bg-black/50" style={{ left: `${((item.start + item.end) / 2 / FILM_DURATION) * 100}%` }} />
                ))}
              </div>
              <input
                type="range"
                aria-label="Scrub film"
                min={0}
                max={FILM_DURATION}
                step={0.01}
                value={time}
                onChange={(e) => seek(parseFloat(e.target.value))}
                className="relative z-10 h-6 w-full cursor-pointer appearance-none bg-transparent [&::-webkit-slider-runnable-track]:h-[3px] [&::-webkit-slider-runnable-track]:bg-transparent [&::-webkit-slider-thumb]:mt-0 [&::-webkit-slider-thumb]:h-[9px] [&::-webkit-slider-thumb]:w-[9px] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#f4efe4] [&::-webkit-slider-thumb]:shadow-[0_0_0_3px_rgba(255,106,61,0.22)]"
              />
              <span className="mono pointer-events-none absolute top-[17px] hidden text-[6px] tracking-[0.04em] text-white/25 sm:block" style={{ left: `${Math.min(91, progress * 100)}%` }}>
                {time.toFixed(2)}s
              </span>
            </div>

            <div className="flex shrink-0 items-center gap-1">
              <button
                onClick={() => setLoop(!loop)}
                aria-label="Loop"
                className={cn("flex h-6 w-6 items-center justify-center rounded transition-colors", loop ? "text-[#ffb49c]" : "text-white/30 hover:text-white/70")}
              >
                <Repeat size={11} />
              </button>
              <button onClick={toggleAudio} aria-label="Mute audio" className="flex h-6 w-6 items-center justify-center rounded text-white/40 hover:text-white">
                {mix.muted ? <VolumeX size={12} /> : <Volume2 size={12} />}
              </button>
              <input
                type="range"
                aria-label="Master volume"
                min={0}
                max={1}
                step={0.01}
                value={mix.master}
                onChange={(e) => {
                  const next = { ...mix, master: parseFloat(e.target.value) };
                  setMix(next);
                  mixRef.current = next;
                  getSound().setMix(next);
                }}
                className="range range-plain hidden w-[48px] md:block"
              />
              <span className="mono ml-1 hidden items-center gap-1 rounded-[3px] border border-[#ff6a3d]/20 bg-[#ff6a3d]/[0.06] px-1.5 py-1 text-[6.5px] tracking-[0.08em] text-[#ffb49c] uppercase lg:flex">
                <span className="h-1 w-1 rounded-full bg-[#ff6a3d]" /> Auto cam
              </span>
              <button onClick={openExport} className="ml-1 hidden h-6 items-center gap-1 rounded border border-white/10 px-2 text-[8px] text-white/50 hover:text-white sm:flex">
                <Settings2 size={9} /> Render
              </button>
            </div>
          </div>

          {/* timeline */}
          <div className="h-[188px] shrink-0 border-t border-white/[0.07]">
            <Timeline time={time} onSeek={seek} currentShotId={shot.id} />
          </div>
        </main>

        <div className="hidden min-h-0 xl:block">
          <RightRail
            settings={settings}
            telemetry={telemetry}
            shot={shot}
            time={time}
            onCameraChange={updateCamera}
            onGradeChange={updateGrade}
            onFxChange={updateFx}
            onCustomChange={updateCustom}
            onMood={(mood: MoodId | null) => setSettings((s) => ({ ...s, mood }))}
            onResetCamera={resetCamera}
          />
        </div>
      </div>

      <StyleSelector
        open={styleOpen}
        settings={settings}
        onClose={() => setStyleOpen(false)}
        onStyleChange={(id: StyleId) => setSettings((s) => ({ ...s, styleId: id }))}
        onCustomChange={updateCustom}
      />
      <ExportPanel
        open={exportOpen}
        settings={settings}
        onClose={() => {
          setExportOpen(false);
          if (wasPlayingRef.current) {
            wasPlayingRef.current = false;
          }
        }}
        onOpenStyles={() => {
          setExportOpen(false);
          setStyleOpen(true);
        }}
      />
      <StoryboardPanel
        open={storyboardOpen}
        onClose={() => setStoryboardOpen(false)}
        onSeek={seek}
        time={time}
        settings={settings}
      />
      <SoundPanel
        open={soundOpen}
        onClose={() => setSoundOpen(false)}
        onSeek={seek}
        mix={mix}
        onMix={(next) => {
          setMix(next);
          mixRef.current = next;
          getSound().setMix(next);
          if (next.muted) getSound().stop();
        }}
        audioOn={!mix.muted}
        onToggleAudio={toggleAudio}
      />

      {/* mobile-only rails summary */}
      <div className="flex items-center justify-between border-t border-white/[0.06] bg-[#0a0c0e] px-3 py-1.5 xl:hidden">
        <button onClick={() => setStyleOpen(true)} className="mono flex items-center gap-1.5 text-[7.5px] tracking-[0.08em] text-[#c8c3ba] uppercase">
          <Sparkles size={9} className="text-[#ff8a62]" /> {style.name}
        </button>
        <button onClick={() => setStoryboardOpen(true)} className="mono flex items-center gap-1.5 text-[7.5px] tracking-[0.08em] text-white/40 uppercase">
          <LayoutGrid size={9} /> Storyboard
        </button>
        <button onClick={() => setSoundOpen(true)} className="mono flex items-center gap-1.5 text-[7.5px] tracking-[0.08em] text-white/40 uppercase">
          <AudioLines size={9} /> Sound
        </button>
        <button onClick={() => setExportOpen(true)} className="mono flex items-center gap-1.5 text-[7.5px] tracking-[0.08em] text-[#ffb49c] uppercase">
          <Download size={9} /> Export
        </button>
      </div>
    </div>
  );
}

function ChevronRightIcon() {
  return <ChevronRight size={8} className="text-white/25" />;
}

function ToolbarButton({
  children,
  label,
  active,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn(
        "flex h-6 w-6 items-center justify-center rounded-[4px] border transition-colors",
        active
          ? "border-[#ff6a3d]/30 bg-[#ff6a3d]/10 text-[#ff9a76]"
          : "border-transparent text-white/30 hover:border-white/10 hover:bg-white/[0.04] hover:text-white/70"
      )}
    >
      {children}
    </button>
  );
}

const _unusedIcons = { ChevronLeft, Pause, Play, SkipBack, SkipForward };
void _unusedIcons;
