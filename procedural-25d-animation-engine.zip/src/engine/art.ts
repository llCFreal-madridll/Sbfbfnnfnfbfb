import type { CastMember, StyleId } from "./data";
import { CAST as CAST_DATA } from "./data";

export { CAST_DATA };

export interface Palette {
  light: boolean;
  bg1: string;
  bg2: string;
  far: string;
  mid: string;
  near: string;
  ink: string;
  line: string;
  accent: string;
  accent2: string;
  warm: string;
  cool: string;
  ground: string;
  road: string;
  skin: string;
  zombie: string;
  glass: string;
  glow: string;
  shadow: string;
  smoke: string;
}

export interface ResolvedStyle {
  outline: number;
  grain: number;
  jitter: number;
  soft: number;
  detail: number;
}

const STYLE_PALETTES: Record<StyleId, Palette> = {
  claude: {
    light: false,
    bg1: "#0c1418",
    bg2: "#2b393a",
    far: "#5f7b7b",
    mid: "#344c4d",
    near: "#192224",
    ink: "#0a0d0f",
    line: "#efe6d6",
    accent: "#ff6a3d",
    accent2: "#a8c3bd",
    warm: "#ffb483",
    cool: "#9ac4c2",
    ground: "#151c1e",
    road: "#1c2527",
    skin: "#efd4b7",
    zombie: "#8fa39a",
    glass: "#a3cecb",
    glow: "#ffe0bd",
    shadow: "#05090b",
    smoke: "#9aa9a5",
  },
  cinematic: {
    light: false,
    bg1: "#071018",
    bg2: "#1a3340",
    far: "#2c4c57",
    mid: "#182d34",
    near: "#0c171c",
    ink: "#050b10",
    line: "#dfe8e4",
    accent: "#ff8248",
    accent2: "#78aeb2",
    warm: "#ffbd84",
    cool: "#78b8d0",
    ground: "#0b1418",
    road: "#111d22",
    skin: "#c9a184",
    zombie: "#7c8f85",
    glass: "#8fc4c9",
    glow: "#ffd3a3",
    shadow: "#020609",
    smoke: "#8fa6a9",
  },
  minimal: {
    light: true,
    bg1: "#efece5",
    bg2: "#dcd7cc",
    far: "#bab4a8",
    mid: "#8f897e",
    near: "#1b1c1c",
    ink: "#161717",
    line: "#191a1a",
    accent: "#dc4531",
    accent2: "#8b8780",
    warm: "#c98b55",
    cool: "#9aa7ab",
    ground: "#cdc7ba",
    road: "#bdb7aa",
    skin: "#e4d4c0",
    zombie: "#9e9b90",
    glass: "#cfd3cf",
    glow: "#ffffff",
    shadow: "#716c62",
    smoke: "#a5a096",
  },
  sketch: {
    light: true,
    bg1: "#e7dfd1",
    bg2: "#d2c8b7",
    far: "#a9a091",
    mid: "#777064",
    near: "#36332d",
    ink: "#2b2925",
    line: "#33302b",
    accent: "#b64e39",
    accent2: "#7f8b7d",
    warm: "#c98e63",
    cool: "#8b9c9d",
    ground: "#bfb5a3",
    road: "#a89e8c",
    skin: "#dcc4a9",
    zombie: "#9b9b89",
    glass: "#c2cbc6",
    glow: "#fff7e4",
    shadow: "#5c574d",
    smoke: "#b5ac9c",
  },
  cartoon: {
    light: false,
    bg1: "#191a34",
    bg2: "#3a3f76",
    far: "#5a67a5",
    mid: "#333b72",
    near: "#1b1e3b",
    ink: "#0e0f20",
    line: "#111226",
    accent: "#ffbe3d",
    accent2: "#4ec8bb",
    warm: "#ff9a5c",
    cool: "#73d4e8",
    ground: "#202046",
    road: "#26274e",
    skin: "#f0c09a",
    zombie: "#9cc59e",
    glass: "#9fe3e4",
    glow: "#ffe8a8",
    shadow: "#0b0b1a",
    smoke: "#8d8fb7",
  },
  flat: {
    light: false,
    bg1: "#1b252b",
    bg2: "#3f5258",
    far: "#6b8086",
    mid: "#43565b",
    near: "#232f33",
    ink: "#172024",
    line: "#e4d8bf",
    accent: "#d96c3d",
    accent2: "#a7b8b3",
    warm: "#dcae74",
    cool: "#8ba8b0",
    ground: "#222e32",
    road: "#2a373a",
    skin: "#dbb391",
    zombie: "#94a79a",
    glass: "#a7c4c4",
    glow: "#ffe7c2",
    shadow: "#121a1d",
    smoke: "#9faeac",
  },
  hybrid: {
    light: false,
    bg1: "#0c1020",
    bg2: "#2f2f5c",
    far: "#5560a0",
    mid: "#303963",
    near: "#161b34",
    ink: "#080b16",
    line: "#e8e2f5",
    accent: "#ff8557",
    accent2: "#79d7d1",
    warm: "#ffc08f",
    cool: "#8fdcf0",
    ground: "#161a33",
    road: "#1d2340",
    skin: "#d8aa8b",
    zombie: "#93a2a8",
    glass: "#a7d8e4",
    glow: "#ffe0c8",
    shadow: "#050710",
    smoke: "#8b93b8",
  },
  experimental: {
    light: false,
    bg1: "#06050c",
    bg2: "#1d0f2b",
    far: "#48265e",
    mid: "#2b1a41",
    near: "#120d1d",
    ink: "#05040a",
    line: "#f5f1de",
    accent: "#ff2e88",
    accent2: "#24f0d2",
    warm: "#f3f25e",
    cool: "#24f0d2",
    ground: "#0d0915",
    road: "#15101f",
    skin: "#d6a98e",
    zombie: "#9aaaa0",
    glass: "#8ff0e4",
    glow: "#ff9ec4",
    shadow: "#030208",
    smoke: "#a184b3",
  },
};

export function paletteFor(styleId: StyleId): Palette {
  return STYLE_PALETTES[styleId];
}

export function resolveStyle(styleId: StyleId, outline = 1): ResolvedStyle {
  const map: Record<StyleId, ResolvedStyle> = {
    claude: { outline: 2.1, grain: 0.045, jitter: 0, soft: 0.45, detail: 1 },
    cinematic: { outline: 0.35, grain: 0.06, jitter: 0, soft: 1, detail: 1.05 },
    minimal: { outline: 1.45, grain: 0.008, jitter: 0, soft: 0.12, detail: 0.62 },
    sketch: { outline: 1.15, grain: 0.09, jitter: 1.5, soft: 0.3, detail: 0.92 },
    cartoon: { outline: 3.1, grain: 0.03, jitter: 0.4, soft: 0.2, detail: 0.88 },
    flat: { outline: 0.7, grain: 0.012, jitter: 0, soft: 0.5, detail: 0.8 },
    hybrid: { outline: 0.9, grain: 0.03, jitter: 0, soft: 0.85, detail: 1 },
    experimental: { outline: 1.1, grain: 0.075, jitter: 0.8, soft: 0.4, detail: 0.9 },
  };
  const base = map[styleId];
  return { ...base, outline: base.outline * outline };
}

/* ---------------------------------- color ---------------------------------- */

export function clamp(v: number, a = 0, b = 1) {
  return Math.max(a, Math.min(b, v));
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function smooth(t: number) {
  const x = clamp(t);
  return x * x * (3 - 2 * x);
}

export function easeOut(t: number) {
  const x = clamp(t);
  return 1 - Math.pow(1 - x, 3);
}

export function mixColor(a: string, b: string, amount: number): string {
  const pa = hex(a);
  const pb = hex(b);
  const t = clamp(amount);
  const r = Math.round(lerp(pa[0], pb[0], t));
  const g = Math.round(lerp(pa[1], pb[1], t));
  const bl = Math.round(lerp(pa[2], pb[2], t));
  return `rgb(${r},${g},${bl})`;
}

export function hex(c: string): [number, number, number] {
  if (c.startsWith("rgb")) {
    const vals = c.replace(/[^\d.,]/g, "").split(",").map(Number);
    return [vals[0] ?? 0, vals[1] ?? 0, vals[2] ?? 0];
  }
  const raw = c.replace("#", "");
  const full = raw.length === 3 ? raw.split("").map((v) => v + v).join("") : raw;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgba(c: string, alpha: number): string {
  const [r, g, b] = hex(c);
  return `rgba(${r},${g},${b},${clamp(alpha)})`;
}

export function shade(c: string, amount: number): string {
  return amount < 0 ? mixColor(c, "#000000", -amount) : mixColor(c, "#ffffff", amount);
}

export function seeded(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/* ---------------------------------- shapes --------------------------------- */

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

export function poly(ctx: CanvasRenderingContext2D, points: [number, number][], close = true) {
  ctx.beginPath();
  points.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
  if (close) ctx.closePath();
}

export function grad(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  stops: [number, string][]
) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  stops.forEach(([at, c]) => g.addColorStop(at, c));
  return g;
}

export function radial(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r0: number,
  r1: number,
  stops: [number, string][]
) {
  const g = ctx.createRadialGradient(x, y, r0, x, y, r1);
  stops.forEach(([at, c]) => g.addColorStop(at, c));
  return g;
}

export function glow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  color: string,
  strength = 0.5
) {
  if (radius <= 0 || strength <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = radial(ctx, x, y, 0, radius, [
    [0, rgba(color, strength)],
    [0.35, rgba(color, strength * 0.42)],
    [1, rgba(color, 0)],
  ]);
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function vignette(ctx: CanvasRenderingContext2D, w: number, h: number, strength = 0.65, color = "#000000") {
  ctx.save();
  ctx.fillStyle = radial(ctx, w / 2, h * 0.46, h * 0.18, Math.max(w, h) * 0.76, [
    [0, rgba(color, 0)],
    [0.62, rgba(color, 0.06)],
    [1, rgba(color, strength)],
  ]);
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

export function speedLines(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  color: string,
  intensity = 1,
  count = 26
) {
  const rnd = seeded(77);
  ctx.save();
  ctx.globalAlpha = 0.55 * intensity;
  ctx.strokeStyle = color;
  for (let i = 0; i < count; i++) {
    const y = rnd() * h;
    const len = 80 + rnd() * 340;
    const speed = 420 + rnd() * 720;
    const x = (t * speed + rnd() * w * 2) % (w + len) - len;
    ctx.lineWidth = 0.6 + rnd() * 2.2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + len, y);
    ctx.stroke();
  }
  ctx.restore();
}

export function smokePlume(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  color: string,
  t: number,
  alpha = 0.4,
  seed = 1
) {
  const rnd = seeded(seed);
  ctx.save();
  for (let i = 0; i < 9; i++) {
    const drift = (t * (12 + i * 4) + rnd() * 80) % 120;
    const px = x + Math.sin(t * 0.6 + i) * 18 * scale + (rnd() - 0.5) * 50 * scale;
    const py = y - i * 22 * scale - drift * scale * 0.35;
    const pr = (16 + rnd() * 26) * scale * (1 + i * 0.16);
    ctx.globalAlpha = 1;
    ctx.fillStyle = radial(ctx, px, py, pr * 0.08, pr, [
      [0, rgba(color, alpha * (0.42 + (1 - i / 10) * 0.3))],
      [0.55, rgba(color, alpha * 0.2)],
      [1, rgba(color, 0)],
    ]);
    ctx.beginPath();
    ctx.arc(px, py, pr, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function dust(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  color: string,
  count = 42,
  seed = 3,
  intensity = 1
) {
  const rnd = seeded(seed);
  ctx.save();
  ctx.fillStyle = color;
  for (let i = 0; i < count; i++) {
    const baseX = rnd() * w;
    const baseY = rnd() * h;
    const speed = 5 + rnd() * 16;
    const x = (baseX + t * speed + Math.sin(t + i) * 12) % w;
    const y = (baseY - t * speed * 0.45 + h) % h;
    const r = 0.5 + rnd() * 1.8;
    ctx.globalAlpha = (0.16 + rnd() * 0.4) * intensity;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function rain(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  color: string,
  intensity = 1
) {
  const rnd = seeded(19);
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  for (let i = 0; i < 110; i++) {
    const x = (rnd() * w + t * 240) % (w + 120) - 60;
    const y = (rnd() * h + t * (620 + rnd() * 320)) % (h + 60) - 30;
    const len = 8 + rnd() * 27;
    ctx.globalAlpha = (0.08 + rnd() * 0.2) * intensity;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - 3, y + len);
    ctx.stroke();
  }
  ctx.restore();
}

export function lightCone(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  spread: number,
  length: number,
  color: string,
  alpha = 0.24
) {
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  const g = ctx.createRadialGradient(x, y, 8, x, y, length);
  g.addColorStop(0, rgba(color, alpha));
  g.addColorStop(0.55, rgba(color, alpha * 0.4));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.arc(x, y, length, angle - spread / 2, angle + spread / 2);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function sunRays(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string,
  alpha: number,
  count = 7,
  length = 900
) {
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  for (let i = 0; i < count; i++) {
    const a = -0.35 + i * 0.13 + Math.sin(i * 4.1) * 0.05;
    const spread = 0.026 + (i % 3) * 0.018;
    const g = ctx.createRadialGradient(x, y, 20, x, y, length);
    g.addColorStop(0, rgba(color, alpha));
    g.addColorStop(0.45, rgba(color, alpha * 0.4));
    g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(x, y, length, a - spread, a + spread);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

export function grainTile(size = 180): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const g = c.getContext("2d")!;
  const img = g.createImageData(size, size);
  let seed = 99;
  for (let i = 0; i < img.data.length; i += 4) {
    seed = (seed * 16807) % 2147483647;
    const v = 90 + (seed % 150);
    img.data[i] = v;
    img.data[i + 1] = v;
    img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

/* ---------------------------------- cast ---------------------------------- */

export function castLook(member: CastMember, p: Palette, styleId: StyleId) {
  let skin = member.skin;
  let hair = member.hair;
  let coat = member.coat;
  let shirt = member.shirt;
  let pants = member.pants;
  let accent = member.accent;
  if (styleId === "minimal") {
    skin = mixColor(member.skin, p.bg1, 0.55);
    hair = p.ink;
    coat = member.key === "mara" ? p.accent : p.near;
    shirt = p.bg1;
    pants = mixColor(p.ink, p.bg1, 0.15);
    accent = p.accent;
  } else if (styleId === "sketch") {
    skin = mixColor(member.skin, p.bg1, 0.36);
    hair = mixColor(member.hair, p.bg1, 0.22);
    coat = mixColor(member.coat, p.bg1, 0.4);
    shirt = mixColor(member.shirt, p.bg1, 0.4);
    pants = mixColor(member.pants, p.bg1, 0.2);
  } else if (styleId === "cartoon") {
    coat = shade(member.coat, 0.06);
    accent = shade(member.accent, 0.04);
  } else if (styleId === "cinematic") {
    skin = mixColor(member.skin, "#8b6b58", 0.25);
    coat = shade(member.coat, -0.2);
    shirt = shade(member.shirt, -0.25);
    hair = shade(member.hair, -0.1);
  } else if (styleId === "experimental") {
    coat = member.key === "mara" ? p.accent : member.key === "kai" ? p.accent2 : p.warm;
    skin = mixColor(member.skin, "#c9a4a4", 0.25);
  } else if (styleId === "flat") {
    coat = mixColor(member.coat, p.bg1, 0.18);
    accent = mixColor(member.accent, p.warm, 0.2);
  } else if (styleId === "hybrid") {
    coat = mixColor(member.coat, "#5862a0", 0.18);
  }
  return { skin, hair, coat, shirt, pants, accent, bag: mixColor(accent, p.near, 0.4) };
}

export type ActorPose = "run" | "sprint" | "idle" | "reach" | "push" | "lookback" | "wave" | "drive" | "leap" | "whisper";
export type ActorView = "front" | "back" | "side";

interface ActorOptions {
  x: number;
  y: number;
  scale: number;
  member: CastMember;
  pose: ActorPose;
  view?: ActorView;
  facing?: 1 | -1;
  t: number;
  phase?: number;
  palette: Palette;
  style: StyleId;
  styleCfg: ResolvedStyle;
  expression?: "fear" | "determined" | "shock" | "calm";
  wobble?: number;
  wobbleSpeed?: number;
  zombie?: boolean;
  silhouette?: boolean;
  alpha?: number;
  detail?: boolean;
}

export function drawActor(ctx: CanvasRenderingContext2D, o: ActorOptions) {
  const p = o.palette;
  const look = o.zombie
    ? {
        skin: p.zombie,
        hair: p.ink,
        coat: mixColor(p.zombie, p.near, 0.55),
        shirt: mixColor(p.zombie, p.near, 0.35),
        pants: mixColor(p.ink, p.near, 0.4),
        accent: p.accent,
        bag: p.near,
      }
    : castLook(o.member, p, o.style);
  const outline = o.silhouette ? 0 : o.styleCfg.outline;
  const h = 200 * o.scale * (o.member?.height ?? 1);
  const facing = o.facing ?? 1;
  const phase = o.phase ?? 0;
  const wob = (o.wobble ?? 1) * (o.styleCfg.jitter * 0.5 + 0.4);
  const speed = o.wobbleSpeed ?? 1;
  const walk = Math.sin(o.t * (o.pose === "run" || o.pose === "sprint" ? 12 * speed : 6 * speed) + phase);
  const running = o.pose === "run" || o.pose === "sprint";
  const lean = running ? 0.11 : o.pose === "push" ? 0.2 : o.pose === "leap" ? 0.22 : 0;
  const bob = running ? Math.abs(Math.cos(o.t * 12 * speed + phase)) * 0.035 : Math.sin(o.t * 2 * speed + phase) * 0.011;

  ctx.save();
  ctx.translate(o.x, o.y);
  ctx.scale(facing * h, h);
  ctx.globalAlpha = o.alpha ?? 1;
  ctx.translate(0, -bob);
  ctx.rotate(-lean * 0.15 + Math.sin(o.t * 1.7 * speed + phase) * 0.006 * wob);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  const outlineDraw = (width = 0.75) => {
    if (outline <= 0) return;
    ctx.strokeStyle = o.style === "minimal" || o.style === "sketch" ? p.line : p.ink;
    ctx.lineWidth = width / h;
    ctx.stroke();
  };

  const drawBoot = (x: number, y: number, rot: number) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.fillStyle = o.silhouette ? p.near : shade(look.pants, -0.32);
    roundRect(ctx, -0.018, -0.018, 0.095, 0.035, 0.015 / h * 4);
    ctx.fill();
    if (!o.silhouette) {
      ctx.fillStyle = rgba(p.line, 0.22);
      ctx.fillRect(0.052, -0.004, 0.01, 0.012);
    }
    ctx.restore();
  };

  const leg = (hipX: number, thigh: number, knee: number, bootRot: number) => {
    const hipY = -0.46;
    const kx = hipX + Math.sin(thigh) * 0.24;
    const ky = hipY + Math.cos(thigh) * 0.24;
    const fx = kx + Math.sin(thigh - knee) * 0.23;
    const fy = ky + Math.cos(thigh - knee) * 0.23;
    ctx.strokeStyle = look.pants;
    ctx.lineWidth = 0.075;
    ctx.beginPath();
    ctx.moveTo(hipX, hipY);
    ctx.lineTo(kx, ky);
    ctx.lineTo(fx, fy);
    ctx.stroke();
    outlineDraw(ctx.lineWidth);
    drawBoot(fx, fy, bootRot);
    return fy;
  };

  // far leg / arm
  const farLegThigh = running ? walk * 0.52 : 0.08;
  const farLegKnee = running ? Math.max(0, -walk) * 0.8 + 0.06 : 0.06;
  leg(-0.04, farLegThigh, farLegKnee, running ? 0.18 : 0);

  // far arm
  const armDraw = (shoulderX: number, shoulderY: number, upper: number, lower: number, color: string) => {
    const ex = shoulderX + Math.sin(upper) * 0.2;
    const ey = shoulderY + Math.cos(upper) * 0.2;
    const hx = ex + Math.sin(upper + lower) * 0.18;
    const hy = ey + Math.cos(upper + lower) * 0.18;
    ctx.strokeStyle = color;
    ctx.lineWidth = 0.062;
    ctx.beginPath();
    ctx.moveTo(shoulderX, shoulderY);
    ctx.lineTo(ex, ey);
    ctx.lineTo(hx, hy);
    ctx.stroke();
    outlineDraw(ctx.lineWidth);
    ctx.fillStyle = look.skin;
    ctx.beginPath();
    ctx.arc(hx, hy, 0.029, 0, Math.PI * 2);
    ctx.fill();
    if (outline > 0) {
      ctx.lineWidth = outline * 0.55 / h;
      ctx.strokeStyle = rgba(p.ink, 0.8);
      ctx.stroke();
    }
    return [hx, hy] as [number, number];
  };

  const farUpper = running ? -0.9 * walk : o.pose === "push" ? 1.35 : 0.12;
  armDraw(-0.115, -0.77, farUpper, 0.55, shade(look.coat, -0.18));

  // torso / jacket
  const torsoGrad = ctx.createLinearGradient(-0.1, -0.8, 0.15, -0.45);
  torsoGrad.addColorStop(0, o.silhouette ? p.near : shade(look.coat, 0.12));
  torsoGrad.addColorStop(1, o.silhouette ? p.near : shade(look.coat, -0.16));
  ctx.fillStyle = torsoGrad;
  ctx.beginPath();
  ctx.moveTo(-0.12, -0.8);
  ctx.quadraticCurveTo(-0.17, -0.68, -0.135, -0.44);
  ctx.lineTo(0.12, -0.44);
  ctx.quadraticCurveTo(0.16, -0.67, 0.115, -0.8);
  ctx.quadraticCurveTo(0, -0.86, -0.12, -0.8);
  ctx.closePath();
  ctx.fill();
  outlineDraw();

  if (!o.silhouette && o.view !== "back") {
    // shirt / zip
    ctx.fillStyle = rgba(look.shirt, 0.9);
    ctx.beginPath();
    ctx.moveTo(-0.035, -0.79);
    ctx.lineTo(0.035, -0.79);
    ctx.lineTo(0.025, -0.52);
    ctx.lineTo(-0.02, -0.52);
    ctx.closePath();
    ctx.fill();
    // strap / accent
    ctx.strokeStyle = rgba(look.accent, 0.85);
    ctx.lineWidth = 0.018;
    ctx.beginPath();
    ctx.moveTo(-0.08, -0.79);
    ctx.lineTo(0.07, -0.58);
    ctx.stroke();
  }

  // neck
  ctx.fillStyle = look.skin;
  ctx.fillRect(-0.026, -0.865, 0.052, 0.06);

  // head
  const headTilt = o.zombie ? -0.24 + Math.sin(o.t * 1.6) * 0.06 : (o.expression === "shock" ? -0.06 : 0.02) + Math.sin(o.t * 1.8 * speed + phase) * 0.02 * wob;
  ctx.save();
  ctx.translate(0, -0.88);
  ctx.rotate(headTilt);
  ctx.fillStyle = look.skin;
  ctx.beginPath();
  ctx.ellipse(0, -0.045, 0.073, 0.085, 0, 0, Math.PI * 2);
  ctx.fill();
  outlineDraw(0.6);
  // hair
  ctx.fillStyle = look.hair;
  if (o.member?.hairStyle === "beanie" || o.zombie) {
    ctx.beginPath();
    ctx.ellipse(0, -0.083, 0.082, 0.07, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(0.004, -0.094, 0.076, 0.052, 0, 0, Math.PI * 2);
    ctx.fill();
    if (o.member?.hairStyle === "beanie" && !o.zombie) {
      ctx.fillStyle = look.accent;
      ctx.fillRect(-0.08, -0.077, 0.16, 0.031);
      ctx.fillStyle = rgba(p.bg1, 0.25);
      for (let i = 0; i < 5; i++) ctx.fillRect(-0.07 + i * 0.032, -0.077, 0.011, 0.03);
    }
  } else if (o.member?.hairStyle === "curls") {
    for (let i = 0; i < 9; i++) {
      const a = Math.PI * (0.95 + i * 0.14);
      const cx = Math.cos(a) * 0.068;
      const cy = -0.09 + Math.sin(a) * -0.048;
      ctx.beginPath();
      ctx.arc(cx, cy, 0.038 + (i % 3) * 0.007, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.ellipse(0, -0.1, 0.082, 0.064, 0, Math.PI, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.ellipse(0, -0.098, 0.08, 0.059, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(facing * 0.035, -0.1, 0.052, 0.04, 0, Math.PI, Math.PI * 2);
    ctx.fill();
  }
  // face
  if (o.view !== "back" && !o.silhouette) {
    const eyeColor = o.zombie ? p.glow : p.ink;
    const eyeY = -0.048;
    if (o.zombie) {
      ctx.fillStyle = p.ink;
      ctx.beginPath();
      ctx.ellipse(-0.026, eyeY, 0.017, 0.012, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(0.028, eyeY, 0.016, 0.011, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = rgba(p.glow, 0.85);
      ctx.beginPath();
      ctx.arc(-0.026, eyeY, 0.005, 0, Math.PI * 2);
      ctx.arc(0.028, eyeY, 0.005, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = eyeColor;
      ctx.beginPath();
      ctx.ellipse(-0.028, eyeY, 0.009, 0.011, 0, 0, Math.PI * 2);
      ctx.ellipse(0.027, eyeY, 0.009, 0.011, 0, 0, Math.PI * 2);
      ctx.fill();
      if (o.expression === "fear" || o.expression === "shock") {
        ctx.strokeStyle = rgba(p.ink, 0.6);
        ctx.lineWidth = 0.006;
        ctx.beginPath();
        ctx.moveTo(-0.042, eyeY - 0.026);
        ctx.lineTo(-0.017, eyeY - 0.02);
        ctx.moveTo(0.016, eyeY - 0.02);
        ctx.lineTo(0.04, eyeY - 0.025);
        ctx.stroke();
      }
    }
    ctx.strokeStyle = rgba(p.ink, 0.55);
    ctx.lineWidth = 0.006;
    ctx.beginPath();
    ctx.moveTo(0.002, eyeY);
    ctx.lineTo(-0.002, eyeY + 0.019);
    ctx.stroke();
    ctx.fillStyle = o.zombie ? rgba(p.ink, 0.85) : rgba(shade(look.skin, -0.55), 0.9);
    ctx.beginPath();
    ctx.ellipse(0, -0.001, o.zombie ? 0.026 : 0.017, o.zombie ? 0.016 : 0.009, 0, 0, Math.PI * 2);
    ctx.fill();
    if (o.zombie) {
      ctx.fillStyle = rgba(p.line, 0.6);
      for (let i = 0; i < 3; i++) ctx.fillRect(-0.012 + i * 0.011, -0.005, 0.007, 0.006);
      ctx.strokeStyle = rgba(p.accent, 0.5);
      ctx.lineWidth = 0.005;
      ctx.beginPath();
      ctx.moveTo(0.021, -0.07);
      ctx.lineTo(0.034, -0.04);
      ctx.lineTo(0.028, -0.02);
      ctx.stroke();
    }
  }
  ctx.restore();

  // near leg
  const nearLegThigh = running ? -walk * 0.52 : -0.08;
  const nearLegKnee = running ? Math.max(0, walk) * 0.8 + 0.06 : 0.06;
  leg(0.055, nearLegThigh, nearLegKnee, running ? -0.12 : 0);

  // near arm
  const nearUpper =
    o.pose === "reach" ? 1.9 : o.pose === "push" ? 1.15 : o.pose === "wave" ? 2.2 : o.pose === "whisper" ? 0.9 : running ? walk * 0.9 : 0.14;
  armDraw(0.115, -0.77, nearUpper, 0.4, look.coat);

  if (o.pose === "whisper") {
    // hand near mouth
    ctx.fillStyle = look.skin;
    ctx.beginPath();
    ctx.arc(0.03, -0.84, 0.034, 0, Math.PI * 2);
    ctx.fill();
  }

  // cross-body bag for Mara
  if (o.member?.key === "mara" && !o.zombie && o.view !== "back") {
    ctx.strokeStyle = rgba(p.ink, 0.5);
    ctx.lineWidth = 0.012;
    ctx.beginPath();
    ctx.moveTo(-0.09, -0.79);
    ctx.lineTo(0.1, -0.54);
    ctx.stroke();
    ctx.fillStyle = look.bag;
    roundRect(ctx, 0.06, -0.55, 0.09, 0.1, 0.012);
    ctx.fill();
    if (outline > 0) {
      ctx.strokeStyle = rgba(p.ink, 0.8);
      ctx.lineWidth = outline * 0.6 / h;
      ctx.stroke();
    }
  }
  // backpack (Kai / back view)
  if (o.member?.key === "kai" && !o.zombie) {
    ctx.fillStyle = shade(look.accent, -0.2);
    roundRect(ctx, -0.085, -0.79, 0.17, 0.22, 0.035);
    ctx.fill();
    ctx.strokeStyle = rgba(p.ink, 0.55);
    ctx.lineWidth = 0.01;
    ctx.stroke();
    ctx.fillStyle = rgba(p.bg1, 0.4);
    ctx.fillRect(-0.055, -0.71, 0.11, 0.035);
  }
  // zombie arm forward
  if (o.zombie) {
    ctx.strokeStyle = look.coat;
    ctx.lineWidth = 0.058;
    ctx.beginPath();
    ctx.moveTo(facing * 0.11, -0.78);
    ctx.lineTo(facing * 0.24, -0.72);
    ctx.lineTo(facing * 0.34, -0.7);
    ctx.stroke();
    ctx.fillStyle = look.skin;
    ctx.beginPath();
    ctx.arc(facing * 0.35, -0.7, 0.03, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

interface BustOptions {
  x: number;
  y: number;
  size: number;
  member: CastMember;
  palette: Palette;
  style: StyleId;
  styleCfg: ResolvedStyle;
  t: number;
  mood: "fear" | "whisper" | "determined" | "zombie";
  facing?: 1 | -1;
  rim?: string;
  rimStrength?: number;
  alpha?: number;
}

export function drawBust(ctx: CanvasRenderingContext2D, o: BustOptions) {
  const p = o.palette;
  const look = o.mood === "zombie"
    ? { skin: p.zombie, hair: p.ink, coat: mixColor(p.zombie, p.near, 0.5), shirt: p.near, pants: p.near, accent: p.accent, bag: p.near }
    : castLook(o.member, p, o.style);
  const s = o.size;
  const facing = o.facing ?? 1;
  const wob = o.styleCfg.jitter;
  ctx.save();
  ctx.translate(o.x, o.y);
  ctx.scale(s, s);
  ctx.globalAlpha = o.alpha ?? 1;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const lw = (o.styleCfg.outline * 1.1) / 1000;
  const stroke = (w = 1) => {
    if (o.styleCfg.outline <= 0.2) return;
    ctx.lineWidth = lw * w;
    ctx.strokeStyle = o.mood === "zombie" ? rgba(p.ink, 0.9) : o.style === "minimal" || o.style === "sketch" ? p.line : p.ink;
    ctx.stroke();
  };

  // ambient halo
  const haloX = facing * 90;
  glow(ctx, haloX, -120, 480, o.rim ?? p.accent, (o.rimStrength ?? 0.32) * 0.6);

  // shoulders / coat
  ctx.fillStyle = look.coat;
  ctx.beginPath();
  ctx.moveTo(-360, 260);
  ctx.quadraticCurveTo(-310, 30, -190, -20);
  ctx.lineTo(190, -20);
  ctx.quadraticCurveTo(320, 40, 380, 260);
  ctx.closePath();
  ctx.fill();
  stroke(1.2);
  ctx.fillStyle = rgba(look.shirt, 0.9);
  ctx.beginPath();
  ctx.moveTo(-110, -10);
  ctx.lineTo(-20, 160);
  ctx.lineTo(50, 160);
  ctx.lineTo(140, -10);
  ctx.closePath();
  ctx.fill();
  // collar
  ctx.fillStyle = shade(look.coat, -0.2);
  poly(ctx, [
    [-190, -16],
    [-100, 20],
    [-150, 88],
    [-232, 26],
  ]);
  ctx.fill();
  stroke(0.8);
  poly(ctx, [
    [186, -18],
    [96, 22],
    [144, 90],
    [232, 20],
  ]);
  ctx.fill();
  stroke(0.8);

  // neck
  ctx.fillStyle = o.mood === "zombie" ? mixColor(p.zombie, p.ink, 0.2) : mixColor(look.skin, p.ink, 0.2);
  ctx.beginPath();
  ctx.moveTo(-58, 40);
  ctx.lineTo(-52, -176);
  ctx.lineTo(54, -176);
  ctx.lineTo(62, 40);
  ctx.closePath();
  ctx.fill();
  stroke(0.9);
  // jaw shadow under chin
  ctx.save();
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = p.ink;
  ctx.beginPath();
  ctx.ellipse(0, -178, 78, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // ears
  ctx.fillStyle = look.skin;
  ctx.beginPath();
  ctx.ellipse(-206, -320, 34, 56, -0.1, 0, Math.PI * 2);
  ctx.ellipse(206, -320, 34, 56, 0.1, 0, Math.PI * 2);
  ctx.fill();
  stroke(0.8);

  // head
  const headGrad = ctx.createLinearGradient(-180, -460, 180, -240);
  headGrad.addColorStop(0, shade(look.skin, 0.12));
  headGrad.addColorStop(0.56, look.skin);
  headGrad.addColorStop(1, shade(look.skin, -0.26));
  ctx.fillStyle = headGrad;
  ctx.beginPath();
  ctx.moveTo(-188, -384);
  ctx.bezierCurveTo(-200, -486, -108, -552, 0, -554);
  ctx.bezierCurveTo(112, -556, 198, -486, 192, -384);
  ctx.bezierCurveTo(186, -300, 120, -214, 42, -200);
  ctx.quadraticCurveTo(4, -194, -34, -201);
  ctx.bezierCurveTo(-114, -218, -180, -300, -188, -384);
  ctx.closePath();
  ctx.fill();
  stroke(1);

  // cheek / jaw shading
  ctx.save();
  ctx.globalAlpha = 0.16;
  ctx.fillStyle = p.ink;
  ctx.beginPath();
  ctx.ellipse(facing * 130, -272, 76, 98, facing * 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-facing * 156, -394, 34, 96, -facing * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // hair
  ctx.fillStyle = look.hair;
  if (o.mood === "zombie") {
    ctx.beginPath();
    ctx.ellipse(0, -470, 196, 112, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    for (let i = 0; i < 7; i++) {
      const bx = -170 + i * 56;
      ctx.beginPath();
      ctx.ellipse(bx, -476 + Math.sin(i) * 24, 42, 20, 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
    // scalp wounds
    ctx.strokeStyle = rgba(p.accent, 0.55);
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(58, -524);
    ctx.lineTo(96, -476);
    ctx.lineTo(74, -438);
    ctx.stroke();
  } else if (o.member.hairStyle === "curls") {
    for (let i = 0; i < 13; i++) {
      const a = Math.PI * (0.93 + (i / 13) * 1.15);
      const cx = Math.cos(a) * 180;
      const cy = -492 + Math.sin(a) * -64;
      ctx.beginPath();
      ctx.arc(cx, cy, 56 + (i % 4) * 10, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.ellipse(0, -505, 200, 116, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(facing * -160, -374, 48, 112, 0.16, 0, Math.PI * 2);
    ctx.fill();
  } else if (o.member.hairStyle === "beanie") {
    ctx.beginPath();
    ctx.ellipse(0, -475, 196, 122, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = look.accent;
    ctx.beginPath();
    ctx.ellipse(0, -510, 202, 140, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(-204, -528, 408, 54);
    ctx.fillStyle = rgba(p.ink, 0.22);
    for (let i = 0; i < 12; i++) ctx.fillRect(-190 + i * 34, -528, 11, 54);
    ctx.fillStyle = look.hair;
    ctx.beginPath();
    ctx.ellipse(facing * 140, -414, 64, 70, 0.2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.ellipse(0, -488, 202, 116, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(facing * 118, -466, 106, 56, -facing * 0.14, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(facing * -168, -420, 52, 82, 0.16, 0, Math.PI * 2);
    ctx.fill();
  }

  // eyes
  const eyeY = -364;
  const eyeGap = 84;
  const eyeW = o.mood === "zombie" ? 44 : 42;
  const eyeH = o.mood === "zombie" ? 20 : 24;
  if (o.mood === "zombie") {
    ctx.fillStyle = rgba(p.ink, 0.88);
    ctx.beginPath();
    ctx.ellipse(-eyeGap, eyeY, eyeW, eyeH, -0.1, 0, Math.PI * 2);
    ctx.ellipse(eyeGap, eyeY, eyeW, eyeH, 0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(p.line, 0.55);
    ctx.beginPath();
    ctx.arc(-eyeGap, eyeY, 8, 0, Math.PI * 2);
    ctx.arc(eyeGap, eyeY, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = rgba(p.ink, 0.45);
    ctx.lineWidth = 6;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(-150, -330 + i * 12);
      ctx.lineTo(-eyeGap + 30, -340 + i * 10);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(150, -330 + i * 12);
      ctx.lineTo(eyeGap - 30, -340 + i * 10);
      ctx.stroke();
    }
  } else {
    // eye sockets
    ctx.save();
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = p.ink;
    ctx.beginPath();
    ctx.ellipse(-eyeGap, eyeY - 4, eyeW + 20, eyeH + 20, -0.08, 0, Math.PI * 2);
    ctx.ellipse(eyeGap, eyeY - 4, eyeW + 20, eyeH + 20, 0.08, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    const wide = o.mood === "fear" ? 1.18 : o.mood === "whisper" ? 1.06 : 1;
    ctx.fillStyle = "#f4ece2";
    ctx.beginPath();
    ctx.ellipse(-eyeGap, eyeY, eyeW * wide, eyeH * wide, -0.06, 0, Math.PI * 2);
    ctx.ellipse(eyeGap, eyeY, eyeW * wide, eyeH * wide, 0.06, 0, Math.PI * 2);
    ctx.fill();
    const iris = facing * 8;
    ctx.fillStyle = mixColor(look.hair, "#5c4430", 0.4);
    ctx.beginPath();
    ctx.arc(-eyeGap + iris, eyeY + 2, 19, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(eyeGap + iris, eyeY + 2, 19, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = p.ink;
    ctx.beginPath();
    ctx.arc(-eyeGap + iris, eyeY + 2, 8.5, 0, Math.PI * 2);
    ctx.arc(eyeGap + iris, eyeY + 2, 8.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.beginPath();
    ctx.arc(-eyeGap + iris - 6, eyeY - 4, 4.4, 0, Math.PI * 2);
    ctx.arc(eyeGap + iris - 6, eyeY - 4, 4.4, 0, Math.PI * 2);
    ctx.fill();
    // rim reflection
    if (o.mood === "whisper" || o.mood === "fear") {
      ctx.fillStyle = rgba(o.rim ?? p.accent, 0.55);
      ctx.beginPath();
      ctx.arc(-eyeGap + iris + 6, eyeY + 4, 6, 0, Math.PI * 2);
      ctx.arc(eyeGap + iris + 6, eyeY + 4, 6, 0, Math.PI * 2);
      ctx.fill();
    }
    // upper lash
    ctx.strokeStyle = rgba(p.ink, 0.82);
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.ellipse(-eyeGap, eyeY, eyeW * wide, eyeH * wide, -0.06, Math.PI * 1.07, Math.PI * 1.93);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(eyeGap, eyeY, eyeW * wide, eyeH * wide, 0.06, Math.PI * 1.07, Math.PI * 1.93);
    ctx.stroke();
  }

  // brows
  ctx.strokeStyle = o.mood === "zombie" ? rgba(p.ink, 0.7) : shade(look.hair, -0.1);
  ctx.lineWidth = o.mood === "zombie" ? 9 : 13;
  ctx.beginPath();
  if (o.mood === "fear" || o.mood === "whisper") {
    ctx.moveTo(-150, -414);
    ctx.quadraticCurveTo(-86, -444, -28, -418);
    ctx.moveTo(28, -418);
    ctx.quadraticCurveTo(86, -446, 152, -416);
  } else if (o.mood === "determined") {
    ctx.moveTo(-150, -424);
    ctx.quadraticCurveTo(-80, -436, -24, -410);
    ctx.moveTo(24, -410);
    ctx.quadraticCurveTo(84, -438, 152, -426);
  } else {
    ctx.moveTo(-154, -420);
    ctx.quadraticCurveTo(-86, -436, -26, -414);
    ctx.moveTo(26, -414);
    ctx.quadraticCurveTo(86, -436, 154, -420);
  }
  ctx.stroke();

  // nose
  ctx.strokeStyle = rgba(shade(look.skin, -0.45), 0.6);
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(facing * 6, -360);
  ctx.quadraticCurveTo(facing * 18, -296, facing * -4, -282);
  ctx.stroke();
  ctx.fillStyle = rgba(p.ink, 0.45);
  ctx.beginPath();
  ctx.ellipse(facing * -16, -280, 9, 6, 0, 0, Math.PI * 2);
  ctx.ellipse(facing * 24, -282, 9, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  // nasolabial
  ctx.strokeStyle = rgba(shade(look.skin, -0.35), 0.25);
  ctx.lineWidth = 12;
  ctx.beginPath();
  ctx.moveTo(facing * 36, -300);
  ctx.quadraticCurveTo(facing * 74, -270, facing * 66, -234);
  ctx.stroke();

  // mouth
  const mouthY = -222;
  if (o.mood === "zombie") {
    ctx.fillStyle = rgba(p.ink, 0.9);
    ctx.beginPath();
    ctx.ellipse(facing * 16, mouthY, 72, 40, 0.08, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(p.line, 0.55);
    for (let i = 0; i < 5; i++) {
      ctx.fillRect(-38 + facing * 16 + i * 18, mouthY - 32, 10, 22);
    }
    ctx.strokeStyle = rgba(p.accent, 0.65);
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(facing * -6, mouthY + 30);
    ctx.lineTo(facing * 8, mouthY + 90);
    ctx.stroke();
  } else {
    const open = o.mood === "whisper" ? 14 : o.mood === "fear" ? 10 : 6;
    ctx.fillStyle = rgba(shade(look.skin, -0.5), 0.8);
    ctx.beginPath();
    ctx.ellipse(facing * 10, mouthY, 62, open + 6, 0.02, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(248,240,229,0.85)";
    ctx.fillRect(facing * 10 - 28, mouthY - open, 56, 5);
    ctx.strokeStyle = rgba(p.ink, 0.4);
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(facing * 10 - 42, mouthY + 2);
    ctx.quadraticCurveTo(facing * 10, mouthY + 12, facing * 10 + 44, mouthY);
    ctx.stroke();
    if (o.mood === "whisper") {
      ctx.strokeStyle = rgba(shade(look.skin, -0.4), 0.6);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(facing * 10 - 40, mouthY + 24);
      ctx.quadraticCurveTo(facing * 10, mouthY + 32, facing * 10 + 42, mouthY + 22);
      ctx.stroke();
    }
  }

  // sweat / grime
  if (o.mood !== "zombie") {
    ctx.fillStyle = rgba("#eaf4f2", 0.3);
    ctx.beginPath();
    ctx.ellipse(-facing * 130, -390, 10, 20, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(facing * 150, -330, 6, 13, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(p.ink, 0.1);
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.ellipse(-facing * (80 + i * 18), -260 + i * 16, 16, 8, 0.3, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // rim light
  const rim = o.rim ?? p.accent;
  if ((o.rimStrength ?? 0) > 0.05) {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.strokeStyle = rgba(rim, (o.rimStrength ?? 0.2) * 0.85);
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-188, -400);
    ctx.bezierCurveTo(-202, -490, -110, -554, 2, -556);
    ctx.bezierCurveTo(112, -558, 200, -486, 194, -382);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(196, -330);
    ctx.quadraticCurveTo(238, -100, 360, 180);
    ctx.stroke();
    ctx.restore();
  }

  // style-specific texture / linework
  if (o.style === "sketch" || wob > 1.3) {
    ctx.strokeStyle = rgba(p.line, 0.16);
    ctx.lineWidth = 2;
    for (let i = 0; i < 16; i++) {
      const yy = -520 + i * 28;
      ctx.beginPath();
      ctx.moveTo(-170 + Math.sin(i) * 16, yy);
      ctx.lineTo(-80 + Math.cos(i * 2) * 24, yy + 12);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* ------------------------------- 3D primitives ------------------------------ */

interface Proj {
  x: number;
  y: number;
  z: number;
}

function project3(v: Proj, fov = 4.2) {
  const p = fov / (fov + v.z);
  return { x: v.x * p, y: v.y * p, s: p };
}

function rotateVertex(v: Proj, rx: number, ry: number): Proj {
  const cy = Math.cos(ry);
  const sy = Math.sin(ry);
  const x1 = v.x * cy - v.z * sy;
  const z1 = v.x * sy + v.z * cy;
  const cx = Math.cos(rx);
  const sx = Math.sin(rx);
  const y1 = v.y * cx - z1 * sx;
  const z2 = v.y * sx + z1 * cx;
  return { x: x1, y: y1, z: z2 };
}

export interface PrimitiveOptions {
  x: number;
  y: number;
  size: number;
  rotX?: number;
  rotY?: number;
  color: string;
  palette: Palette;
  lightDir?: [number, number, number];
  outline?: number;
  alpha?: number;
  label?: string;
}

export function drawCube3D(ctx: CanvasRenderingContext2D, o: PrimitiveOptions) {
  const s = o.size;
  const rx = o.rotX ?? -0.2;
  const ry = o.rotY ?? 0.5;
  const verts: Proj[] = [];
  for (const x of [-0.5, 0.5]) for (const y of [-0.5, 0.5]) for (const z of [-0.5, 0.5]) verts.push({ x: x * s, y: y * s, z: z * s });
  const rotated = verts.map((v) => rotateVertex(v, rx, ry));
  const projected = rotated.map((v) => project3(v));
  const faces = [
    [0, 1, 3, 2],
    [4, 6, 7, 5],
    [0, 4, 5, 1],
    [2, 3, 7, 6],
    [0, 2, 6, 4],
    [1, 5, 7, 3],
  ];
  const light = o.lightDir ?? [-0.5, -0.9, -0.4];
  const order = faces
    .map((f, i) => ({ f, i, z: f.reduce((acc, vi) => acc + rotated[vi].z, 0) / 4 }))
    .sort((a, b) => a.z - b.z);
  ctx.save();
  ctx.globalAlpha = o.alpha ?? 1;
  ctx.translate(o.x, o.y);
  for (const { f } of order) {
    const raw = f.map((vi) => verts[vi]);
    const n = [raw[1].x - raw[0].x, raw[1].y - raw[0].y, raw[1].z - raw[0].z];
    const m = [raw[3].x - raw[0].x, raw[3].y - raw[0].y, raw[3].z - raw[0].z];
    const normal = [n[1] * m[2] - n[2] * m[1], n[2] * m[0] - n[0] * m[2], n[0] * m[1] - n[1] * m[0]];
    const len = Math.hypot(normal[0], normal[1], normal[2]) || 1;
    const dot = Math.abs((normal[0] * light[0] + normal[1] * light[1] + normal[2] * light[2]) / len);
    const color = shade(o.color, -0.18 + dot * 0.42);
    ctx.fillStyle = color;
    ctx.beginPath();
    f.forEach((vi, idx) => {
      const pt = projected[vi];
      if (idx === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.closePath();
    ctx.fill();
    if ((o.outline ?? 1) > 0) {
      ctx.strokeStyle = rgba(o.palette.ink, 0.75);
      ctx.lineWidth = (o.outline ?? 1) * 0.9;
      ctx.stroke();
    }
  }
  // top highlight
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = o.palette.glow;
  const top = faces[4].map((vi) => projected[vi]);
  ctx.beginPath();
  top.forEach((pt, idx) => (idx === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

export function drawCylinder3D(ctx: CanvasRenderingContext2D, o: PrimitiveOptions) {
  const w = o.size * 0.7;
  const h = o.size;
  ctx.save();
  ctx.globalAlpha = o.alpha ?? 1;
  ctx.translate(o.x, o.y);
  const g = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
  g.addColorStop(0, shade(o.color, -0.32));
  g.addColorStop(0.32, shade(o.color, 0.16));
  g.addColorStop(0.62, o.color);
  g.addColorStop(1, shade(o.color, -0.4));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(-w / 2, -h / 2);
  ctx.lineTo(-w / 2, h / 2);
  ctx.ellipse(0, h / 2, w / 2, h * 0.13, 0, Math.PI, 0, true);
  ctx.lineTo(w / 2, -h / 2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = shade(o.color, 0.2);
  ctx.beginPath();
  ctx.ellipse(0, -h / 2, w / 2, h * 0.13, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = rgba(o.palette.ink, 0.7);
  ctx.lineWidth = Math.max(0.5, (o.outline ?? 1) * 0.9);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(0, -h / 2, w / 2, h * 0.13, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = rgba(o.palette.glow, 0.18);
  ctx.beginPath();
  ctx.ellipse(-w * 0.14, -h * 0.08, w * 0.1, h * 0.36, -0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

export function drawSphere3D(ctx: CanvasRenderingContext2D, o: PrimitiveOptions) {
  const r = o.size * 0.5;
  ctx.save();
  ctx.translate(o.x, o.y);
  ctx.globalAlpha = o.alpha ?? 1;
  glow(ctx, 0, 0, r * 2.3, o.color, 0.4);
  ctx.fillStyle = radial(ctx, -r * 0.32, -r * 0.36, r * 0.08, r * 1.3, [
    [0, shade(o.color, 0.55)],
    [0.45, o.color],
    [1, shade(o.color, -0.55)],
  ]);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = rgba("#ffffff", 0.6);
  ctx.beginPath();
  ctx.ellipse(-r * 0.3, -r * 0.34, r * 0.17, r * 0.11, -0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = rgba(o.palette.ink, 0.6);
  ctx.lineWidth = Math.max(0.4, (o.outline ?? 1) * 0.7);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

/* ------------------------------- environment ------------------------------- */

export function skyline(
  ctx: CanvasRenderingContext2D,
  baseY: number,
  color: string,
  seed: number,
  scale = 1,
  lightColor?: string,
  alpha = 1
) {
  const rnd = seeded(seed);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  let x = -40;
  while (x < 1320) {
    const w = (24 + rnd() * 72) * scale;
    const h = (40 + rnd() * 220) * scale;
    ctx.fillRect(x, baseY - h, w, h + 400);
    if (lightColor && rnd() > 0.3) {
      ctx.fillStyle = rgba(lightColor, 0.12 + rnd() * 0.35);
      const cols = Math.max(1, Math.floor(w / (10 * scale)));
      const rows = Math.max(1, Math.floor(h / (16 * scale)));
      for (let c = 0; c < cols; c++) {
        for (let r = 0; r < rows; r++) {
          if (rnd() > 0.72) ctx.fillRect(x + 4 * scale + c * 10 * scale, baseY - h + 8 * scale + r * 16 * scale, 4 * scale, 5 * scale);
        }
      }
      ctx.fillStyle = color;
    }
    if (rnd() > 0.86) {
      const ah = 20 + rnd() * 60;
      ctx.fillRect(x + w * 0.4, baseY - h - ah, 3, ah);
      if (lightColor) {
        ctx.fillStyle = rgba("#ff4a38", 0.8);
        ctx.fillRect(x + w * 0.4 - 1, baseY - h - ah, 5, 4);
        ctx.fillStyle = color;
      }
    }
    x += w + 4 + rnd() * 12;
  }
  ctx.restore();
}

export function car(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  color: string,
  p: Palette,
  o: { facing?: 1 | -1; alarm?: boolean; headlights?: boolean; alpha?: number; outline?: number; t?: number; driver?: string } = {}
) {
  const facing = o.facing ?? 1;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing * scale, scale);
  ctx.globalAlpha = o.alpha ?? 1;
  // shadow
  ctx.fillStyle = rgba(p.shadow, 0.55);
  ctx.beginPath();
  ctx.ellipse(0, 30, 105, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  // headlight beam
  if (o.headlights) {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    const g = ctx.createLinearGradient(80, 0, 360, 0);
    g.addColorStop(0, rgba(p.glow, 0.5));
    g.addColorStop(1, rgba(p.glow, 0));
    ctx.fillStyle = g;
    poly(ctx, [
      [82, -2],
      [360, -52],
      [360, 48],
      [82, 14],
    ]);
    ctx.fill();
    ctx.restore();
  }
  // body
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(-105, 0);
  ctx.lineTo(-92, -32);
  ctx.lineTo(-44, -38);
  ctx.lineTo(-12, -78);
  ctx.quadraticCurveTo(24, -84, 50, -76);
  ctx.lineTo(84, -36);
  ctx.lineTo(102, -28);
  ctx.quadraticCurveTo(114, -12, 106, 10);
  ctx.lineTo(88, 20);
  ctx.lineTo(-88, 20);
  ctx.closePath();
  ctx.fill();
  if ((o.outline ?? 1) > 0) {
    ctx.strokeStyle = rgba(p.ink, 0.85);
    ctx.lineWidth = Math.max(1, (o.outline ?? 1) * 1.1);
    ctx.stroke();
  }
  // roof gradient
  ctx.fillStyle = rgba(p.glow, 0.12);
  ctx.beginPath();
  ctx.moveTo(-86, -32);
  ctx.lineTo(80, -33);
  ctx.lineTo(66, -16);
  ctx.lineTo(-80, -14);
  ctx.closePath();
  ctx.fill();
  // windows
  ctx.fillStyle = rgba(p.bg1, 0.82);
  poly(ctx, [
    [-36, -40],
    [-8, -72],
    [16, -73],
    [16, -40],
  ]);
  ctx.fill();
  poly(ctx, [
    [24, -72],
    [46, -68],
    [76, -38],
    [24, -40],
  ]);
  ctx.fill();
  // windshield shine
  ctx.strokeStyle = rgba(p.glow, 0.28);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-14, -68);
  ctx.lineTo(40, -46);
  ctx.stroke();
  // driver
  if (o.driver) {
    ctx.fillStyle = p.ink;
    ctx.beginPath();
    ctx.arc(40, -54, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(31, -48, 19, 15);
  }
  // lights
  ctx.fillStyle = o.headlights ? p.glow : rgba(p.glow, 0.5);
  ctx.fillRect(98, -18, 9, 10);
  ctx.fillStyle = o.alarm ? p.accent : rgba(p.accent, 0.8);
  ctx.fillRect(-108, -18, 9, 10);
  // wheels
  ctx.fillStyle = p.ink;
  for (const wx of [-66, 68]) {
    ctx.beginPath();
    ctx.arc(wx, 20, 21, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(p.line, 0.18);
    ctx.beginPath();
    ctx.arc(wx, 20, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = p.ink;
  }
  ctx.restore();
  if (o.alarm) {
    const flash = Math.sin((o.t ?? 0) * 22) > 0;
    glow(ctx, x - 110 * scale * facing, y - 18 * scale, 110 * scale, flash ? p.accent : p.cool, 0.55);
    glow(ctx, x + 100 * scale * facing, y - 18 * scale, 90 * scale, flash ? p.accent2 : p.accent, 0.3);
  }
  return { front: [x + 105 * scale * facing, y - 18 * scale] as [number, number], rear: [x - 105 * scale * facing, y - 18 * scale] as [number, number] };
}

export function sign(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  text: string,
  p: Palette,
  o: { color?: string; bg?: string; size?: number; align?: "center" | "left"; rotate?: number } = {}
) {
  ctx.save();
  ctx.translate(x, y);
  if (o.rotate) ctx.rotate(o.rotate);
  ctx.fillStyle = o.bg ?? rgba(p.ink, 0.75);
  roundRect(ctx, 0, 0, w, h, 3);
  ctx.fill();
  ctx.strokeStyle = rgba(p.line, 0.15);
  ctx.stroke();
  ctx.fillStyle = o.color ?? rgba(p.line, 0.7);
  ctx.font = `600 ${o.size ?? 10}px "JetBrains Mono", monospace`;
  ctx.textAlign = o.align ?? "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text.toUpperCase(), (o.align ?? "center") === "center" ? w / 2 : 8, h / 2 + 1);
  ctx.restore();
}
