import {
  CAST,
  FILM_DURATION,
  SHOTS,
  VIRTUAL_H,
  VIRTUAL_W,
  activeDialogue,
  shotAt,
  type CastMember,
  type Dialogue,
  type MoodId,
  type Shot,
  type StyleId,
} from "./data";
import {
  type Palette,
  type ResolvedStyle,
  type ActorPose,
  clamp,
  easeOut,
  grad,
  grainTile,
  lerp,
  mixColor,
  paletteFor,
  radial,
  rgba,
  resolveStyle,
  roundRect,
  seeded,
  shade,
  smooth,
  car,
  drawActor,
  drawBust,
  drawCube3D,
  drawCylinder3D,
  drawSphere3D,
  dust,
  glow,
  lightCone,
  poly,
  rain,
  sign,
  skyline,
  smokePlume,
  speedLines,
  sunRays,
  vignette,
} from "./art";

export interface GradingSettings {
  saturation: number;
  contrast: number;
  brightness: number;
  temperature: number;
  tint: string;
  tintStrength: number;
}

export interface CameraSettings {
  auto: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  fov: number;
  shake: number;
  speed: number;
}

export interface CustomSettings {
  outline: number;
  texture: number;
  detail: number;
  character: number;
  wobble: number;
  wobbleSpeed: number;
  envWobble: number;
}

export interface FxSettings {
  bloom: number;
  rays: boolean;
  fog: boolean;
  rain: boolean;
  particles: boolean;
  grain: boolean;
  letterbox: boolean;
  shadows: boolean;
  threeD: boolean;
  subtitles: boolean;
  speedFx: boolean;
  light: number;
}

export interface EngineSettings {
  styleId: StyleId;
  mood: MoodId | null;
  grade: GradingSettings;
  camera: CameraSettings;
  custom: CustomSettings;
  fx: FxSettings;
}

export const DEFAULT_SETTINGS: EngineSettings = {
  styleId: "claude",
  mood: null,
  grade: { saturation: 0.94, contrast: 1.1, brightness: 0.97, temperature: 0.16, tint: "#ff6a3d", tintStrength: 0.12 },
  camera: { auto: true, x: 0, y: 0, z: 2, yaw: 0, pitch: 0, roll: 0, fov: 46, shake: 0.3, speed: 1 },
  custom: { outline: 1, texture: 0.7, detail: 0.9, character: 1, wobble: 0.65, wobbleSpeed: 1, envWobble: 0.7 },
  fx: {
    bloom: 0.62,
    rays: true,
    fog: true,
    rain: true,
    particles: true,
    grain: true,
    letterbox: false,
    shadows: true,
    threeD: true,
    subtitles: true,
    speedFx: true,
    light: 1,
  },
};

export interface CameraState {
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  fov: number;
  shakeX: number;
  shakeY: number;
  shake: number;
}

export interface RadarObject {
  label: string;
  type: "cast" | "zombie" | "prop3d" | "vehicle" | "camera" | "environment";
  x: number;
  y: number;
  z: number;
  size: number;
}

export interface Telemetry {
  time: number;
  shotId: string;
  shotIndex: number;
  totalShots: number;
  title: string;
  scene: string;
  focus: "wide" | "medium" | "close";
  camera: CameraState;
  objects: RadarObject[];
  duration: number;
  fov: number;
  layerBands: { name: string; z: number; color: string }[];
  crop: string;
}

interface SceneState {
  ctx: CanvasRenderingContext2D;
  time: number;
  local: number;
  progress: number;
  shot: Shot;
  cam: CameraState;
  palette: Palette;
  styleCfg: ResolvedStyle;
  settings: EngineSettings;
  styleId: StyleId;
  dialogue?: Dialogue;
}

const TAU = Math.PI * 2;
const W = VIRTUAL_W;
const H = VIRTUAL_H;

function member(key: "mara" | "eli" | "kai"): CastMember {
  return CAST.find((c) => c.key === key) ?? CAST[0];
}

function lerpAngle(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function resolveCamera(shot: Shot, time: number, settings: EngineSettings): CameraState {
  const keys = shot.camera;
  const local = clamp((time - shot.start) / Math.max(0.001, shot.end - shot.start));
  let a = keys[0];
  let b = keys[keys.length - 1];
  for (let i = 0; i < keys.length - 1; i++) {
    if (local >= keys[i].at && local <= keys[i + 1].at) {
      a = keys[i];
      b = keys[i + 1];
      break;
    }
  }
  const span = Math.max(0.0001, b.at - a.at);
  const raw = clamp((local - a.at) / span);
  const t = shot.kind === "whip" || shot.kind === "runback" || shot.kind === "dive" ? easeOut(raw) : smooth(raw);
  const base = {
    x: lerp(a.x, b.x, t),
    y: lerp(a.y, b.y, t),
    z: lerp(a.z, b.z, t),
    yaw: lerpAngle(a.yaw, b.yaw, t),
    pitch: lerpAngle(a.pitch, b.pitch, t),
    roll: lerpAngle(a.roll, b.roll, t),
    fov: lerp(a.fov, b.fov, t),
  };
  const active = settings.camera.auto ? base : settings.camera;
  const shakeBase = (shot.mood === "action" ? 1 : 0.4) * (settings.camera.shake / 100) * 8;
  const shake = (active === base ? shakeBase : settings.camera.shake / 100) * (shot.focus === "wide" ? 1.4 : 0.7);
  return {
    x: active.x,
    y: active.y,
    z: active.z,
    yaw: active.yaw,
    pitch: active.pitch,
    roll: "roll" in active ? active.roll : 0,
    fov: active.fov,
    shakeX: Math.sin(time * 17.3) * shake + Math.sin(time * 7.1) * shake * 0.4,
    shakeY: Math.cos(time * 13.7) * shake * 0.8 + Math.sin(time * 3.7) * shake * 0.3,
    shake,
  };
}

export class FilmEngine {
  private grain: HTMLCanvasElement | null = null;
  private lastTelemetry: Telemetry | null = null;

  constructor() {
    this.grain = grainTile(190);
  }

  palette(settings: EngineSettings) {
    return paletteFor(settings.styleId);
  }

  styleConfig(settings: EngineSettings): ResolvedStyle {
    return resolveStyle(settings.styleId, settings.custom.outline);
  }

  /** Draws one deterministic film frame into any 2D context. */
  render(ctx: CanvasRenderingContext2D, width: number, height: number, time: number, settings: EngineSettings) {
    const t = clamp(time, 0, FILM_DURATION - 0.0001);
    const shot = shotAt(t);
    const palette = this.palette(settings);
    const styleCfg = this.styleConfig(settings);
    const cam = resolveCamera(shot, t, settings);
    const state: SceneState = {
      ctx,
      time: t,
      local: t - shot.start,
      progress: clamp((t - shot.start) / Math.max(0.001, shot.end - shot.start)),
      shot,
      cam,
      palette,
      styleCfg,
      settings,
      styleId: settings.styleId,
      dialogue: activeDialogue(t),
    };

    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#050608";
    ctx.fillRect(0, 0, width, height);
    const fit = Math.min(width / W, height / H);
    const offsetX = (width - W * fit) / 2;
    const offsetY = (height - H * fit) / 2;
    ctx.translate(offsetX, offsetY);
    ctx.scale(fit, fit);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    ctx.save();
    const g = settings.grade;
    ctx.filter = `saturate(${g.saturation}) contrast(${g.contrast}) brightness(${g.brightness})`;
    this.drawScene(state);
    ctx.filter = "none";
    this.drawGrade(state);
    ctx.restore();

    this.drawTransitions(state);
    this.drawAtmosphere(state);
    if (settings.fx.grain) this.drawGrain(state);
    this.drawVignetteAndFrame(state);
    if (settings.fx.subtitles) this.drawSubtitle(state);
    if (settings.fx.letterbox) {
      const bh = 44;
      ctx.fillStyle = "#030405";
      ctx.fillRect(0, 0, W, bh);
      ctx.fillRect(0, H - bh, W, bh);
    }
    this.drawStyleSignature(state);
    ctx.restore();
    this.lastTelemetry = this.buildTelemetry(t, shot, cam, settings);
  }

  getTelemetry(): Telemetry {
    return this.lastTelemetry ?? this.telemetryAt(0, DEFAULT_SETTINGS);
  }

  telemetryAt(time: number, settings: EngineSettings): Telemetry {
    const t = clamp(time, 0, FILM_DURATION - 0.0001);
    const shot = shotAt(t);
    const cam = resolveCamera(shot, t, settings);
    return this.buildTelemetry(t, shot, cam, settings);
  }

  /* --------------------------------- helpers -------------------------------- */

  private layer(s: SceneState, depth: number, fn: () => void) {
    const { ctx, cam } = s;
    const par = clamp(1.28 - depth, 0.18, 1.25);
    const dolly = 1 + (cam.z - 2) * 0.028 * (0.7 + (1 - depth) * 0.5);
    ctx.save();
    ctx.translate(W / 2 + cam.shakeX * par, H / 2 + cam.shakeY * par + cam.pitch * 1.5 * par);
    ctx.rotate((cam.roll * Math.PI) / 180 * par * 0.65);
    ctx.scale(dolly, dolly);
    ctx.translate(-W / 2 - cam.x * 38 * par - cam.yaw * par * 2.2, -H / 2 - cam.y * 30 * par);
    fn();
    ctx.restore();
  }

  private sky(s: SceneState, top?: string, bottom?: string) {
    const p = s.palette;
    const { ctx } = s;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [
      [0, top ?? p.bg1],
      [0.62, p.bg2],
      [1, bottom ?? p.bg2],
    ]);
    ctx.fillRect(0, 0, W, H);
  }

  private brickPattern(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string, seed = 4) {
    const rnd = seeded(seed);
    ctx.save();
    ctx.strokeStyle = rgba(color, 0.18);
    ctx.lineWidth = 1;
    for (let yy = y; yy < y + h; yy += 16) {
      ctx.beginPath();
      ctx.moveTo(x, yy);
      ctx.lineTo(x + w, yy);
      ctx.stroke();
      const offset = Math.floor((yy - y) / 16) % 2 ? 18 : 0;
      for (let xx = x + offset; xx < x + w; xx += 36) {
        if (rnd() > 0.2) {
          ctx.beginPath();
          ctx.moveTo(xx, yy);
          ctx.lineTo(xx, yy + 16);
          ctx.stroke();
        }
      }
    }
    ctx.restore();
  }

  private streetLamps(ctx: CanvasRenderingContext2D, p: Palette, t: number, y = 360, xs = [180, 470, 790, 1100]) {
    xs.forEach((x, i) => {
      const flicker = 0.7 + Math.sin(t * 6 + i * 4) * 0.18;
      ctx.strokeStyle = rgba(p.ink, 0.9);
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(x, y + 260);
      ctx.lineTo(x, y - 40);
      ctx.quadraticCurveTo(x + 2, y - 66, x + 32, y - 66);
      ctx.stroke();
      ctx.fillStyle = rgba(p.glow, 0.9);
      ctx.beginPath();
      ctx.arc(x + 34, y - 64, 6, 0, TAU);
      ctx.fill();
      glow(ctx, x + 34, y - 64, 150, p.glow, 0.32 * flicker);
    });
  }

  private papers(ctx: CanvasRenderingContext2D, p: Palette, t: number, n = 16, seed = 9) {
    const rnd = seeded(seed);
    for (let i = 0; i < n; i++) {
      const x = rnd() * W;
      const base = H * (0.55 + rnd() * 0.4);
      const y = base - ((t * (8 + rnd() * 18) + rnd() * 400) % (H * 0.42));
      const rot = t * (1 + rnd() * 2) + rnd() * 6;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.fillStyle = rgba(p.line, 0.14 + rnd() * 0.16);
      ctx.fillRect(-3, -2, 7 + rnd() * 6, 3);
      ctx.restore();
    }
  }

  private actor(
    s: SceneState,
    key: "mara" | "eli" | "kai",
    x: number,
    y: number,
    scale: number,
    pose: ActorPose,
    facing: 1 | -1 = 1,
    view: "front" | "back" | "side" = "front",
    phase = 0,
    alpha = 1,
    expression: "fear" | "determined" | "shock" | "calm" = "fear"
  ) {
    drawActor(s.ctx, {
      x,
      y,
      scale: scale * (0.9 + s.settings.custom.character * 0.1),
      member: member(key),
      pose,
      view,
      facing,
      t: s.time,
      phase,
      palette: s.palette,
      style: s.styleId,
      styleCfg: s.styleCfg,
      expression,
      wobble: s.settings.custom.wobble,
      wobbleSpeed: s.settings.custom.wobbleSpeed,
      alpha,
    });
  }

  private zombie(
    s: SceneState,
    x: number,
    y: number,
    scale: number,
    facing: 1 | -1 = 1,
    alpha = 1,
    phase = 0,
    view: "front" | "back" | "side" = "front"
  ) {
    drawActor(s.ctx, {
      x,
      y,
      scale,
      member: member("mara"),
      pose: "reach",
      view,
      facing,
      t: s.time + phase,
      phase,
      palette: s.palette,
      style: s.styleId,
      styleCfg: s.styleCfg,
      expression: "shock",
      zombie: true,
      wobble: s.settings.custom.wobble,
      wobbleSpeed: s.settings.custom.wobbleSpeed,
      alpha,
      silhouette: true,
    });
  }

  private horde(cm: CanvasRenderingContext2D, palette: Palette, x: number, y: number, n: number, t: number, spread = 320, scale = 1, color?: string) {
    const rnd = seeded(41);
    for (let i = 0; i < n; i++) {
      const px = x + (rnd() - 0.5) * spread;
      const py = y + (rnd() - 0.5) * 24;
      const sc = scale * (0.5 + rnd() * 0.7);
      const sway = Math.sin(t * 2.4 + i * 1.3) * 3;
      cm.save();
      cm.fillStyle = color ?? rgba(palette.ink, 0.74);
      cm.translate(px + sway, py);
      cm.beginPath();
      cm.ellipse(0, -sc * 52, sc * 12, sc * 14, 0.15, 0, TAU);
      cm.fill();
      cm.beginPath();
      cm.moveTo(-sc * 15, -sc * 38);
      cm.quadraticCurveTo(-sc * 20, -sc * 6, -sc * 10, 0);
      cm.lineTo(sc * 13, 0);
      cm.quadraticCurveTo(sc * 19, -sc * 8, sc * 14, -sc * 38);
      cm.closePath();
      cm.fill();
      cm.strokeStyle = color ?? rgba(palette.ink, 0.74);
      cm.lineWidth = sc * 7;
      cm.beginPath();
      cm.moveTo(sc * 10, -sc * 34);
      cm.lineTo(sc * 26, -sc * 40 + Math.sin(t * 3 + i) * sc * 4);
      cm.stroke();
      cm.restore();
    }
    // atmospheric red eyes in the dark
    const rnd2 = seeded(17 + n);
    for (let i = 0; i < Math.floor(n / 3); i++) {
      const ex = x + (rnd2() - 0.5) * spread;
      const ey = y - 44 - rnd2() * 20;
      glow(cm, ex, ey, 9, palette.accent, 0.35 + Math.sin(t * 3 + i) * 0.1);
    }
  }

  /* ---------------------------------- grade --------------------------------- */

  private drawGrade(s: SceneState) {
    const { ctx } = s;
    const g = s.settings.grade;
    const mood = s.settings.mood ?? s.shot.mood;
    const moodTint =
      mood === "action"
        ? "#ff6a3d"
        : mood === "suspense"
        ? "#df4b3c"
        : mood === "mysterious"
        ? "#8a76cf"
        : mood === "sad"
        ? "#6b8dad"
        : mood === "peaceful"
        ? "#9db999"
        : "#f0b45c";
    ctx.save();
    ctx.globalCompositeOperation = "soft-light";
    ctx.globalAlpha = 0.34;
    ctx.fillStyle = grad(ctx, 0, 0, W, H, [
      [0, rgba(paletteFor(s.settings.styleId).bg1, 0.4)],
      [0.48, rgba(moodTint, 0.22)],
      [1, rgba(g.tint, g.tintStrength * 1.4)],
    ]);
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = "overlay";
    ctx.globalAlpha = 0.14 + g.temperature * 0.16;
    ctx.fillStyle = g.temperature >= 0 ? grad(ctx, W, 0, 0, 0, [[0, "#ff8a4c"], [1, "rgba(255,138,76,0)"]]) : grad(ctx, W, 0, 0, 0, [[0, "rgba(86,156,210,0)"], [1, "#569cd2"]]);
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    // slight cold shadow lift
    if (s.styleId === "cinematic" || s.styleId === "claude") {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = 0.055;
      ctx.fillStyle = radial(ctx, W * 0.2, H * 0.1, 10, W * 0.9, [[0, moodTint], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  private drawGrain(s: SceneState) {
    const { ctx } = s;
    if (!this.grain) return;
    const strength = s.palette.light ? 0.11 : 0.16;
    ctx.save();
    ctx.globalAlpha = strength * s.settings.custom.texture;
    ctx.globalCompositeOperation = s.palette.light ? "multiply" : "overlay";
    const rnd = seeded(21 + Math.floor(s.time * 24));
    const ox = -rnd() * 180;
    const oy = -rnd() * 180;
    const pattern = ctx.createPattern(this.grain, "repeat");
    if (pattern) {
      ctx.translate(ox, oy);
      ctx.fillStyle = pattern;
      ctx.fillRect(0, 0, W + 200, H + 200);
    }
    ctx.restore();
    if (s.styleId === "sketch") {
      ctx.save();
      ctx.strokeStyle = rgba(s.palette.line, 0.055);
      ctx.lineWidth = 1;
      for (let y = 0; y < H; y += 9) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y + Math.sin(y) * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private drawVignetteAndFrame(s: SceneState) {
    const { ctx } = s;
    vignette(ctx, W, H, s.styleId === "minimal" || s.styleId === "sketch" ? 0.25 : 0.72, s.palette.shadow);
    if (s.styleId === "minimal") {
      ctx.strokeStyle = rgba(s.palette.line, 0.35);
      ctx.lineWidth = 1.5;
      ctx.strokeRect(34, 34, W - 68, H - 68);
    }
    if (s.styleId === "experimental") {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = 0.2;
      const t = s.time;
      for (let i = 0; i < 7; i++) {
        const y = ((t * 190 + i * 127) % H) | 0;
        ctx.fillStyle = i % 2 ? rgba(s.palette.accent, 0.35) : rgba(s.palette.accent2, 0.3);
        ctx.fillRect(0, y, W, 1.5 + (i % 3));
      }
      ctx.restore();
    }
  }

  private drawSubtitle(s: SceneState) {
    if (!s.dialogue) return;
    const { ctx } = s;
    const line = s.dialogue;
    const fadeIn = smooth(clamp((s.time - line.start) / 0.14));
    const fadeOut = smooth(clamp((line.end - s.time) / 0.18));
    const a = Math.min(fadeIn, fadeOut);
    const isNarration = line.kind === "narration";
    const speakerColor = isNarration ? s.palette.cool : s.palette.accent;
    const p = s.palette;
    ctx.save();
    ctx.globalAlpha = a;
    ctx.fillStyle = grad(ctx, 0, H - 170, 0, H, [
      [0, "rgba(3,5,6,0)"],
      [1, "rgba(3,5,6,0.78)"],
    ]);
    ctx.fillRect(0, H - 170, W, 170);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const label = isNarration ? "NARRATION" : line.speaker;
    ctx.font = `600 11px "JetBrains Mono", monospace`;
    ctx.fillStyle = speakerColor;
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "3px";
    ctx.fillText(label, W / 2, H - 82);
    ctx.font = `500 27px "Instrument Sans", sans-serif`;
    ctx.fillStyle = "rgba(245,241,232,0.97)";
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "-0.2px";
    // soft shadow for legibility
    ctx.shadowColor = "rgba(0,0,0,0.85)";
    ctx.shadowBlur = 16;
    ctx.fillText(line.text, W / 2, H - 50);
    ctx.shadowBlur = 0;
    ctx.strokeStyle = rgba(speakerColor, 0.7);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 135, H - 102);
    ctx.lineTo(W / 2 - 118, H - 102);
    ctx.moveTo(W / 2 + 118, H - 102);
    ctx.lineTo(W / 2 + 135, H - 102);
    ctx.stroke();
    if (isNarration) {
      ctx.fillStyle = rgba(p.line, 0.35);
      ctx.font = `400 9px "JetBrains Mono", monospace`;
      ctx.fillText("THE LAST 15 SECONDS · 06:12", W / 2, H - 24);
    }
    ctx.restore();
  }

  private drawStyleSignature(s: SceneState) {
    const { ctx } = s;
    if (s.styleId === "minimal") {
      ctx.save();
      ctx.fillStyle = rgba(s.palette.line, 0.65);
      ctx.font = `500 9px "JetBrains Mono", monospace`;
      ctx.textAlign = "right";
      ctx.fillText("2.5D / MINIMAL", W - 46, H - 40);
      ctx.restore();
    }
  }
  /* --------------------------------- scenes --------------------------------- */

  private drawScene(s: SceneState) {
    switch (s.shot.kind) {
      case "aerial":
        this.cityGrid(s, false);
        break;
      case "chaos":
        this.cityGrid(s, true);
        break;
      case "dive":
        this.cityDive(s);
        break;
      case "screen":
        this.broadcast(s);
        break;
      case "street":
        this.streetScene(s);
        break;
      case "emerge":
        this.emergeScene(s);
        break;
      case "bag":
        this.bagScene(s);
        break;
      case "zombie":
        this.zombieClose(s);
        break;
      case "whip":
        this.whipScene(s);
        break;
      case "alley":
        this.alleyScene(s);
        break;
      case "door":
        this.doorScene(s);
        break;
      case "hallway":
        this.hallwayScene(s);
        break;
      case "shadow":
        this.shadowScene(s);
        break;
      case "horde":
        this.hordeScene(s);
        break;
      case "window":
        this.windowScene(s);
        break;
      case "alarm":
        this.alarmScene(s);
        break;
      case "engine":
        this.engineScene(s);
        break;
      case "drive":
        this.driveScene(s);
        break;
      case "bridge":
        this.bridgeScene(s, "blocked");
        break;
      case "sacrifice":
        this.bridgeScene(s, "sacrifice");
        break;
      case "realization":
        this.realizationScene(s);
        break;
      case "obstacle":
        this.obstacleScene(s);
        break;
      case "runback":
        this.runbackScene(s);
        break;
      case "escape":
        this.bridgeScene(s, "escape");
        break;
      case "shelter":
        this.shelterScene(s);
        break;
      case "glass":
        this.glassScene(s);
        break;
      case "whisper":
        this.whisperScene(s);
        break;
      case "blackout":
        this.blackoutScene(s);
        break;
      case "title":
        this.titleScene(s);
        break;
      default:
        break;
    }
  }

  /* ------------------------------- city scenes ------------------------------- */

  private cityGrid(s: SceneState, chaos: boolean) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [
      [0, chaos ? mixColor(p.bg1, "#2a1410", 0.4) : p.bg1],
      [1, chaos ? mixColor(p.bg2, "#402017", 0.32) : p.bg2],
    ]);
    ctx.fillRect(0, 0, W, H);

    this.layer(s, 0.95, () => {
      ctx.save();
      ctx.translate(-s.cam.x * 18, -s.cam.y * 12);
      // street grid
      ctx.strokeStyle = mixColor(p.ink, p.road, 0.55);
      ctx.lineWidth = 58;
      for (let i = 0; i < 5; i++) {
        const y = 80 + i * 172;
        ctx.beginPath();
        ctx.moveTo(-80 + cam(i), y);
        ctx.lineTo(W + 80, y + 30);
        ctx.stroke();
      }
      for (let i = 0; i < 7; i++) {
        const x = -60 + i * 208;
        ctx.beginPath();
        ctx.moveTo(x, -40);
        ctx.lineTo(x + 120 + cam(i), H + 40);
        ctx.stroke();
      }
      // road markings
      ctx.setLineDash([18, 24]);
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
        const y = 80 + i * 172;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y + 30);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      ctx.restore();

      function cam(i: number) {
        return Math.sin(i * 3.2) * 30;
      }

      // city blocks
      const rnd = seeded(chaos ? 71 : 33);
      const rows = 5;
      const cols = 7;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const cw = 126 + rnd() * 46;
          const ch = 88 + rnd() * 52;
          const bx = c * 202 + (r % 2) * 40 - 92 + rnd() * 14;
          const by = r * 166 + 2 + rnd() * 12;
          const depthShade = 0.04 + r * 0.035;
          const base = chaos
            ? mixColor(p.mid, "#22120d", 0.66 + r * 0.04)
            : mixColor(p.mid, p.ink, 0.3 + r * 0.04 + (c % 3) * 0.035);
          // shadow
          ctx.fillStyle = rgba(p.shadow, 0.65);
          roundRect(ctx, bx + 20, by + 26, cw, ch, 8);
          ctx.fill();
          // block
          ctx.fillStyle = shade(base, depthShade);
          roundRect(ctx, bx, by, cw, ch, 5);
          ctx.fill();
          // roof rim light
          ctx.strokeStyle = rgba(chaos ? p.accent : p.line, 0.16);
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(bx + 4, by + 1);
          ctx.lineTo(bx + cw - 4, by + 1);
          ctx.moveTo(bx + 1, by + 4);
          ctx.lineTo(bx + 1, by + ch - 4);
          ctx.stroke();
          if (s.styleCfg.outline > 0.4) {
            ctx.strokeStyle = rgba(p.ink, 0.55);
            ctx.lineWidth = Math.max(0.5, s.styleCfg.outline * 0.4);
            roundRect(ctx, bx, by, cw, ch, 5);
            ctx.stroke();
          }
          // roof lip
          ctx.fillStyle = rgba(p.line, 0.045 + r * 0.012);
          roundRect(ctx, bx + 5, by + 5, cw - 10, ch - 12, 3);
          ctx.fill();
          // rooftop details
          const rnd2 = seeded(c + r * 13 + (chaos ? 9 : 0) + 4);
          // inset light court
          ctx.fillStyle = rgba(p.ink, 0.16);
          roundRect(ctx, bx + cw * 0.52, by + ch * 0.5, cw * 0.36, ch * 0.34, 4);
          ctx.fill();
          for (let k = 0; k < 3; k++) {
            const vx = bx + 12 + rnd2() * (cw - 34);
            const vy = by + 12 + rnd2() * (ch - 30);
            ctx.fillStyle = rgba(p.ink, 0.3);
            ctx.fillRect(vx, vy, 16 + rnd2() * 14, 10 + rnd2() * 8);
            ctx.fillStyle = rgba(p.line, 0.12);
            ctx.fillRect(vx, vy, 16 + rnd2() * 14, 1.5);
          }
          // water tower / antenna
          if (rnd2() > 0.55) {
            ctx.fillStyle = rgba(p.ink, 0.5);
            ctx.beginPath();
            ctx.arc(bx + cw * 0.6, by + ch * 0.34, 9, 0, TAU);
            ctx.fill();
          }
          if (rnd2() > 0.7) {
            ctx.strokeStyle = rgba(p.line, 0.18);
            ctx.beginPath();
            ctx.moveTo(bx + cw * 0.8, by + ch * 0.7);
            ctx.lineTo(bx + cw * 0.8, by + ch * 0.7 - 22);
            ctx.stroke();
          }
          // rooftop emergency lights
          if (chaos || rnd2() > 0.72) {
            const blink = 0.5 + Math.sin(t * 4 + c + r) * 0.4;
            glow(ctx, bx + 10, by + 8, 40, rnd2() > 0.5 ? p.accent : p.cool, 0.34 * blink);
            ctx.fillStyle = rnd2() > 0.5 ? p.accent : p.cool;
            ctx.beginPath();
            ctx.arc(bx + 10, by + 8, 2.4, 0, TAU);
            ctx.fill();
          }
        }
      }

      // tiny traffic
      const trnd = seeded(chaos ? 13 : 8);
      for (let i = 0; i < 30; i++) {
        const lane = Math.floor(trnd() * 5);
        const yOff = 16 + trnd() * 34;
        const y = 80 + lane * 172 + yOff;
        const speed = 24 + trnd() * 70;
        const dir = trnd() > 0.5 ? 1 : -1;
        const x = ((trnd() * W + t * speed * dir) % W + W) % W;
        const parked = chaos && trnd() > 0.62;
        const vx = parked ? trnd() * W : x;
        const vy = parked ? y + 22 : y;
        ctx.save();
        ctx.translate(vx, vy);
        ctx.rotate(parked ? (trnd() - 0.5) * 0.5 : 0);
        ctx.fillStyle = rgba(p.shadow, 0.5);
        ctx.fillRect(-6, -3, 14, 8);
        ctx.fillStyle = chaos ? rgba(p.warm, 0.85) : rgba(p.glass, 0.72);
        roundRect(ctx, -6, -3, 13, 6.5, 1.6);
        ctx.fill();
        ctx.fillStyle = rgba(p.ink, 0.6);
        roundRect(ctx, -2.5, -2, 6, 3, 1);
        ctx.fill();
        if (chaos) {
          glow(ctx, 0, 0, 22, p.accent, 0.16);
          ctx.fillStyle = rgba(p.accent, 0.9);
          ctx.fillRect(-7, -2, 1.6, 1.6);
        }
        ctx.restore();
      }

      // evacuation streams
      const ernd = seeded(chaos ? 27 : 14);
      for (let i = 0; i < (chaos ? 90 : 30); i++) {
        const x = ernd() * W;
        const y = 90 + Math.floor(ernd() * 5) * 172 + (ernd() - 0.5) * 48;
        const drift = (t * (chaos ? 12 : 22) + ernd() * 200) % W;
        const px = (x + drift) % W;
        ctx.fillStyle = chaos ? rgba(p.zombie, 0.72) : rgba(p.line, 0.34);
        ctx.beginPath();
        ctx.arc(px, y + Math.sin(i + t * 2) * 3, chaos ? 2.2 : 1.5, 0, TAU);
        ctx.fill();
      }

      // fire / smoke
      const fireSpots = chaos ? [[220, 380, 1.3], [820, 540, 1], [1080, 220, 0.8], [460, 660, 1.1]] : [[250, 320, 0.8], [960, 470, 1]];
      fireSpots.forEach(([x, y, sc], i) => {
        smokePlume(ctx, x, y, sc * 0.7, rgba(p.smoke, 0.7), t + i * 3, 0.13, i + 5);
        const flick = 0.85 + Math.sin(t * 9 + i) * 0.15;
        glow(ctx, x, y, 60 * sc, p.accent, (chaos ? 0.5 : 0.34) * flick);
        ctx.fillStyle = rgba(p.warm, 0.8 * flick);
        ctx.beginPath();
        ctx.ellipse(x, y, 7 * sc, 3.5 * sc, 0, 0, TAU);
        ctx.fill();
      });

      // helicopter
      if (chaos) {
        const hx = 980 - ((t * 30) % 240);
        const hy = 130 + Math.sin(t * 1.2) * 10;
        ctx.fillStyle = rgba(p.ink, 0.7);
        ctx.beginPath();
        ctx.ellipse(hx, hy, 20, 7, 0.1, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = rgba(p.line, 0.25);
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(hx - 40, hy);
        ctx.lineTo(hx + 42, hy - 2);
        ctx.stroke();
        glow(ctx, hx, hy + 3, 20, p.accent, 0.3);
      }

      // burning block wash
      ctx.fillStyle = grad(ctx, 0, 0, W, H, [
        [0, "rgba(255,106,61,0)"],
        [0.5, rgba(p.accent, chaos ? 0.07 : 0.04)],
        [1, "rgba(0,0,0,0)"],
      ]);
      ctx.fillRect(0, 0, W, H);
    });

    if (s.settings.fx.fog) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = radial(ctx, W * 0.5, H * 0.4, 20, W * 0.7, [[0, p.smoke], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
    speedLines(ctx, W, H, t * 0.4, rgba(p.line, 0.2), 0.5, 10);
  }

  private cityDive(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, p.bg1, mixColor(p.bg2, "#6c4733", 0.22));
    this.layer(s, 0.86, () => {
      skyline(ctx, 540, rgba(p.far, 0.85), 5, 1.3, p.glow, 0.9);
      ctx.fillStyle = rgba(p.smoke, 0.12);
      ctx.fillRect(0, 400, W, 320);
      smokePlume(ctx, 500, 470, 1.8, rgba(p.smoke, 0.4), t, 0.22, 7);
    });
    this.layer(s, 0.62, () => {
      this.streetLamps(ctx, p, t, 430, [260, 1020]);
      // road far below
      ctx.fillStyle = p.road;
      poly(ctx, [
        [0, 590],
        [640, 486],
        [1280, 590],
        [1280, 720],
        [0, 720],
      ]);
      ctx.fill();
      ctx.strokeStyle = rgba(p.line, 0.14);
      ctx.setLineDash([26, 36]);
      ctx.beginPath();
      ctx.moveTo(640, 500);
      ctx.lineTo(640, 720);
      ctx.stroke();
      ctx.setLineDash([]);
      // tiny city
      const rnd = seeded(4);
      for (let i = 0; i < 24; i++) {
        ctx.fillStyle = rgba(p.near, 0.7 + rnd() * 0.2);
        ctx.fillRect(rnd() * W, 530 + rnd() * 170, 20 + rnd() * 40, 10 + rnd() * 30);
      }
    });
    this.layer(s, 0.46, () => {
      // left tower
      ctx.fillStyle = shade(p.near, -0.12);
      poly(ctx, [
        [0, 0],
        [330, 0],
        [356, 720],
        [0, 720],
      ]);
      ctx.fill();
      // right tower
      ctx.fillStyle = shade(p.near, -0.22);
      poly(ctx, [
        [880, 0],
        [1280, 0],
        [1280, 720],
        [842, 720],
      ]);
      ctx.fill();
      // windows
      const rnd = seeded(8);
      for (let row = 0; row < 13; row++) {
        for (let col = 0; col < 5; col++) {
          const wx = 42 + col * 62 + row * 4;
          const wy = 38 + row * 54;
          ctx.fillStyle = rnd() > 0.62 ? rgba(p.glow, 0.18 + rnd() * 0.32) : rgba(p.ink, 0.4);
          ctx.fillRect(wx, wy, 24, 16);
          ctx.fillStyle = rgba(p.glow, 0.18);
          ctx.fillRect(1110 + col * 46 - row * 2, wy, 20, 14);
        }
      }
      // facades / ledges
      for (let i = 0; i < 7; i++) {
        const y = 30 + i * 95;
        ctx.fillStyle = rgba(p.line, 0.06);
        ctx.fillRect(0, y, 336 - i * 12, 3);
        ctx.fillRect(874 + i * 16, y + 20, 420, 3);
      }
      // red beacons
      [110, 250, 1010, 1160].forEach((x, i) => {
        const y = 80 + i * 120;
        glow(ctx, x, y, 42, p.accent, 0.55 + Math.sin(t * 5 + i) * 0.2);
        ctx.fillStyle = p.accent;
        ctx.beginPath();
        ctx.arc(x, y, 3.2, 0, TAU);
        ctx.fill();
      });
    });
    this.layer(s, 0.15, () => {
      // foreground debris rushing past
      const rnd = seeded(29);
      for (let i = 0; i < 18; i++) {
        const y = ((t * 540 + rnd() * 900) % 800) - 40;
        const x = rnd() * W;
        ctx.fillStyle = rgba(p.line, 0.16 + rnd() * 0.2);
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(t * 4 + i);
        ctx.fillRect(-4, -2, 8 + rnd() * 16, 2 + rnd() * 5);
        ctx.restore();
      }
      if (s.settings.fx.speedFx) speedLines(ctx, W, H, t, rgba(p.line, 0.5), 1, 34);
    });
    if (s.settings.fx.rays) sunRays(ctx, 920, 40, rgba(p.glow, 0.5), 0.12, 6, 900);
  }

  private broadcast(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, p.bg1, mixColor(p.bg2, "#442821", 0.32));
    this.layer(s, 0.9, () => {
      skyline(ctx, 560, rgba(p.far, 0.4), 66, 0.75, p.glow, 0.35);
      // facade
      const fx = 40;
      const fy = 40;
      const fw = 1200;
      const fh = 660;
      ctx.fillStyle = shade(p.near, -0.14);
      ctx.fillRect(fx, fy, fw, fh);
      this.brickPattern(ctx, fx, fy, fw, fh, p.line, 5);
      // windows
      const rnd = seeded(12);
      for (let r = 0; r < 6; r++) {
        for (let c = 0; c < 9; c++) {
          ctx.fillStyle = rnd() > 0.45 ? rgba(p.glow, 0.04 + rnd() * 0.08) : rgba(p.ink, 0.42);
          ctx.fillRect(fx + 40 + c * 130, fy + 34 + r * 98, 76, 54);
        }
      }
      // billboard
      const bx = 214;
      const by = 118;
      const bw = 850;
      const bh = 370;
      ctx.save();
      ctx.fillStyle = rgba(p.shadow, 0.55);
      roundRect(ctx, bx + 18, by + 24, bw, bh, 6);
      ctx.fill();
      ctx.fillStyle = "#231413";
      roundRect(ctx, bx, by, bw, bh, 5);
      ctx.fill();
      ctx.strokeStyle = p.accent;
      ctx.lineWidth = 3;
      ctx.stroke();
      glow(ctx, bx + bw / 2, by + bh / 2, 540, p.accent, 0.3 + Math.sin(t * 7) * 0.05);
      // header bar
      ctx.fillStyle = p.accent;
      ctx.fillRect(bx + 2, by + 2, bw - 4, 58);
      ctx.fillStyle = "#1b0c09";
      ctx.font = `700 22px "JetBrains Mono", monospace`;
      ctx.textAlign = "left";
      ctx.fillText("CIVIL DEFENCE / LEVEL 5", bx + 32, by + 38);
      // hazard triangle
      const hx = bx + 94;
      const hy = by + 140;
      ctx.strokeStyle = p.warm;
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(hx, hy + 84);
      ctx.lineTo(hx + 62, hy - 26);
      ctx.lineTo(hx + 124, hy + 84);
      ctx.closePath();
      ctx.stroke();
      ctx.fillStyle = p.warm;
      ctx.font = `700 62px "Anton", sans-serif`;
      ctx.fillText("!", hx + 48, hy + 64);
      // headline
      ctx.fillStyle = "#f4e9d8";
      ctx.font = `400 92px "Anton", sans-serif`;
      ctx.fillText("GLOBAL", bx + 260, by + 168);
      ctx.fillText("EMERGENCY", bx + 260, by + 254);
      ctx.fillStyle = p.accent;
      ctx.fillRect(bx + 260, by + 278, 548, 4);
      ctx.fillStyle = "#f4e9d8";
      ctx.font = `600 31px "JetBrains Mono", monospace`;
      ctx.fillText("STAY INDOORS", bx + 260, by + 324);
      // scanlines + glitch
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = "#000";
      for (let y = by + 6; y < by + bh; y += 5) ctx.fillRect(bx + 3, y, bw - 6, 2);
      ctx.globalAlpha = 1;
      const glitch = Math.sin(t * 17) > 0.86;
      if (glitch) {
        ctx.fillStyle = rgba(p.accent2, 0.28);
        ctx.fillRect(bx + 20, by + 120 + Math.sin(t * 44) * 40, bw - 40, 18);
        ctx.fillStyle = rgba(p.accent, 0.24);
        ctx.fillRect(bx + 20, by + 210, bw - 90, 8);
      }
      // screen reflection
      ctx.fillStyle = grad(ctx, bx, by, bx + bw, by + bh, [
        [0, "rgba(255,255,255,0.08)"],
        [0.4, "rgba(255,255,255,0)"],
      ]);
      ctx.fillRect(bx, by, bw, bh);
      ctx.restore();
      // speakers / rig
      ctx.fillStyle = rgba(p.ink, 0.8);
      ctx.fillRect(bx + 20, by - 24, 40, 24);
      ctx.fillRect(bx + bw - 60, by - 24, 40, 24);
      // crowd silhouettes
      const crnd = seeded(32);
      for (let i = 0; i < 26; i++) {
        const x = 60 + crnd() * 1160;
        const sc = 0.5 + crnd() * 0.4;
        ctx.fillStyle = rgba(p.shadow, 0.8);
        ctx.beginPath();
        ctx.arc(x, H - 48 - sc * 44, 8 * sc, 0, TAU);
        ctx.fill();
        ctx.fillRect(x - 7 * sc, H - 46 - sc * 42, 14 * sc, 54 * sc);
      }
      this.papers(ctx, p, t, 10, 2);
    });
    if (s.settings.fx.rays) sunRays(ctx, 760, 90, rgba(p.glow, 0.6), 0.14, 5, 780);
  }

  /* ------------------------------ street scenes ------------------------------ */

  private streetBackdrop(s: SceneState, options: { closeCars?: boolean; zombies?: number } = {}) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, mixColor(p.bg1, p.cool, 0.08), mixColor(p.bg2, p.warm, 0.12));
    this.layer(s, 0.92, () => {
      skyline(ctx, 430, rgba(p.far, 0.42), 11, 0.9, p.glow, 0.5);
      ctx.fillStyle = rgba(p.smoke, 0.12);
      ctx.fillRect(0, 300, W, 460);
      smokePlume(ctx, 820, 410, 1.4, rgba(p.smoke, 0.5), t, 0.22, 3);
    });
    this.layer(s, 0.72, () => {
      // shop row left & right in perspective
      const shops = [
        { x: 20, y: 290, w: 340, h: 340, label: "PHARMACY / CLOSED", color: mixColor(p.mid, p.accent2, 0.2) },
        { x: 300, y: 330, w: 230, h: 300, label: "CAFÉ", color: mixColor(p.mid, p.warm, 0.16) },
        { x: 940, y: 280, w: 340, h: 360, label: "MARKET", color: mixColor(p.mid, p.cool, 0.12) },
        { x: 790, y: 330, w: 190, h: 300, label: "NO ENTRY", color: p.near },
      ];
      shops.forEach((sh, i) => {
        ctx.fillStyle = sh.color;
        ctx.fillRect(sh.x, sh.y, sh.w, sh.h);
        ctx.fillStyle = rgba(p.ink, 0.35);
        for (let wx = sh.x + 22; wx < sh.x + sh.w - 30; wx += 54) {
          ctx.fillRect(wx, sh.y + 132, 38, 74);
        }
        // awning
        ctx.fillStyle = rgba(i % 2 ? p.accent : p.accent2, 0.42);
        poly(ctx, [
          [sh.x + 6, sh.y + 96],
          [sh.x + sh.w - 6, sh.y + 96],
          [sh.x + sh.w - 30, sh.y + 130],
          [sh.x + 30, sh.y + 130],
        ]);
        ctx.fill();
        sign(ctx, sh.x + 16, sh.y + 40, Math.min(250, sh.w - 32), 34, sh.label, p, { color: rgba(p.line, 0.7), bg: rgba(p.ink, 0.55), size: 9, align: "left" });
      });
      // wet street
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 540, W, 200);
      ctx.fillStyle = grad(ctx, 0, 520, 0, H, [
        [0, rgba(p.bg2, 0.4)],
        [1, rgba(p.ink, 0.6)],
      ]);
      ctx.fillRect(0, 520, W, 220);
      ctx.strokeStyle = rgba(p.line, 0.22);
      ctx.setLineDash([34, 28]);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(560, 720);
      ctx.lineTo(616, 540);
      ctx.stroke();
      ctx.setLineDash([]);
      // curb
      ctx.fillStyle = rgba(p.line, 0.09);
      ctx.fillRect(0, 530, W, 10);
      // distant barricade
      ctx.strokeStyle = rgba(p.accent, 0.5);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(430, 510);
      ctx.lineTo(850, 510);
      ctx.stroke();
      // park cars
      car(ctx, 330, 560, 0.8, mixColor(p.cool, p.near, 0.55), p, { alarm: false, alpha: 0.9, outline: s.styleCfg.outline });
      car(ctx, 820, 548, 0.72, mixColor(p.accent, p.near, 0.6), p, { facing: -1, outline: s.styleCfg.outline });
      if (options.closeCars) {
        car(ctx, 120, 650, 1.55, mixColor(p.mid, p.ink, 0.25), p, { outline: s.styleCfg.outline });
        car(ctx, 1080, 670, 1.8, mixColor(p.cool, p.ink, 0.6), p, { facing: -1, outline: s.styleCfg.outline });
      }
      this.streetLamps(ctx, p, t, 402, [90, 740, 1180]);
      // foreground debris
      if (s.settings.fx.particles) this.papers(ctx, p, t, 16, 7);
      // zombies emerging
      const count = options.zombies ?? 0;
      for (let i = 0; i < count; i++) {
        this.zombie(s, 440 + i * 130, 560 + i * 8, 0.65 + i * 0.14, i % 2 ? -1 : 1, 0.86, i * 1.2);
      }
    });
  }

  private streetScene(s: SceneState) {
    this.streetBackdrop(s, { zombies: 1 });
    const p = s.palette;
    const { ctx } = s;
    this.layer(s, 0.26, () => {
      // survivor dropping the shopping bag, far left
      this.actor(s, "mara", 310, 620, 1.08, "lookback", -1, "side", 0.4, 0.9);
      // dropped bag
      ctx.save();
      ctx.translate(382, 646);
      ctx.rotate(-0.24);
      ctx.fillStyle = p.warm;
      roundRect(ctx, -18, -20, 36, 40, 4);
      ctx.fill();
      ctx.strokeStyle = rgba(p.ink, 0.6);
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, -20, 12, Math.PI, 0);
      ctx.stroke();
      ctx.fillStyle = p.accent;
      ctx.fillRect(-8, -4, 16, 10);
      ctx.restore();
      glow(ctx, 620, 300, 260, p.accent, 0.12);
    });
    if (s.settings.fx.fog) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = radial(ctx, W * 0.5, 520, 30, 540, [[0, rgba(p.smoke, 0.22)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 300, W, 420);
      ctx.restore();
    }
  }

  private emergeScene(s: SceneState) {
    this.streetBackdrop(s, { closeCars: true, zombies: 0 });
    const { ctx } = s;
    const p = s.palette;
    this.layer(s, 0.3, () => {
      this.zombie(s, 545, 642, 1.36, 1, 1, 0);
      this.zombie(s, 760, 628, 1.02, -1, 0.92, 1.4);
      this.zombie(s, 400, 610, 0.85, 1, 0.8, 2.1);
      // head-turn close foreground
      drawBust(ctx, {
        x: 1060,
        y: 610,
        size: 0.48,
        member: member("mara"),
        palette: p,
        style: s.styleId,
        styleCfg: s.styleCfg,
        t: s.time,
        mood: "zombie",
        facing: -1,
        rim: p.accent,
        rimStrength: 0.55,
      });
      glow(ctx, 540, 340, 300, p.accent, 0.2);
    });
    if (s.settings.fx.speedFx) speedLines(ctx, W, H, s.time, rgba(p.line, 0.2), 0.3, 10);
  }

  private bagScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, mixColor(p.road, p.bg2, 0.2)], [1, p.ink]]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.7, () => {
      // pavement
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 230, W, 490);
      ctx.strokeStyle = rgba(p.line, 0.12);
      ctx.lineWidth = 3;
      for (let i = 0; i < 7; i++) {
        ctx.beginPath();
        ctx.moveTo(-100 + i * 220, 230);
        ctx.lineTo(-240 + i * 290, 720);
        ctx.stroke();
      }
      ctx.strokeStyle = rgba(p.line, 0.1);
      ctx.beginPath();
      ctx.moveTo(0, 470);
      ctx.lineTo(W, 440);
      ctx.stroke();
      // spilled groceries
      const items: [number, number, number, string][] = [
        [-90, 84, 20, p.accent],
        [66, 36, 15, p.accent2],
        [112, 82, 22, p.warm],
        [-140, 118, 14, p.line],
        [20, 128, 18, p.accent],
      ];
      items.forEach(([ix, iy, r, col], i) => {
        ctx.fillStyle = rgba(p.shadow, 0.5);
        ctx.beginPath();
        ctx.ellipse(640 + ix, 590 + iy + 8, r * 1.1, r * 0.4, 0, 0, TAU);
        ctx.fill();
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(640 + ix, 590 + iy, r, 0, TAU);
        ctx.fill();
        if (i % 2 === 0) {
          ctx.fillStyle = rgba(p.glow, 0.5);
          ctx.beginPath();
          ctx.arc(640 + ix - r * 0.3, 590 + iy - r * 0.3, r * 0.3, 0, TAU);
          ctx.fill();
        }
      });
      // a can
      drawCylinder3D(ctx, { x: 480, y: 636, size: 54, color: p.accent2, palette: p, outline: s.styleCfg.outline });
      // bag
      const fall = smooth(clamp(s.local / 0.12));
      ctx.save();
      ctx.translate(640, 560 + (1 - fall) * -40);
      ctx.rotate(-0.32 + fall * 0.1);
      ctx.fillStyle = p.warm;
      poly(ctx, [
        [-92, 0],
        [88, -4],
        [72, 116],
        [-78, 120],
      ]);
      ctx.fill();
      ctx.strokeStyle = rgba(p.ink, 0.75);
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = rgba(p.accent, 0.8);
      ctx.fillRect(-48, 28, 88, 22);
      ctx.fillStyle = rgba(p.ink, 0.7);
      ctx.font = `600 12px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.fillText("24 HR", 0, 44);
      // handles
      ctx.strokeStyle = p.warm;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(-34, 0, 22, Math.PI * 1.05, Math.PI * 1.95);
      ctx.arc(34, 0, 22, Math.PI * 1.05, Math.PI * 1.95);
      ctx.stroke();
      ctx.restore();
      // feet fleeing
      const kick = smooth(clamp((s.local - 0.04) / 0.25));
      this.actor(s, "eli", 1000 + kick * 240, 620, 1.9, "sprint", -1, "side", 1.5, 0.28);
      this.actor(s, "mara", 900 + kick * 300, 660, 2.1, "run", -1, "side", 0.3, 0.18);
      // motion streaks
      ctx.strokeStyle = rgba(p.line, 0.18);
      ctx.lineWidth = 2;
      for (let i = 0; i < 7; i++) {
        ctx.beginPath();
        ctx.moveTo(800 + i * 40, 580 + i * 18);
        ctx.lineTo(1180 + i * 30, 560 + i * 16);
        ctx.stroke();
      }
    });
    vignette(ctx, W, H, 0.5, p.shadow);
  }

  private zombieClose(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    // blurred street bg
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, p.bg1], [1, mixColor(p.bg2, p.accent, 0.12)]]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.8, () => {
      skyline(ctx, 400, rgba(p.far, 0.32), 21, 1.1, p.accent, 0.5);
      ctx.fillStyle = rgba(p.smoke, 0.16);
      ctx.fillRect(0, 340, W, 380);
      for (let i = 0; i < 6; i++) {
        const bx = 60 + i * 230;
        ctx.fillStyle = rgba(p.mid, 0.16 + i * 0.02);
        ctx.fillRect(bx, 240 + (i % 3) * 50, 140, 380);
      }
      glow(ctx, 250, 300, 380, p.accent, 0.25);
      smokePlume(ctx, 320, 460, 1.7, rgba(p.smoke, 0.4), t, 0.28, 11);
    });
    this.layer(s, 0.25, () => {
      drawBust(ctx, {
        x: 650 + (1 - smooth(clamp(s.local / 0.3))) * 110,
        y: 660,
        size: 1.04,
        member: member("mara"),
        palette: p,
        style: s.styleId,
        styleCfg: s.styleCfg,
        t,
        mood: "zombie",
        facing: 1,
        rim: p.accent,
        rimStrength: 0.85,
      });
      // foreground reach
      glow(ctx, 1070, 560, 220, p.accent, 0.14);
    });
    if (s.local < 0.12) {
      ctx.fillStyle = rgba(p.accent, 0.18 * (1 - s.local / 0.12));
      ctx.fillRect(0, 0, W, H);
    }
  }

  private whipScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.streetBackdrop(s, { zombies: 2 });
    this.layer(s, 0.2, () => {
      const slide = (1 - s.progress) * 920 * (s.cam.yaw > 0 ? 1 : -1);
      ctx.translate(slide, 0);
      this.actor(s, "mara", 540, 630, 1.5, "sprint", -1, "side", 0.2);
      this.actor(s, "eli", 690, 646, 1.62, "sprint", -1, "side", 1.8);
      this.actor(s, "kai", 820, 618, 1.36, "run", -1, "side", 3.1);
      drawBust(ctx, {
        x: 1180,
        y: 650,
        size: 0.62,
        member: member("mara"),
        palette: p,
        style: s.styleId,
        styleCfg: s.styleCfg,
        t,
        mood: "zombie",
        facing: -1,
        rim: p.accent,
        rimStrength: 0.5,
      });
    });
    if (s.settings.fx.speedFx) {
      speedLines(ctx, W, H, t * 2, rgba(p.line, 0.5), 1.3, 38);
      ctx.fillStyle = rgba(p.bg1, 0.18);
      ctx.fillRect(0, 0, W, H);
    }
  }

  private alleyScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, p.bg1, p.bg2);
    this.layer(s, 0.9, () => {
      // far wall / end of alley
      ctx.fillStyle = shade(p.mid, -0.2);
      ctx.fillRect(440, 170, 400, 430);
      this.brickPattern(ctx, 440, 170, 400, 430, p.line, 17);
      // back door
      ctx.fillStyle = rgba(p.ink, 0.7);
      ctx.fillRect(566, 300, 150, 300);
      ctx.strokeStyle = rgba(p.accent, 0.45);
      ctx.strokeRect(566, 300, 150, 300);
      ctx.fillStyle = rgba(p.accent2, 0.5);
      ctx.font = `600 12px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.fillText("EXIT 03", 640, 368);
      // far emergency glow
      glow(ctx, 640, 430, 300, p.accent, 0.2);
      // graffiti
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(826, 380);
      ctx.bezierCurveTo(870, 340, 850, 480, 900, 420);
      ctx.stroke();
    });
    // left wall
    this.layer(s, 0.5, () => {
      ctx.fillStyle = shade(p.near, -0.06);
      poly(ctx, [
        [0, 120],
        [452, 188],
        [452, 610],
        [0, 720],
      ]);
      ctx.fill();
      this.brickPattern(ctx, 0, 120, 452, 600, p.line, 4);
      // pipes
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.moveTo(40, 200);
      ctx.lineTo(390, 250);
      ctx.lineTo(390, 560);
      ctx.stroke();
      ctx.lineWidth = 4;
      ctx.strokeStyle = rgba(p.ink, 0.55);
      ctx.stroke();
      // window
      ctx.fillStyle = rgba(p.ink, 0.55);
      ctx.fillRect(120, 280, 118, 150);
      ctx.strokeStyle = rgba(p.glow, 0.14);
      ctx.lineWidth = 2;
      ctx.strokeRect(120, 280, 118, 150);
      ctx.beginPath();
      ctx.moveTo(179, 280);
      ctx.lineTo(179, 430);
      ctx.stroke();
      // bins
      ctx.fillStyle = mixColor(p.mid, p.ink, 0.4);
      roundRect(ctx, 285, 510, 118, 124, 6);
      ctx.fill();
      ctx.fillStyle = rgba(p.ink, 0.5);
      roundRect(ctx, 274, 500, 140, 24, 5);
      ctx.fill();
      // graffiti mark
      ctx.strokeStyle = rgba(p.accent, 0.38);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(70, 480);
      ctx.lineTo(130, 450);
      ctx.lineTo(100, 510);
      ctx.stroke();
    });
    // right wall
    this.layer(s, 0.5, () => {
      ctx.fillStyle = shade(p.near, -0.16);
      poly(ctx, [
        [1280, 96],
        [826, 188],
        [826, 610],
        [1280, 720],
      ]);
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      poly(ctx, [
        [1280, 96],
        [826, 188],
        [826, 610],
        [1280, 720],
      ]);
      ctx.clip();
      this.brickPattern(ctx, 826, 96, 460, 640, p.line, 12);
      ctx.restore();
      // pipe + ladder
      ctx.strokeStyle = rgba(p.line, 0.2);
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(1100, 170);
      ctx.lineTo(1100, 700);
      ctx.stroke();
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.lineWidth = 4;
      for (let i = 0; i < 8; i++) {
        ctx.beginPath();
        ctx.moveTo(1000, 300 + i * 40);
        ctx.lineTo(1060, 306 + i * 40);
        ctx.stroke();
      }
    });
    // ground
    this.layer(s, 0.34, () => {
      ctx.fillStyle = p.road;
      poly(ctx, [
        [0, 610],
        [1280, 602],
        [1280, 720],
        [0, 720],
      ]);
      ctx.fill();
      ctx.fillStyle = grad(ctx, 0, 580, 0, H, [[0, rgba(p.accent, 0.1)], [1, rgba(p.ink, 0.7)]]);
      ctx.fillRect(0, 580, W, 140);
      ctx.strokeStyle = rgba(p.line, 0.1);
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.moveTo(640, 580);
        ctx.lineTo(180 + i * 190, 720);
        ctx.stroke();
      }
    });
    // cast sprinting away
    this.layer(s, 0.24, () => {
      const stride = Math.sin(t * 12) * 6;
      this.actor(s, "mara", 490 + stride, 640, 1.15, "sprint", 1, "back", 0.4);
      this.actor(s, "eli", 582 - stride, 664, 1.28, "sprint", 1, "back", 2.1);
      this.actor(s, "kai", 652 + stride * 0.6, 622, 1.02, "run", 1, "back", 3.4);
      // horde entering frame behind
      this.horde(ctx, p, 760, 500, 5, t, 250, 0.55, rgba(p.ink, 0.6));
      glow(ctx, 760, 430, 160, p.accent, 0.16);
    });
    if (s.settings.fx.fog) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = radial(ctx, 640, 560, 20, 420, [[0, rgba(p.smoke, 0.18)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 200, W, 520);
      ctx.restore();
    }
    if (s.settings.fx.particles) dust(ctx, W, H, t, p.line, 34, 12, 0.7);
  }

  private doorScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const slamAt = 0.55;
    const slam = s.local > slamAt ? smooth(clamp((s.local - slamAt) / 0.12)) : 0;
    const open = 1 - slam;
    this.sky(s, p.bg1, p.bg2);
    // interior beyond the door
    this.layer(s, 0.9, () => {
      ctx.fillStyle = "#101517";
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, p.bg2], [1, p.ink]]);
      ctx.fillRect(0, 0, 820, H);
      this.actor(s, "mara", 320, 650, 1.45, "sprint", -1, "side", 0.4);
      this.actor(s, "kai", 450, 672, 1.25, "run", -1, "side", 2.2);
      glow(ctx, 230, 420, 340, p.warm, 0.14);
    });
    // door frame
    this.layer(s, 0.42, () => {
      // wall
      ctx.fillStyle = shade(p.near, -0.12);
      ctx.fillRect(690, 0, 590, 720);
      this.brickPattern(ctx, 690, 0, 590, 720, p.line, 8);
      // door opening
      const dx = 760;
      const dw = 390;
      ctx.fillStyle = p.ink;
      ctx.fillRect(dx, 90, dw, 630);
      // door panel rotates open by sliding/foreshortening
      const doorW = dw * (0.4 + open * 0.6);
      ctx.save();
      ctx.translate(dx, 0);
      ctx.fillStyle = mixColor(p.mid, p.ink, 0.3);
      ctx.fillRect(0, 88, doorW, 632);
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.lineWidth = 2;
      for (let i = 0; i < 9; i++) {
        ctx.beginPath();
        ctx.moveTo(doorW * 0.1, 130 + i * 64);
        ctx.lineTo(doorW * 0.9, 130 + i * 64);
        ctx.stroke();
      }
      ctx.strokeStyle = rgba(p.ink, 0.65);
      ctx.lineWidth = 4;
      ctx.strokeRect(12, 100, doorW - 24, 610);
      ctx.fillStyle = rgba(p.line, 0.22);
      for (let i = 0; i < 12; i++) {
        ctx.beginPath();
        ctx.arc(24, 130 + i * 50, 3, 0, TAU);
        ctx.arc(doorW - 24, 130 + i * 50, 3, 0, TAU);
        ctx.fill();
      }
      // push bar
      ctx.fillStyle = mixColor(p.line, p.ink, 0.4);
      ctx.fillRect(doorW * 0.16, 440, doorW * 0.68, 18);
      ctx.fillStyle = p.accent;
      ctx.fillRect(doorW - 56, 390, 26, 50);
      // sign
      sign(ctx, doorW / 2 - 92, 188, 184, 40, "FIRE EXIT · KEEP SHUT", p, { color: p.line, bg: rgba(p.ink, 0.7), size: 9 });
      ctx.restore();
      // door frame
      ctx.strokeStyle = rgba(p.line, 0.25);
      ctx.lineWidth = 7;
      ctx.strokeRect(dx - 8, 82, dw + 16, 642);
      glow(ctx, 640, 300, 420, p.accent, 0.18);
    });
    // Eli pushing door + hands
    this.layer(s, 0.18, () => {
      this.actor(s, "eli", 778, 690, 2.05, "push", -1, "side", 0.8, 1, "determined");
      const rnd = seeded(5);
      for (let i = 0; i < 4; i++) {
        const hx = 760 - slam * 40 + rnd() * 30;
        const hy = 350 + i * 60;
        ctx.strokeStyle = p.zombie;
        ctx.lineWidth = 15;
        ctx.beginPath();
        ctx.moveTo(hx - 120 + rnd() * 40, hy + 40);
        ctx.lineTo(hx - 20, hy);
        ctx.stroke();
        ctx.fillStyle = p.zombie;
        ctx.beginPath();
        ctx.arc(hx - 12, hy, 12, 0, TAU);
        ctx.fill();
      }
      if (slam > 0.02) {
        glow(ctx, 760, 360, 260, p.glow, 0.4 * (1 - slam) + 0.08);
        ctx.strokeStyle = rgba(p.glow, 0.6 * (1 - slam * 0.6));
        ctx.lineWidth = 3;
        for (let i = 0; i < 9; i++) {
          const a = (i / 9) * TAU;
          ctx.beginPath();
          ctx.moveTo(762, 380);
          ctx.lineTo(762 + Math.cos(a) * (80 + slam * 120), 380 + Math.sin(a) * (80 + slam * 120));
          ctx.stroke();
        }
      }
      if (s.settings.fx.particles) {
        dust(ctx, W, H, s.time, p.line, 26, 8, 0.5 + slam);
      }
    });
  }

  private hallwayBase(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.layer(s, 0.95, () => {
      ctx.fillStyle = p.ink;
      ctx.fillRect(0, 0, W, H);
      // back wall & corridor
      const vx = 650;
      const vy = 350;
      ctx.fillStyle = shade(p.mid, -0.24);
      ctx.fillRect(vx - 120, vy - 150, 240, 300);
      // floor
      ctx.fillStyle = mixColor(p.near, p.ink, 0.24);
      poly(ctx, [
        [0, 720],
        [vx - 120, vy + 150],
        [vx + 120, vy + 150],
        [W, 720],
      ]);
      ctx.fill();
      // left wall
      ctx.fillStyle = shade(p.near, -0.06);
      poly(ctx, [
        [0, 0],
        [vx - 120, vy - 150],
        [vx - 120, vy + 150],
        [0, 720],
      ]);
      ctx.fill();
      // right wall
      ctx.fillStyle = shade(p.near, -0.18);
      poly(ctx, [
        [W, 0],
        [vx + 120, vy - 150],
        [vx + 120, vy + 150],
        [W, 720],
      ]);
      ctx.fill();
      // ceiling
      ctx.fillStyle = mixColor(p.ink, p.mid, 0.2);
      poly(ctx, [
        [0, 0],
        [W, 0],
        [vx + 120, vy - 150],
        [vx - 120, vy - 150],
      ]);
      ctx.fill();
      // perspective wall lines
      ctx.strokeStyle = rgba(p.line, 0.09);
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(0, 120 + i * 90);
        ctx.lineTo(vx - 120, 230 + i * 42);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(W, 100 + i * 100);
        ctx.lineTo(vx + 120, 230 + i * 42);
        ctx.stroke();
      }
      // peeling papers
      ctx.fillStyle = rgba(p.line, 0.12);
      for (let i = 0; i < 6; i++) ctx.fillRect(120 + i * 80, 260 + (i % 3) * 60, 40, 54);
      // covered furniture
      ctx.fillStyle = rgba(p.line, 0.16);
      poly(ctx, [
        [120, 560],
        [190, 430],
        [340, 448],
        [392, 580],
      ]);
      ctx.fill();
      ctx.strokeStyle = rgba(p.ink, 0.35);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(160, 510);
      ctx.lineTo(340, 520);
      ctx.stroke();
      ctx.fillStyle = rgba(p.line, 0.12);
      poly(ctx, [
        [960, 480],
        [1010, 400],
        [1180, 430],
        [1200, 590],
        [990, 585],
      ]);
      ctx.fill();
      // covered table
      ctx.fillStyle = rgba(p.line, 0.1);
      ctx.fillRect(820, 520, 130, 90);
      drawCube3D(ctx, { x: 900, y: 540, size: 74, rotX: -0.25, rotY: 0.7, color: mixColor(p.mid, p.ink, 0.2), palette: p, outline: s.styleCfg.outline });
      // exit sign
      glow(ctx, vx, vy - 148, 120, p.accent, 0.25);
      ctx.fillStyle = rgba(p.accent, 0.7);
      ctx.font = `600 14px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.fillText("EXIT", vx, vy - 140);
      // flashlight
      lightCone(ctx, 980, 690, -2.15, 0.34, 880, p.glow, 0.34);
      glow(ctx, 980, 690, 60, p.glow, 0.5);
      // characters as silhouettes
      this.actor(s, "mara", 540, 620, 1.2, "idle", 1, "back", 0.3, 0.72);
      this.actor(s, "eli", 760, 600, 1.25, "lookback", -1, "back", 1.3, 0.6);
      this.actor(s, "kai", 860, 608, 1.02, "idle", 1, "back", 2.3, 0.5);
      // dust in beam
      if (s.settings.fx.particles) dust(ctx, W, H, t, p.glow, 42, 14, 0.6);
    });
    if (s.settings.fx.fog) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = radial(ctx, 650, 350, 40, 380, [[0, rgba(p.smoke, 0.16)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  private hallwayScene(s: SceneState) {
    this.hallwayBase(s);
  }

  private shadowScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.layer(s, 0.9, () => {
      ctx.fillStyle = mixColor(p.near, p.ink, 0.3);
      ctx.fillRect(0, 0, W, H);
      // wall panel
      ctx.fillStyle = shade(p.mid, -0.1);
      ctx.fillRect(70, 80, 1140, 570);
      ctx.strokeStyle = rgba(p.line, 0.12);
      ctx.lineWidth = 2;
      for (let x = 70; x < 1210; x += 142) {
        ctx.beginPath();
        ctx.moveTo(x, 80);
        ctx.lineTo(x, 650);
        ctx.stroke();
      }
      // frames
      [[260, 200, 150, 100], [860, 170, 190, 140]].forEach(([x, y, w, h]) => {
        ctx.strokeStyle = rgba(p.line, 0.2);
        ctx.lineWidth = 8;
        ctx.strokeRect(x, y, w, h);
        ctx.fillStyle = rgba(p.ink, 0.4);
        ctx.fillRect(x + 10, y + 10, w - 20, h - 20);
      });
      // monstrous shadow
      const sway = Math.sin(t * 1.8) * 18;
      ctx.save();
      ctx.fillStyle = rgba(p.shadow, 0.78);
      ctx.beginPath();
      ctx.ellipse(760 + sway, 380, 72, 92, 0.12, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(700 + sway, 400);
      ctx.quadraticCurveTo(680, 560, 740, 650);
      ctx.lineTo(860, 650);
      ctx.quadraticCurveTo(872, 500, 826 + sway, 402);
      ctx.closePath();
      ctx.fill();
      // reaching arms
      ctx.strokeStyle = rgba(p.shadow, 0.78);
      ctx.lineWidth = 30;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(816 + sway, 470);
      ctx.quadraticCurveTo(940, 430 + sway, 1040, 350);
      ctx.moveTo(712 + sway, 470);
      ctx.quadraticCurveTo(620, 420, 520, 390 + sway);
      ctx.stroke();
      ctx.restore();
      // floor
      ctx.fillStyle = p.ink;
      ctx.fillRect(0, 650, W, 70);
      // flashlight from side
      lightCone(ctx, 110, 660, -0.75, 0.3, 940, p.glow, 0.4);
      glow(ctx, 110, 660, 40, p.glow, 0.5);
      // foreground shoulder
      ctx.fillStyle = rgba(p.ink, 0.92);
      ctx.beginPath();
      ctx.ellipse(60, 650, 190, 210, 0.25, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(90, 500, 74, 0, TAU);
      ctx.fill();
      if (s.settings.fx.particles) dust(ctx, W, H, t, p.glow, 28, 22, 0.7);
    });
    const flicker = Math.sin(t * 23) > 0.75 ? 0.18 : 0;
    ctx.fillStyle = rgba(p.ink, flicker);
    ctx.fillRect(0, 0, W, H);
  }

  private hordeScene(s: SceneState) {
    this.hallwayBase(s);
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.layer(s, 0.3, () => {
      const vy = 350;
      const vx = 650;
      // doorway crowd
      this.horde(ctx, p, vx, vy + 118, 9, t, 230, 1.05, rgba(p.ink, 0.86));
      // lead zombie
      this.zombie(s, vx, vy + 150, 0.95, -1, 0.85, 0.4);
      glow(ctx, vx, vy - 10, 260, p.accent, 0.36);
      glow(ctx, vx, vy + 60, 60, p.glow, 0.7);
      // flashlight flare
      lightCone(ctx, 640, 680, -1.57, 0.24, 640, p.glow, 0.36);
    });
    if (s.local > 0.45) {
      ctx.strokeStyle = rgba(p.glow, 0.25 * (1 - s.progress));
      ctx.lineWidth = 2;
      for (let i = 0; i < 20; i++) {
        const a = (i / 20) * TAU;
        ctx.beginPath();
        ctx.moveTo(640 + Math.cos(a) * 250, 360 + Math.sin(a) * 250);
        ctx.lineTo(640 + Math.cos(a) * 620, 360 + Math.sin(a) * 620);
        ctx.stroke();
      }
    }
  }

  /* ------------------------------ getaway scenes ----------------------------- */

  private windowScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, p.bg1, mixColor(p.bg2, p.warm, 0.3));
    this.layer(s, 0.86, () => {
      skyline(ctx, 470, rgba(p.far, 0.55), 44, 1.2, p.glow, 0.7);
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 470, W, 250);
      car(ctx, 820, 610, 1.2, mixColor(p.accent, p.near, 0.45), p, { outline: s.styleCfg.outline, alarm: true, t });
      glow(ctx, 500, 400, 420, p.warm, 0.24);
      smokePlume(ctx, 970, 500, 1.7, rgba(p.smoke, 0.7), t, 0.25, 12);
    });
    // window frame silhouette
    this.layer(s, 0.4, () => {
      ctx.strokeStyle = p.ink;
      ctx.lineWidth = 42;
      ctx.strokeRect(90, 20, 1100, 680);
      ctx.beginPath();
      ctx.moveTo(640, 40);
      ctx.lineTo(640, 210);
      ctx.moveTo(240, 40);
      ctx.lineTo(240, 680);
      ctx.moveTo(1040, 40);
      ctx.lineTo(1040, 680);
      ctx.stroke();
      // shards
      const rnd = seeded(3);
      for (let i = 0; i < 34; i++) {
        const life = smooth(clamp(s.local / 0.29));
        const x = 200 + rnd() * 880 + (rnd() - 0.5) * life * 520;
        const y = 180 + rnd() * 360 + life * 300;
        const size = 8 + rnd() * 38;
        ctx.fillStyle = rgba(p.glass, 0.12 + rnd() * 0.32);
        ctx.strokeStyle = rgba(p.glow, 0.35);
        ctx.lineWidth = 1;
        poly(ctx, [
          [x, y],
          [x + size * 0.7, y - size * 0.4],
          [x + size, y + size * 0.7],
        ]);
        ctx.fill();
        ctx.stroke();
      }
      // leaping bodies
      this.actor(s, "mara", 450, 520 - s.progress * 70, 1.75, "leap", 1, "side", 0.4);
      this.actor(s, "eli", 660, 490 - s.progress * 40, 1.85, "leap", 1, "side", 1.3);
      this.actor(s, "kai", 850, 540, 1.4, "run", 1, "side", 2.3);
      // alarm glows
      glow(ctx, 970, 580, 220, Math.sin(t * 20) > 0 ? p.accent : p.accent2, 0.4);
    });
    if (s.settings.fx.speedFx) speedLines(ctx, W, H, t, rgba(p.line, 0.3), 0.7, 18);
  }

  private alarmScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, mixColor(p.bg1, p.accent, 0.06), p.bg2);
    this.layer(s, 0.92, () => {
      skyline(ctx, 440, rgba(p.far, 0.4), 55, 1, p.glow, 0.6);
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 500, W, 220);
      // storefronts behind
      ctx.fillStyle = rgba(p.near, 0.6);
      ctx.fillRect(0, 360, W, 150);
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = rgba(p.glow, 0.05 + (i % 3) * 0.03);
        ctx.fillRect(40 + i * 210, 385, 150, 82);
      }
      // parked wrecks
      car(ctx, 150, 560, 1.05, mixColor(p.cool, p.ink, 0.4), p, { facing: 1, outline: s.styleCfg.outline });
      // main car
      const rig = car(ctx, 700, 612, 1.55, mixColor(p.accent, p.ink, 0.38), p, { facing: -1, alarm: true, headlights: true, t, driver: "kai", outline: s.styleCfg.outline });
      glow(ctx, 500, 560, 300, Math.sin(t * 22) > 0 ? p.accent : p.cool, 0.35);
      // survivors
      this.actor(s, "mara", 360, 660, 1.55, "wave", 1, "side", 0.3);
      this.actor(s, "eli", 900, 665, 1.5, "run", -1, "side", 1.2);
      this.actor(s, "kai", 572, 585, 0.95, "drive", -1, "front", 2.3);
      // horde background
      this.horde(ctx, p, 1110, 545, 7, t, 200, 0.55);
      // alarm warning light on wall
      ctx.fillStyle = p.accent;
      ctx.beginPath();
      ctx.arc(1120, 400, 10, 0, TAU);
      ctx.fill();
      glow(ctx, 1120, 400, 260, p.accent, 0.3);
      void rig;
      if (s.settings.fx.particles) this.papers(ctx, p, t, 14, 4);
    });
    if (s.settings.fx.rain) rain(ctx, W, H, t, rgba(p.cool, 0.7), 0.8);
  }

  private engineScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, p.bg1], [1, p.ink]]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.9, () => {
      // windshield
      ctx.fillStyle = grad(ctx, 0, 0, 0, H, [
        [0, mixColor(p.bg2, p.cool, 0.18)],
        [1, p.bg1],
      ]);
      ctx.fillRect(0, 0, W, 320);
      ctx.fillStyle = rgba(p.smoke, 0.2);
      ctx.fillRect(0, 240, W, 80);
      this.horde(ctx, p, 300, 230, 5, t, 300, 0.4, rgba(p.shadow, 0.5));
      glow(ctx, 1080, 190, 230, p.accent, 0.22);
      // dash
      ctx.fillStyle = shade(p.near, -0.28);
      ctx.beginPath();
      ctx.moveTo(0, 330);
      ctx.quadraticCurveTo(640, 250, 1280, 330);
      ctx.lineTo(1280, 720);
      ctx.lineTo(0, 720);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = rgba(p.ink, 0.45);
      ctx.fillRect(0, 330, W, 30);
      // gauges
      const gauge = (x: number, y: number, r: number, value: number, label: string, redline = 0.78) => {
        ctx.save();
        ctx.translate(x, y);
        ctx.fillStyle = "#0b0e10";
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = rgba(p.line, 0.22);
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, r - 10, 0, TAU);
        ctx.stroke();
        for (let i = 0; i < 22; i++) {
          const a = Math.PI * 0.75 + (i / 21) * Math.PI * 1.5;
          const major = i % 3 === 0;
          ctx.strokeStyle = i / 21 > redline ? p.accent : rgba(p.line, major ? 0.8 : 0.3);
          ctx.lineWidth = major ? 4 : 2;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * (r - 22), Math.sin(a) * (r - 22));
          ctx.lineTo(Math.cos(a) * (r - (major ? 40 : 33)), Math.sin(a) * (r - (major ? 40 : 33)));
          ctx.stroke();
        }
        const a = Math.PI * 0.75 + value * Math.PI * 1.5;
        ctx.strokeStyle = p.accent;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * -12, Math.sin(a) * -12);
        ctx.lineTo(Math.cos(a) * (r - 34), Math.sin(a) * (r - 34));
        ctx.stroke();
        glow(ctx, 0, 0, r * 1.2, p.accent, 0.1);
        ctx.fillStyle = rgba(p.line, 0.7);
        ctx.font = `600 ${r * 0.15}px "JetBrains Mono", monospace`;
        ctx.textAlign = "center";
        ctx.fillText(label, 0, r * 0.5);
        ctx.fillStyle = rgba(p.line, 0.45);
        ctx.font = `500 ${r * 0.12}px "JetBrains Mono", monospace`;
        ctx.fillText("×1000", 0, r * 0.68);
        ctx.restore();
      };
      const ignition = smooth(clamp((s.local - 0.12) / 0.3));
      const rev = ignition * (0.35 + Math.sin(t * 4) * 0.04 + s.progress * 0.28);
      gauge(430, 520, 150, rev, "RPM");
      gauge(760, 530, 128, 0.32 + rev * 0.3, "KM/H");
      // center display
      ctx.fillStyle = "#0b0e10";
      roundRect(ctx, 540, 380, 320, 94, 8);
      ctx.fill();
      ctx.strokeStyle = rgba(p.line, 0.16);
      ctx.stroke();
      ctx.fillStyle = ignition > 0.2 ? p.accent2 : p.accent;
      ctx.font = `600 20px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.fillText(ignition > 0.2 ? "ENGINE RUNNING" : "IGNITION", 700, 420);
      ctx.fillStyle = rgba(p.line, 0.4);
      ctx.font = `400 11px "JetBrains Mono", monospace`;
      ctx.fillText("TRACTION · OFF    FUEL · 31%", 700, 448);
      // key & hand
      ctx.save();
      ctx.translate(310, 430);
      ctx.fillStyle = rgba(p.ink, 0.9);
      ctx.fillRect(0, 0, 90, 18);
      ctx.fillStyle = p.accent;
      ctx.beginPath();
      ctx.arc(0, 9, 20, 0, TAU);
      ctx.fill();
      ctx.fillStyle = mixColor(p.skin, p.warm, 0.3);
      roundRect(ctx, -110, -22, 120, 74, 22);
      ctx.fill();
      glow(ctx, 0, 0, 120, p.accent, 0.2 * ignition);
      ctx.restore();
      // steering wheel
      ctx.strokeStyle = shade(p.ink, 0.12);
      ctx.lineWidth = 42;
      ctx.beginPath();
      ctx.arc(640, 800, 300, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
      ctx.strokeStyle = rgba(p.line, 0.12);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(640, 800, 282, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
      // rain on windshield
      if (s.settings.fx.rain) rain(ctx, W, 330, t, rgba(p.cool, 0.5), 0.6);
    });
    // speed blur at end
    if (s.local > 0.38) speedLines(ctx, W, H, t, rgba(p.glow, 0.3), 0.8, 26);
  }

  private driveScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, mixColor(p.bg1, p.cool, 0.08), mixColor(p.bg2, p.accent, 0.08));
    this.layer(s, 0.92, () => {
      skyline(ctx, 400, rgba(p.far, 0.5), 77, 0.9, p.glow, 0.7);
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 470, W, 250);
      ctx.strokeStyle = rgba(p.line, 0.15);
      ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(-100, 560 + i * 70);
        ctx.lineTo(W + 100, 520 + i * 70);
        ctx.stroke();
      }
      // wrecks foreground moving
      const off = (t * 360) % 620;
      car(ctx, 170 - off * 0.2, 590, 0.9, mixColor(p.cool, p.ink, 0.55), p, { facing: 1, outline: s.styleCfg.outline });
      car(ctx, 1180 + off * 0.12, 610, 1.1, mixColor(p.accent, p.ink, 0.4), p, { facing: -1, outline: s.styleCfg.outline });
      car(ctx, 1080 - off * 0.4, 520, 0.62, mixColor(p.mid, p.ink, 0.3), p, { facing: -1, outline: s.styleCfg.outline });
      // horde crossing background
      this.horde(ctx, p, 640, 520, 10, t, 700, 0.6, rgba(p.ink, 0.65));
      // hero car tracking
      const bob = Math.sin(t * 22) * 2;
      car(ctx, 610, 590 + bob, 1.7, mixColor(p.accent, p.ink, 0.36), p, {
        facing: -1,
        headlights: false,
        alarm: true,
        t,
        outline: s.styleCfg.outline,
      });
      // tail light glow
      glow(ctx, 800, 570, 180, p.accent, 0.5);
      glow(ctx, 900, 500, 260, p.accent, 0.25);
      // speed streaks
      if (s.settings.fx.speedFx) speedLines(ctx, W, H, t, rgba(p.line, 0.3), 1.2, 36);
      if (s.settings.fx.rain) rain(ctx, W, H, t, rgba(p.cool, 0.7), 1);
      smokePlume(ctx, 1050, 560, 1.2, rgba(p.smoke, 0.6), t, 0.25, 11);
    });
    ctx.fillStyle = rgba(p.ink, 0.18);
    ctx.fillRect(0, 0, W, H);
  }

  /* ------------------------------ bridge scenes ------------------------------ */

  private bridgeScene(s: SceneState, variant: "blocked" | "sacrifice" | "escape") {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, mixColor(p.bg1, p.cool, 0.1), mixColor(p.bg2, p.accent, variant === "escape" ? 0.15 : 0.06));
    this.layer(s, 0.96, () => {
      skyline(ctx, 470, rgba(p.far, 0.32), 93, 1, p.glow, 0.35);
      // water
      ctx.fillStyle = mixColor(p.bg1, p.cool, 0.18);
      ctx.fillRect(0, 470, W, 250);
      ctx.strokeStyle = rgba(p.glow, 0.08);
      for (let i = 0; i < 9; i++) {
        ctx.beginPath();
        ctx.moveTo(0, 520 + i * 22);
        ctx.lineTo(W, 512 + i * 22);
        ctx.stroke();
      }
      // bridge towers / cables
      ctx.strokeStyle = rgba(p.line, 0.18);
      ctx.lineWidth = 5;
      for (const tx of [120, 1160]) {
        ctx.beginPath();
        ctx.moveTo(tx, 130);
        ctx.lineTo(tx, 560);
        ctx.stroke();
      }
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 12; i++) {
        ctx.beginPath();
        ctx.moveTo(120, 150 + i * 30);
        ctx.quadraticCurveTo(640, 340 + i * 10, 1160, 150 + i * 30);
        ctx.stroke();
      }
      // deck
      ctx.fillStyle = shade(p.near, -0.15);
      poly(ctx, [
        [0, 620],
        [1280, 600],
        [1280, 720],
        [0, 720],
      ]);
      ctx.fill();
      ctx.strokeStyle = rgba(p.line, 0.2);
      ctx.lineWidth = 3;
      ctx.setLineDash([48, 32]);
      ctx.beginPath();
      ctx.moveTo(0, 680);
      ctx.lineTo(W, 660);
      ctx.stroke();
      ctx.setLineDash([]);
      this.streetLamps(ctx, p, t, 460, [230, 1040]);
      // fog banks
      for (let i = 0; i < 4; i++) {
        ctx.fillStyle = rgba(p.smoke, 0.05 + i * 0.015);
        ctx.beginPath();
        ctx.ellipse(200 + i * 320, 570 - i * 8, 260, 48, 0, 0, TAU);
        ctx.fill();
      }
    });

    if (variant === "blocked" || variant === "sacrifice") {
      this.layer(s, 0.35, () => {
        // horde in the distance behind the car
        this.horde(ctx, p, 640, 540, 14, t, 640, 0.8, rgba(p.ink, 0.7));
        glow(ctx, 640, 490, 440, p.accent, 0.17);
        car(ctx, variant === "blocked" ? 420 : 370, 616, 1.55, mixColor(p.accent, p.ink, 0.4), p, {
          facing: -1,
          headlights: true,
          driver: "kai",
          outline: s.styleCfg.outline,
          alarm: true,
          t,
        });
        // blocked barrier (real projected 3D primitive)
        drawCube3D(ctx, {
          x: 780,
          y: 560,
          size: 190,
          rotX: -0.12,
          rotY: 0.44 + (variant === "sacrifice" ? s.progress * 0.3 : 0),
          color: mixColor(p.mid, p.ink, 0.2),
          palette: p,
          outline: s.styleCfg.outline,
          lightDir: [0.4, -0.8, -0.4],
        });
        drawCylinder3D(ctx, { x: 930, y: 600, size: 120, color: p.accent, palette: p, outline: s.styleCfg.outline });
        // hazard stripes
        ctx.save();
        ctx.translate(780, 560);
        ctx.rotate(0.08);
        for (let i = 0; i < 5; i++) {
          ctx.fillStyle = rgba(p.warm, 0.7);
          poly(ctx, [
            [-80 + i * 34, -90],
            [-64 + i * 34, -90],
            [-90 + i * 34, 20],
            [-106 + i * 34, 20],
          ]);
          ctx.fill();
        }
        ctx.restore();
        if (variant === "sacrifice") {
          this.actor(s, "eli", 620, 690, 2.05, "push", 1, "side", 0.4);
          this.actor(s, "mara", 300, 660, 1.25, "wave", 1, "side", 2.2);
        } else {
          this.actor(s, "mara", 260, 660, 1.1, "idle", 1, "side", 0.3);
        }
        if (s.settings.fx.rain) rain(ctx, W, H, t, rgba(p.cool, 0.6), 0.7);
        smokePlume(ctx, 1080, 540, 1.5, rgba(p.smoke, 0.4), t, 0.2, 9);
      });
    }

    if (variant === "escape") {
      this.layer(s, 0.4, () => {
        this.horde(ctx, p, 360 - s.progress * 180, 570, 16, t, 420, 0.9, rgba(p.ink, 0.75));
        const cx = 480 + s.progress * 520;
        ctx.save();
        ctx.translate(cx, 636);
        ctx.rotate(-0.06 - s.progress * 0.05);
        car(ctx, 0, 0, 1.5, mixColor(p.accent, p.ink, 0.34), p, {
          facing: 1,
          headlights: true,
          alarm: false,
          driver: "kai",
          outline: s.styleCfg.outline,
          t,
        });
        ctx.restore();
        glow(ctx, cx + 100, 610, 220, p.glow, 0.4);
        glow(ctx, cx - 100, 620, 160, p.accent, 0.4);
        if (s.settings.fx.speedFx) speedLines(ctx, W, H, t, rgba(p.line, 0.4), 1.2, 30);
        if (s.settings.fx.rain) rain(ctx, W, H, t, rgba(p.cool, 0.6), 0.9);
      });
    }
    if (s.settings.fx.rays) sunRays(ctx, 1020, 10, rgba(p.glow, 0.5), 0.1, 5, 700);
  }

  private realizationScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, p.bg1], [1, mixColor(p.bg2, p.accent, 0.28)]]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.9, () => {
      for (let i = 0; i < 10; i++) {
        glow(ctx, 120 + i * 128, 220 + (i % 4) * 70, 54 + (i % 3) * 30, i % 2 ? p.accent : p.glow, 0.16);
      }
      this.horde(ctx, p, 660, 420, 12, t, 620, 0.65, rgba(p.shadow, 0.55));
      ctx.fillStyle = rgba(p.glow, 0.08);
      poly(ctx, [[-100, 120], [1380, 280], [1380, 330], [-100, 200]]);
      ctx.fill();
      drawBust(ctx, {
        x: 620,
        y: 700,
        size: 1.18,
        member: member("eli"),
        palette: p,
        style: s.styleId,
        styleCfg: s.styleCfg,
        t,
        mood: "determined",
        facing: 1,
        rim: p.accent,
        rimStrength: 0.9,
      });
      glow(ctx, 1030, 520, 260, p.accent, 0.22);
    });
    const pulse = 0.18 + Math.sin(t * 5) * 0.05;
    ctx.fillStyle = radial(ctx, 640, 360, 200, 760, [[0, "rgba(0,0,0,0)"], [1, rgba(p.shadow, pulse + 0.4)]]);
    ctx.fillRect(0, 0, W, H);
  }

  private obstacleScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = mixColor(p.bg1, p.ink, 0.25);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.85, () => {
      drawCube3D(ctx, {
        x: 640,
        y: 400,
        size: 430,
        rotX: -0.14,
        rotY: 0.5 - s.progress * 0.16,
        color: mixColor(p.mid, p.ink, 0.25),
        palette: p,
        outline: s.styleCfg.outline,
      });
      ctx.fillStyle = rgba(p.road, 0.7);
      ctx.fillRect(0, 560, W, 160);
      glow(ctx, 180, 560, 280, p.glow, 0.3);
      ctx.save();
      ctx.translate(560, 470);
      ctx.rotate(-0.14);
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = rgba(p.warm, 0.8);
        poly(ctx, [[i * 34, -160], [i * 34 + 18, -160], [i * 34 - 32, -36], [i * 34 - 50, -36]]);
        ctx.fill();
      }
      ctx.restore();
      ctx.fillStyle = mixColor(p.skin, p.warm, 0.24);
      for (const [hx, hy, rot] of [[500, 360, -0.4], [570, 400, -0.2], [754, 420, 0.25], [806, 380, 0.4]] as [number, number, number][]) {
        ctx.save();
        ctx.translate(hx, hy);
        ctx.rotate(rot);
        roundRect(ctx, -30, -16, 64, 42, 17);
        ctx.fill();
        ctx.strokeStyle = rgba(p.ink, 0.4);
        ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          ctx.moveTo(6 + i * 12, -10);
          ctx.lineTo(10 + i * 12, 14);
          ctx.stroke();
        }
        ctx.restore();
      }
      if (s.settings.fx.particles) {
        const rnd = seeded(88);
        for (let i = 0; i < 26; i++) {
          const life = (s.progress + rnd()) % 1;
          const x = 500 + rnd() * 320 + life * 80;
          const y = 500 - life * 260 + rnd() * 50;
          ctx.fillStyle = rgba(p.warm, 0.8 * (1 - life));
          ctx.fillRect(x, y, 2 + rnd() * 3, 2 + rnd() * 3);
          glow(ctx, x, y, 12, p.accent, 0.25 * (1 - life));
        }
      }
      speedLines(ctx, W, H, t, rgba(p.line, 0.2), 0.6, 12);
    });
  }

  private runbackScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.sky(s, mixColor(p.bg1, p.accent, 0.08), p.bg2);
    this.layer(s, 0.92, () => {
      skyline(ctx, 470, rgba(p.far, 0.35), 102, 1, p.glow, 0.4);
      ctx.fillStyle = p.road;
      ctx.fillRect(0, 520, W, 200);
      this.horde(ctx, p, 640, 500, 16, t, 760, 0.8, rgba(p.ink, 0.7));
      glow(ctx, 640, 460, 520, p.accent, 0.16);
      car(ctx, 980, 580, 1.2, mixColor(p.accent, p.ink, 0.4), p, {
        facing: 1,
        headlights: true,
        outline: s.styleCfg.outline,
      });
      this.actor(s, "eli", 590 + s.progress * 80, 700 + s.progress * 10, 2.15 + s.progress * 0.3, "sprint", -1, "front", 0.4);
      this.actor(s, "mara", 880, 620, 1.1, "wave", -1, "side", 1.2, 0.9);
      glow(ctx, 300, 560, 320, p.glow, 0.24);
      if (s.settings.fx.speedFx) speedLines(ctx, W, H, t, rgba(p.line, 0.4), 1.1, 32);
      if (s.settings.fx.rain) rain(ctx, W, H, t, rgba(p.cool, 0.6), 0.8);
    });
  }

  /* ------------------------------- bunker scenes ------------------------------ */

  private shelterBase(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = p.ink;
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.95, () => {
      ctx.fillStyle = shade(p.near, -0.25);
      ctx.fillRect(0, 0, W, H);
      this.brickPattern(ctx, 0, 0, W, H, p.line, 61);
      ctx.fillStyle = mixColor(p.near, p.ink, 0.42);
      ctx.fillRect(0, 540, W, 180);
      ctx.strokeStyle = rgba(p.line, 0.08);
      for (let i = 0; i < 8; i++) {
        ctx.beginPath();
        ctx.moveTo(0, 560 + i * 20);
        ctx.lineTo(W, 555 + i * 20);
        ctx.stroke();
      }
      for (const cx of [120, 1100]) {
        ctx.fillStyle = shade(p.near, -0.1);
        ctx.fillRect(cx, 100, 90, 470);
        ctx.fillStyle = rgba(p.line, 0.04);
        ctx.fillRect(cx + 10, 100, 18, 470);
      }
      // stairs left
      ctx.fillStyle = rgba(p.ink, 0.7);
      poly(ctx, [[0, 180], [300, 260], [310, 540], [0, 540]]);
      ctx.fill();
      for (let i = 0; i < 7; i++) {
        ctx.fillStyle = rgba(p.line, 0.08);
        ctx.fillRect(i * 24, 260 + i * 36, 280 - i * 30, 12);
      }
      // pipes
      ctx.strokeStyle = rgba(p.line, 0.12);
      ctx.lineWidth = 13;
      ctx.beginPath();
      ctx.moveTo(60, 120);
      ctx.lineTo(420, 120);
      ctx.lineTo(420, 320);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(980, 70);
      ctx.lineTo(1230, 70);
      ctx.stroke();
      // glass door right
      this.glassDoor(ctx, s, 890, 230, 310, 380, 0.45);
      if (s.settings.fx.threeD) {
        drawCube3D(ctx, {
          x: 380,
          y: 600,
          size: 120,
          rotX: -0.2,
          rotY: 0.6,
          color: mixColor(p.mid, p.ink, 0.2),
          palette: p,
          outline: s.styleCfg.outline,
        });
        drawCylinder3D(ctx, {
          x: 210,
          y: 605,
          size: 132,
          color: mixColor(p.accent, p.ink, 0.5),
          palette: p,
          outline: s.styleCfg.outline,
        });
      }
      const flicker = Math.sin(t * 24) > 0.82 || Math.sin(t * 7) > 0.96 ? 0.16 : 1;
      const lx = 700;
      const ly = 250 + Math.sin(t * 1.6) * 4;
      ctx.strokeStyle = rgba(p.line, 0.2);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(lx, 0);
      ctx.lineTo(lx, ly - 26);
      ctx.stroke();
      drawSphere3D(ctx, { x: lx, y: ly, size: 54, color: p.accent, palette: p });
      glow(ctx, lx, ly, 460, p.accent, 0.25 * flicker + 0.05);
      glow(ctx, lx, ly, 80, p.glow, 0.5 * flicker);
      ctx.fillStyle = rgba(p.glow, 0.08 * flicker);
      poly(ctx, [[lx - 20, ly], [lx + 20, ly], [lx + 330, 720], [lx - 330, 720]]);
      ctx.fill();
      this.actor(s, "mara", 480, 660, 1.22, "lookback", 1, "back", 0.4);
      this.actor(s, "eli", 600, 680, 1.32, "idle", 1, "back", 1.4);
      this.actor(s, "kai", 700, 650, 1.05, "idle", 1, "back", 2.4);
      ctx.fillStyle = rgba(p.accent, 0.07);
      ctx.beginPath();
      ctx.ellipse(700, 690, 260, 20, 0, 0, TAU);
      ctx.fill();
      if (s.settings.fx.particles) dust(ctx, W, H, t, p.glow, 30, 18, 0.6);
    });
    if (s.settings.fx.fog) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = radial(ctx, 700, 400, 30, 500, [[0, rgba(p.smoke, 0.12)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  private glassDoor(ctx: CanvasRenderingContext2D, s: SceneState, x: number, y: number, w: number, h: number, silhouette: number) {
    const p = s.palette;
    const t = s.time;
    ctx.save();
    ctx.fillStyle = rgba(p.ink, 0.72);
    ctx.fillRect(x - 10, y - 10, w + 20, h + 20);
    ctx.fillStyle = grad(ctx, x, y, x + w, y + h, [
      [0, rgba(p.glass, 0.24)],
      [0.6, rgba(p.glass, 0.1)],
      [1, rgba(p.cool, 0.16)],
    ]);
    ctx.fillRect(x, y, w, h);
    if (silhouette > 0) {
      const sway = Math.sin(t * 0.9) * 8;
      ctx.fillStyle = rgba(p.ink, silhouette);
      ctx.beginPath();
      ctx.ellipse(x + w * 0.54 + sway, y + h * 0.33, 30, 38, 0.08, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x + w * 0.54 + sway - 44, y + h * 0.45);
      ctx.quadraticCurveTo(x + w * 0.54 + sway - 60, y + h * 0.9, x + w * 0.54 + sway - 22, y + h * 0.94);
      ctx.lineTo(x + w * 0.54 + sway + 28, y + h * 0.94);
      ctx.quadraticCurveTo(x + w * 0.54 + sway + 56, y + h * 0.65, x + w * 0.54 + sway + 38, y + h * 0.45);
      ctx.closePath();
      ctx.fill();
    }
    ctx.strokeStyle = rgba(p.ink, 0.85);
    ctx.lineWidth = 8;
    ctx.strokeRect(x, y, w, h);
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x + w / 2, y);
    ctx.lineTo(x + w / 2, y + h);
    ctx.moveTo(x, y + h * 0.28);
    ctx.lineTo(x + w, y + h * 0.28);
    ctx.stroke();
    ctx.fillStyle = rgba(p.line, 0.07);
    poly(ctx, [[x + 20, y + h - 10], [x + w * 0.52, y + 20], [x + w * 0.72, y + 20], [x + 30, y + h - 10]]);
    ctx.fill();
    poly(ctx, [[x + w * 0.6, y + h - 10], [x + w * 0.9, y + 40], [x + w, y + 40], [x + w * 0.78, y + h - 10]]);
    ctx.fill();
    ctx.fillStyle = rgba(p.line, 0.14);
    ctx.beginPath();
    ctx.ellipse(x + w * 0.76, y + h * 0.58, 12, 16, 0.1, 0, TAU);
    ctx.fill();
    ctx.fillStyle = rgba(p.accent2, 0.55);
    ctx.font = `600 11px "JetBrains Mono", monospace`;
    ctx.fillText("SHELTER B · NO ADMITTANCE", x + 16, y + h * 0.24);
    ctx.restore();
  }

  private shelterScene(s: SceneState) {
    this.shelterBase(s);
  }

  private glassScene(s: SceneState) {
    this.shelterBase(s);
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    this.layer(s, 0.22, () => {
      ctx.fillStyle = rgba(p.ink, 0.18);
      ctx.fillRect(0, 0, W, H);
      this.glassDoor(ctx, s, 620, 130, 470, 500, 0.75);
      const flick = Math.sin(t * 28) > 0.8 ? 0.15 : 0;
      ctx.fillStyle = rgba(p.accent, flick);
      ctx.fillRect(0, 0, W, H);
    });
    glow(ctx, 800, 330, 380, p.accent, 0.18);
  }

  private whisperScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const t = s.time;
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [[0, p.bg1], [1, mixColor(p.near, p.ink, 0.45)]]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.95, () => {
      ctx.fillStyle = rgba(p.line, 0.03);
      for (let i = 0; i < 5; i++) ctx.fillRect(80 + i * 270, 0, 40, H);
      glow(ctx, 1080, 250, 200, p.accent, 0.25);
      glow(ctx, 1100, 250, 30, p.glow, 0.35);
      drawBust(ctx, {
        x: 620,
        y: 730,
        size: 1.16,
        member: member("mara"),
        palette: p,
        style: s.styleId,
        styleCfg: s.styleCfg,
        t,
        mood: "whisper",
        facing: 1,
        rim: p.accent,
        rimStrength: 0.95,
      });
      ctx.strokeStyle = rgba(p.accent, 0.5);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(110, 690);
      ctx.lineTo(1170, 690);
      ctx.stroke();
    });
    ctx.fillStyle = radial(ctx, 600, 360, 180, 720, [[0, "rgba(0,0,0,0)"], [1, rgba(p.shadow, 0.72)]]);
    ctx.fillRect(0, 0, W, H);
    const flick = Math.sin(t * 19) > 0.86 ? 0.2 : 0;
    ctx.fillStyle = rgba(p.ink, flick);
    ctx.fillRect(0, 0, W, H);
  }

  private blackoutScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const local = s.local;
    ctx.fillStyle = "#010203";
    ctx.fillRect(0, 0, W, H);
    const flickA = Math.max(0, Math.sin(local * 27) * Math.sin(local * 11));
    const show = local > 0.28 && local < 0.42;
    const finalFlash = local > 0.8;
    if (show || finalFlash) {
      ctx.save();
      ctx.globalAlpha = finalFlash ? 0.55 : 0.3 + flickA * 0.5;
      ctx.fillStyle = rgba(p.bg2, 0.5);
      ctx.fillRect(0, 0, W, H);
      this.shelterBase(s);
      ctx.restore();
    }
    const shock = smooth(clamp((local - 0.24) / 0.24));
    if (local > 0.24 && local < 0.9) {
      ctx.strokeStyle = rgba(p.glow, 0.5 * (1 - shock));
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(700, 380, 80 + shock * 520, 0, TAU);
      ctx.stroke();
      glow(ctx, 700, 380, 500, p.accent, 0.2 * (1 - shock));
    }
    const rnd = seeded(46);
    for (let i = 0; i < 18; i++) {
      const life = (local * 2 + rnd()) % 1;
      const x = 700 + (rnd() - 0.5) * 900 * life;
      const y = 420 + (rnd() - 0.5) * 420 * life;
      ctx.fillStyle = rgba(p.line, 0.18 * (1 - life));
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(life * 4 + i);
      ctx.fillRect(-8, -2, 20, 3);
      ctx.restore();
    }
    const pulse = Math.max(0, Math.sin(local * 9));
    glow(ctx, 1090, 260, 80 + pulse * 50, p.accent, 0.18 + pulse * 0.16);
    ctx.fillStyle = rgba(p.accent, 0.6);
    ctx.beginPath();
    ctx.arc(1090, 260, 3, 0, TAU);
    ctx.fill();
    if (finalFlash) {
      ctx.fillStyle = rgba(p.accent, 0.08 * (1 - (local - 0.8) / 0.2));
      ctx.fillRect(0, 0, W, H);
    }
  }

  private titleScene(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const local = s.local;
    const reveal = smooth(clamp((local - 0.05) / 0.26));
    ctx.fillStyle = grad(ctx, 0, 0, 0, H, [
      [0, "#040607"],
      [0.55, mixColor(p.bg1, "#130d0c", 0.4)],
      [1, "#050607"],
    ]);
    ctx.fillRect(0, 0, W, H);
    this.layer(s, 0.9, () => {
      ctx.globalAlpha = 0.55;
      skyline(ctx, 710, rgba(p.shadow, 0.85), 123, 1.4, p.accent, 0.5);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = rgba(p.line, 0.1);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 618);
      ctx.lineTo(W, 600);
      ctx.stroke();
      this.horde(ctx, p, 640, 680, 20, s.time, 1100, 0.8, rgba(p.shadow, 0.7));
      const rnd = seeded(55);
      for (let i = 0; i < 40; i++) {
        const life = (local * 0.55 + rnd()) % 1;
        const x = rnd() * W;
        const y = H - life * H * 0.75;
        ctx.fillStyle = rgba(p.accent, 0.2 * (1 - life) * reveal);
        ctx.beginPath();
        ctx.arc(x + Math.sin(life * 7 + i) * 20, y, 1 + rnd() * 2, 0, TAU);
        ctx.fill();
      }
      glow(ctx, 1000, 610, 580, p.accent, 0.24 * reveal);
    });
    ctx.save();
    ctx.globalAlpha = reveal;
    ctx.textAlign = "center";
    ctx.fillStyle = rgba(p.line, 0.4);
    ctx.font = `600 12px "JetBrains Mono", monospace`;
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "5px";
    ctx.fillText("A PARALLAX PROCEDURAL FILM", W / 2, 236);
    ctx.strokeStyle = rgba(p.accent, 0.85);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 60, 262);
    ctx.lineTo(W / 2 + 60, 262);
    ctx.stroke();
    ctx.fillStyle = "#f4ecdd";
    ctx.font = `400 118px "Anton", sans-serif`;
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "2px";
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = 26;
    ctx.fillText("THE LAST", W / 2, 370);
    ctx.fillStyle = p.accent;
    ctx.fillText("15 SECONDS", W / 2, 470);
    ctx.shadowBlur = 0;
    ctx.fillStyle = rgba(p.line, 0.7);
    ctx.font = `500 17px "JetBrains Mono", monospace`;
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "7px";
    ctx.fillText("SURVIVAL IS ONLY THE BEGINNING", W / 2, 538);
    ctx.fillStyle = rgba(p.line, 0.3);
    ctx.font = `400 10px "JetBrains Mono", monospace`;
    (ctx as CanvasRenderingContext2D & { letterSpacing?: string }).letterSpacing = "2px";
    ctx.fillText("DIRECTED BY THE STORY ENGINE  ·  15.00 SEC  ·  2.5D", W / 2, 660);
    ctx.restore();
    ctx.fillStyle = grad(ctx, 0, 540, 0, H, [[0, "rgba(4,6,7,0)"], [1, "rgba(4,6,7,0.75)"]]);
    ctx.fillRect(0, 540, W, 180);
  }

  /* ------------------------------ post & motion ------------------------------ */

  private drawTransitions(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const into = s.local;
    if (into > 0.22) return;
    const a = 1 - into / 0.22;
    if (s.shot.transition === "flash") {
      ctx.fillStyle = rgba(s.styleId === "experimental" ? p.accent2 : "#f7efe2", a * 0.7);
      ctx.fillRect(0, 0, W, H);
    }
    if (s.shot.transition === "impact") {
      ctx.fillStyle = rgba(p.accent, a * 0.18);
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = rgba(p.glow, a * 0.7);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(640, 360, 100 + (1 - a) * 700, 0, TAU);
      ctx.stroke();
    }
    if (s.shot.transition === "whip" && s.settings.fx.speedFx) {
      ctx.save();
      ctx.globalAlpha = a;
      for (let i = 0; i < 22; i++) {
        const y = (i / 22) * H;
        const off = (1 - a) * 500 * (i % 2 ? 1 : -1);
        ctx.fillStyle = i % 2 ? rgba(p.line, 0.12) : rgba(p.accent, 0.1);
        ctx.fillRect(off, y, W, 2 + (i % 3));
      }
      ctx.restore();
    }
  }

  private drawAtmosphere(s: SceneState) {
    const { ctx } = s;
    const p = s.palette;
    const foggy = ["street", "emerge", "alley", "bridge", "escape", "aerial", "chaos", "drive"].includes(s.shot.kind);
    if (s.settings.fx.fog && foggy) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      const drift = Math.sin(s.time * 0.3) * 40;
      ctx.fillStyle = radial(ctx, 300 + drift, 590, 80, 540, [[0, rgba(p.smoke, 0.16)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 300, W, 420);
      ctx.fillStyle = radial(ctx, 1000 - drift, 460, 60, 440, [[0, rgba(p.smoke, 0.11)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 220, W, 500);
      ctx.restore();
    }
    if (s.settings.fx.rain && ["street", "alarm", "drive", "bridge", "escape", "runback", "sacrifice"].includes(s.shot.kind)) {
      rain(ctx, W, H, s.time, rgba(p.cool, 0.55), 0.8);
    }
    if (s.settings.fx.particles && ["aerial", "chaos", "dive", "title"].includes(s.shot.kind)) {
      dust(ctx, W, H, s.time, p.glow, 32, 6, 0.7);
    }
    if (s.settings.fx.rays && ["aerial", "chaos", "bridge", "escape", "realization"].includes(s.shot.kind)) {
      sunRays(ctx, 1000, 20, rgba(p.glow, 0.35), 0.08 * s.settings.fx.light, 4, 800);
    }
    // anamorphic light leak
    if (s.shot.mood === "action" && s.settings.fx.bloom > 0.2) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = grad(ctx, W, 0, 0, 0, [[0, rgba(p.accent, 0.06 * s.settings.fx.bloom)], [1, "rgba(0,0,0,0)"]]);
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  /* -------------------------------- telemetry -------------------------------- */

  private buildTelemetry(time: number, shot: Shot, cam: CameraState, _settings: EngineSettings): Telemetry {
    const base: RadarObject[] = [
      { label: "CAM", type: "camera", x: cam.x, y: cam.y, z: cam.z, size: 1 },
      { label: "MARA", type: "cast", x: -1.6, y: 0.2, z: 2.6, size: 1.2 },
      { label: "ELI", type: "cast", x: -0.3, y: 0, z: 3.2, size: 1.4 },
      { label: "KAI", type: "cast", x: 0.8, y: -0.1, z: 2.1, size: 1.1 },
      { label: "HORDE", type: "zombie", x: 3.2, y: 0, z: 7.2, size: 2.2 },
      { label: "BACKGROUND", type: "environment", x: 0, y: 0, z: 10.5, size: 5 },
    ];
    const kind = shot.kind;
    if (kind === "aerial" || kind === "chaos" || kind === "dive") {
      base.splice(1, 5,
        { label: "GRID BLOCKS", type: "environment", x: 2, y: 0, z: 8.4, size: 5 },
        { label: "TRAFFIC", type: "vehicle", x: -2.8, y: 0, z: 5.4, size: 1.4 },
        { label: "HORDE STREAM", type: "zombie", x: 3.6, y: 0, z: 7.6, size: 2 },
        { label: "HELICOPTER", type: "vehicle", x: -4, y: 2.4, z: 6.2, size: 1.2 },
        { label: "SMOKE", type: "environment", x: 5, y: 1.2, z: 9.2, size: 3 }
      );
    } else if (kind === "alarm" || kind === "drive" || kind === "bridge" || kind === "escape" || kind === "runback") {
      base.splice(1, 5,
        { label: "SEDAN", type: "vehicle", x: 1.2, y: 0.2, z: 2.2, size: 1.6 },
        { label: "WRECK 01", type: "vehicle", x: -2.4, y: 0, z: 4.2, size: 1.2 },
        { label: "MARA", type: "cast", x: -1.2, y: 0.2, z: 2.8, size: 1.1 },
        { label: "ELI", type: "cast", x: 2.4, y: 0, z: 3.4, size: 1.2 },
        { label: "HORDE", type: "zombie", x: 0.8, y: 0, z: 8.2, size: 2.4 },
        { label: "BARRIER / CUBE", type: "prop3d", x: 4.4, y: 0, z: 4.8, size: 1.5 }
      );
    } else if (kind === "shelter" || kind === "glass" || kind === "whisper" || kind === "blackout") {
      base.splice(1, 5,
        { label: "MARA", type: "cast", x: -1.8, y: 0.2, z: 2.2, size: 1.2 },
        { label: "ELI", type: "cast", x: -0.4, y: 0, z: 2.6, size: 1.3 },
        { label: "KAI", type: "cast", x: 0.6, y: 0, z: 2.4, size: 1 },
        { label: "GLASS DOOR", type: "environment", x: 3.4, y: 0, z: 4.6, size: 2.4 },
        { label: "UNKNOWN", type: "zombie", x: 4.2, y: 0, z: 6.2, size: 1.3 },
        { label: "BARREL / CUBE", type: "prop3d", x: -2.6, y: 0, z: 1.2, size: 0.9 }
      );
    } else if (kind === "zombie" || kind === "whip" || kind === "emerge" || kind === "bag" || kind === "door" || kind === "hallway" || kind === "shadow" || kind === "horde" || kind === "window" || kind === "engine" || kind === "street") {
      base.splice(1, 5,
        { label: "MARA", type: "cast", x: -2.2, y: 0, z: 2.2, size: 1.1 },
        { label: "ELI", type: "cast", x: -0.8, y: 0, z: 2.7, size: 1.3 },
        { label: "KAI", type: "cast", x: 0.4, y: -0.2, z: 1.9, size: 1 },
        { label: "INFECTED", type: "zombie", x: 2.8, y: 0, z: 4.4, size: 1.5 },
        { label: "HORDE", type: "zombie", x: 1.2, y: 0, z: 7.8, size: 2.4 },
        { label: "PROP", type: "prop3d", x: 4.8, y: 0, z: 3.2, size: 1.1 }
      );
    } else if (kind === "title") {
      base.splice(1, 5,
        { label: "TITLE LOCKUP", type: "environment", x: 0, y: 1, z: 5, size: 3 },
        { label: "EMBER FIELD", type: "environment", x: 2, y: 0, z: 7.4, size: 4.2 },
        { label: "CITY SILHOUETTE", type: "environment", x: -2.4, y: 0, z: 9.6, size: 5 },
        { label: "HORDE", type: "zombie", x: 3.2, y: 0, z: 8.2, size: 2 }
      );
    } else if (kind === "screen") {
      base.splice(1, 5,
        { label: "BROADCAST", type: "environment", x: 1.2, y: 0.6, z: 5.2, size: 4.2 },
        { label: "CROWD", type: "cast", x: -2.2, y: 0, z: 2.6, size: 1.4 },
        { label: "INFECTED", type: "zombie", x: 3.6, y: 0, z: 6, size: 1.4 }
      );
    }
    const layerBands = [
      { name: "FOREGROUND", z: 1.6, color: "#ff6a3d" },
      { name: "MID-GROUND", z: 4.2, color: "#a8c3bd" },
      { name: "BACKGROUND", z: 8.6, color: "#566a70" },
    ];
    const aspect = "16:9";
    return {
      time,
      shotId: shot.id,
      shotIndex: shot.index + 1,
      totalShots: SHOTS.length,
      title: shot.title,
      scene: shot.scene,
      focus: shot.focus,
      camera: cam,
      objects: base,
      duration: FILM_DURATION,
      fov: cam.fov,
      layerBands,
      crop: `${aspect} · ${(cam.fov * 0.36).toFixed(1)}mm eq`,
    };
  }
}