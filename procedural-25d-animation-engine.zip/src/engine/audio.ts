import { AUDIO_CUES, type AudioCue } from "./data";

export interface MixSettings {
  master: number;
  music: number;
  sfx: number;
  ambience: number;
  muted: boolean;
}

export const DEFAULT_MIX: MixSettings = { master: 0.8, music: 0.6, sfx: 0.75, ambience: 0.55, muted: true };

/**
 * Fully procedural, non-vocal sound design.
 * Every sound is synthesized at runtime with the Web Audio API — no samples, no voices.
 */
export class SoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private ambBus: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private nodes: AudioScheduledSourceNode[] = [];
  private exportDest: MediaStreamAudioDestinationNode | null = null;
  private playing = false;

  get isPlaying() {
    return this.playing;
  }

  setMix(mix: MixSettings) {
    if (!this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.linearRampToValueAtTime(mix.muted ? 0 : mix.master, now + 0.08);
    this.musicBus?.gain.linearRampToValueAtTime(mix.muted ? 0 : mix.music * 0.42, now + 0.08);
    this.sfxBus?.gain.linearRampToValueAtTime(mix.muted ? 0 : mix.sfx * 0.7, now + 0.08);
    this.ambBus?.gain.linearRampToValueAtTime(mix.muted ? 0 : mix.ambience * 0.34, now + 0.08);
  }

  configureStream(): MediaStream | null {
    this.ensureContext();
    if (!this.ctx) return null;
    if (!this.exportDest) {
      this.exportDest = this.ctx.createMediaStreamDestination();
      this.compressor?.connect(this.exportDest);
    }
    return this.exportDest.stream;
  }

  private ensureContext() {
    if (this.ctx) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    const master = ctx.createGain();
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = -16;
    compressor.knee.value = 20;
    compressor.ratio.value = 5;
    compressor.attack.value = 0.004;
    compressor.release.value = 0.22;
    master.connect(compressor);
    compressor.connect(ctx.destination);
    this.master = master;
    this.compressor = compressor;
    this.musicBus = ctx.createGain();
    this.sfxBus = ctx.createGain();
    this.ambBus = ctx.createGain();
    this.musicBus.gain.value = 0.24;
    this.sfxBus.gain.value = 0.5;
    this.ambBus.gain.value = 0.18;
    for (const bus of [this.musicBus, this.sfxBus, this.ambBus]) {
      const pan = ctx.createStereoPanner();
      pan.pan.value = 0;
      bus.connect(pan);
      pan.connect(master);
    }
    // shared noise buffer
    const len = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = last * 0.68 + white * 0.32;
      data[i] = last;
    }
    this.noiseBuffer = buffer;
  }

  async startAt(from: number, mix: MixSettings) {
    this.stop();
    this.ensureContext();
    const ctx = this.ctx;
    if (!ctx) return;
    await ctx.resume().catch(() => undefined);
    this.playing = true;
    this.setMix(mix);
    const t0 = ctx.currentTime + 0.08;
    const map = (cueTime: number) => t0 + Math.max(0, cueTime - from);
    // Beds
    this.wind(t0, 15 - from, 0.22);
    this.score(t0, from);
    // Cue-level foley
    AUDIO_CUES.filter((cue) => cue.t >= from - 0.08).forEach((cue) => {
      const when = map(cue.t);
      this.playCue(cue, when, t0);
    });
    // rhythmic footsteps while running
    const runs: [number, number][] = [
      [3.02, 4.1],
      [6.0, 6.3],
      [11.0, 11.5],
    ];
    runs.forEach(([start, end]) => {
      if (end < from) return;
      for (let tt = Math.max(start, from); tt < end; tt += 0.27) {
        this.step(map(tt), 0.4, 95);
      }
    });
    // heartbeat under pressure
    for (let tt = Math.max(9.4, from); tt < 12; tt += 0.82) {
      this.heart(map(tt));
    }
  }

  stop() {
    this.playing = false;
    this.nodes.forEach((node) => {
      try {
        node.stop();
      } catch {
        /* already stopped */
      }
    });
    this.nodes = [];
    if (this.ctx) {
      const ctx = this.ctx;
      try {
        this.master?.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.035);
      } catch {
        /* noop */
      }
      this.ctx = null;
      this.master = null;
      this.musicBus = null;
      this.sfxBus = null;
      this.ambBus = null;
      this.compressor = null;
      this.exportDest = null;
      window.setTimeout(() => {
        ctx.close().catch(() => undefined);
      }, 140);
    }
  }

  private track(node: AudioScheduledSourceNode) {
    this.nodes.push(node);
  }

  private noiseSource(when: number, duration: number) {
    if (!this.ctx || !this.noiseBuffer) return null;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    src.start(when);
    src.stop(when + duration + 0.05);
    this.track(src);
    return src;
  }

  private env(when: number, attack: number, hold: number, release: number, peak: number) {
    if (!this.ctx) return null;
    const gain = this.ctx.createGain();
    const g = Math.max(0.0001, peak);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(g, when + attack);
    gain.gain.setValueAtTime(g, when + attack + hold);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + attack + hold + release);
    return gain;
  }

  private noiseBurst(when: number, duration: number, gainVal: number, freq: number, type: BiquadFilterType = "bandpass", q = 1, bus: GainNode | null = this.sfxBus) {
    if (!this.ctx || !bus) return;
    const src = this.noiseSource(when, duration);
    if (!src) return;
    const filter = this.ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.value = freq;
    filter.Q.value = q;
    const gain = this.env(when, 0.006, duration * 0.25, duration, gainVal);
    if (!gain) return;
    src.connect(filter);
    filter.connect(gain);
    gain.connect(bus);
  }

  private tone(
    when: number,
    duration: number,
    freq: number,
    gainVal: number,
    type: OscillatorType = "sine",
    bus: GainNode | null = this.sfxBus,
    slideTo?: number
  ) {
    if (!this.ctx || !bus) return;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, when);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), when + duration);
    const gain = this.env(when, 0.01, duration * 0.2, duration, gainVal);
    if (!gain) return;
    osc.connect(gain);
    gain.connect(bus);
    osc.start(when);
    osc.stop(when + duration + 0.06);
    this.track(osc);
  }

  private metal(when: number, strength = 0.4, pitch = 1) {
    this.noiseBurst(when, 0.7, strength * 0.5, 1800, "highpass", 0.7);
    [420, 780, 1240, 2100].forEach((f, i) => this.tone(when + i * 0.008, 0.35 + i * 0.14, f * pitch, strength * (0.16 - i * 0.025), "triangle"));
    this.tone(when, 0.5, 120 * pitch, strength * 0.32, "sine", this.sfxBus, 52);
  }

  private step(when: number, gain = 0.3, freq = 160) {
    this.noiseBurst(when, 0.09, gain * 0.4, freq, "bandpass", 1.4);
    this.tone(when, 0.075, 70, gain * 0.22, "sine", this.sfxBus, 46);
  }

  private heart(when: number) {
    this.tone(when, 0.22, 62, 0.32, "sine", this.sfxBus, 38);
    this.tone(when + 0.18, 0.18, 55, 0.2, "sine", this.sfxBus, 34);
  }

  private wind(when: number, duration: number, level: number) {
    if (!this.ctx || !this.ambBus) return;
    const src = this.noiseSource(when, duration);
    if (!src) return;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 420;
    filter.Q.value = 0.6;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.linearRampToValueAtTime(level, when + 1.2);
    gain.gain.setValueAtTime(level, when + Math.max(1.4, duration - 1.6));
    gain.gain.linearRampToValueAtTime(0.0001, when + duration);
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.value = 0.09;
    lfoGain.gain.value = 190;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start(when);
    lfo.stop(when + duration);
    this.track(lfo);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ambBus);
  }

  private score(when: number, from: number) {
    if (!this.ctx || !this.musicBus) return;
    // A slow, wordless tension score built from stacked procedural pads.
    const chords = [
      { at: 0, notes: [55, 82.41, 130.81], level: 0.2 },
      { at: 3, notes: [49, 73.42, 116.54], level: 0.22 },
      { at: 6, notes: [58.27, 87.31, 138.59], level: 0.24 },
      { at: 9, notes: [46.25, 69.3, 110], level: 0.28 },
      { at: 12, notes: [43.65, 65.41, 103.83], level: 0.3 },
      { at: 13.5, notes: [36.71, 55, 87.31], level: 0.34 },
      { at: 14.3, notes: [32.7, 49, 73.42], level: 0.3 },
    ];
    chords.forEach((chord, idx) => {
      if (chord.at + 3 < from) return;
      const start = when + Math.max(0, chord.at - from);
      const dur = idx === chords.length - 1 ? 2.4 : 3.7;
      chord.notes.forEach((freq, i) => {
        if (!this.ctx || !this.musicBus) return;
        const osc = this.ctx.createOscillator();
        osc.type = i === 0 ? "sine" : "triangle";
        osc.frequency.value = freq;
        osc.detune.value = (i - 1) * 4 + Math.sin(idx) * 3;
        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.linearRampToValueAtTime(chord.level / (i + 1.4), start + 0.9);
        gain.gain.setValueAtTime(chord.level / (i + 1.4), start + dur - 1);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
        const filter = this.ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = 460 + idx * 60;
        filter.Q.value = 0.9;
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicBus);
        osc.start(start);
        osc.stop(start + dur + 0.1);
        this.track(osc);
      });
      // pulse
      if (chord.at >= 1.5) {
        const pulseAt = when + Math.max(0, chord.at - from);
        this.tone(pulseAt, 0.5, 48, 0.2, "sine", this.musicBus, 34);
        this.noiseBurst(pulseAt, 0.5, 0.1, 900, "lowpass", 0.8, this.musicBus);
      }
    });
    // ticking tension in the last third
    for (let tt = Math.max(9.8, from); tt < 14.3; tt += 0.5) {
      const at = when + (tt - from);
      this.noiseBurst(at, 0.055, 0.09, 2600, "highpass", 1.2, this.musicBus);
    }
  }

  private playCue(cue: AudioCue, when: number, t0: number) {
    void t0;
    switch (cue.kind) {
      case "wind":
        this.noiseBurst(when, 2.5, 0.1, 320, "lowpass", 0.8, this.ambBus);
        break;
      case "siren":
        this.tone(when, 1.6, 420, 0.12, "sawtooth", this.sfxBus, 720);
        this.tone(when + 1.4, 1.6, 660, 0.1, "sawtooth", this.sfxBus, 410);
        break;
      case "whoosh":
        this.noiseBurst(when, 0.3, 0.35, 900, "bandpass", 0.8);
        break;
      case "beeps":
        [0, 0.18, 0.36].forEach((o, i) => this.tone(when + o, 0.1, i === 2 ? 660 : 520, 0.14, "square", this.ambBus));
        break;
      case "impact":
        this.tone(when, 0.5, 92, 0.34, "sine", this.sfxBus, 38);
        this.noiseBurst(when, 0.4, 0.2, 240, "lowpass", 0.7);
        break;
      case "growl":
        this.growl(when);
        break;
      case "bag":
        this.noiseBurst(when, 0.14, 0.32, 700, "bandpass", 0.7);
        this.tone(when, 0.18, 74, 0.26, "sine", this.sfxBus, 44);
        break;
      case "steps":
        for (let i = 0; i < 4; i++) this.step(when + i * 0.27, 0.34, 110);
        break;
      case "metal":
        this.metal(when, 0.5, 1);
        break;
      case "click":
        this.noiseBurst(when, 0.03, 0.16, 3200, "bandpass", 2);
        break;
      case "drone":
        this.tone(when, 2.2, 55, 0.1, "sine", this.ambBus);
        this.noiseBurst(when, 2.2, 0.05, 180, "lowpass", 0.9, this.ambBus);
        break;
      case "glass":
        for (let i = 0; i < 7; i++) this.noiseBurst(when + Math.random() * 0.14, 0.06 + Math.random() * 0.13, 0.12, 2200 + Math.random() * 3600, "highpass", 1.6);
        this.tone(when, 0.5, 1800, 0.1, "triangle", this.sfxBus, 700);
        break;
      case "alarm":
        for (let i = 0; i < 5; i++) {
          this.tone(when + i * 0.28, 0.11, i % 2 ? 560 : 720, 0.12, "square", this.ambBus);
        }
        break;
      case "ignition":
        this.noiseBurst(when, 0.3, 0.24, 300, "bandpass", 1.2);
        this.tone(when + 0.16, 0.8, 58, 0.2, "sawtooth", this.sfxBus, 96);
        this.tone(when + 0.2, 0.7, 33, 0.22, "sine", this.sfxBus, 46);
        break;
      case "heli":
        this.noiseBurst(when, 1.8, 0.15, 120, "lowpass", 0.9, this.ambBus);
        this.tone(when, 1.8, 28, 0.1, "sine", this.ambBus);
        break;
      case "screech":
        this.noiseBurst(when, 0.7, 0.18, 1900, "bandpass", 1.4);
        break;
      case "brake":
        this.noiseBurst(when, 0.5, 0.24, 2400, "highpass", 1);
        this.metal(when + 0.1, 0.3, 0.7);
        break;
      case "horde":
        this.noiseBurst(when, 2.2, 0.14, 300, "bandpass", 0.5, this.ambBus);
        this.growl(when + 0.4);
        break;
      case "scrape":
        for (let i = 0; i < 6; i++) this.noiseBurst(when + i * 0.09, 0.16, 0.14, 1400 + i * 190, "bandpass", 1.8);
        this.metal(when, 0.35, 1.2);
        break;
      case "heart":
        this.heart(when);
        break;
      case "rev":
        this.tone(when, 0.9, 46, 0.22, "sawtooth", this.sfxBus, 130);
        this.noiseBurst(when, 0.8, 0.12, 500, "bandpass", 0.8);
        break;
      case "heavyDoor":
        this.metal(when, 0.4, 0.7);
        break;
      case "electric":
        for (let i = 0; i < 4; i++) {
          this.noiseBurst(when + i * 0.13, 0.05, 0.1, 4200, "bandpass", 2);
        }
        break;
      case "eerie":
        this.tone(when, 1.4, 880, 0.07, "sine", this.ambBus, 830);
        this.tone(when + 0.1, 1.2, 1174, 0.045, "sine", this.ambBus, 1100);
        break;
      case "powerdown":
        this.tone(when, 0.8, 320, 0.16, "sawtooth", this.sfxBus, 38);
        this.noiseBurst(when, 0.3, 0.14, 1800, "highpass", 1);
        break;
      case "bigimpact":
        this.tone(when, 1.4, 72, 0.48, "sine", this.sfxBus, 26);
        this.noiseBurst(when, 0.7, 0.32, 420, "lowpass", 0.6);
        this.metal(when + 0.02, 0.52, 0.55);
        this.tone(when + 0.1, 1.2, 34, 0.3, "sine", this.sfxBus, 20);
        break;
      case "boom":
        this.tone(when, 1.8, 58, 0.4, "sine", this.sfxBus, 24);
        this.noiseBurst(when, 0.8, 0.2, 220, "lowpass", 0.5);
        break;
      default:
        break;
    }
  }

  private growl(when: number) {
    if (!this.ctx || !this.sfxBus) return;
    const osc = this.ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(82, when);
    osc.frequency.linearRampToValueAtTime(54, when + 0.9);
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 360;
    filter.Q.value = 5;
    const gain = this.env(when, 0.12, 0.3, 0.8, 0.13);
    if (!gain) return;
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.value = 11;
    lfoGain.gain.value = 14;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxBus);
    osc.start(when);
    osc.stop(when + 1.3);
    lfo.start(when);
    lfo.stop(when + 1.3);
    this.track(osc);
    this.track(lfo);
    this.noiseBurst(when, 0.9, 0.04, 240, "bandpass", 0.6);
  }
}
