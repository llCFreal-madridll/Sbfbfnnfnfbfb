export const FILM_DURATION = 15;
export const VIRTUAL_W = 1280;
export const VIRTUAL_H = 720;

export type MoodId = "action" | "suspense" | "mysterious" | "peaceful" | "sad" | "happy";
export type StyleId = "claude" | "minimal" | "sketch" | "cartoon" | "flat" | "cinematic" | "hybrid" | "experimental";

export type SceneKind =
  | "aerial"
  | "dive"
  | "screen"
  | "street"
  | "emerge"
  | "bag"
  | "zombie"
  | "whip"
  | "alley"
  | "door"
  | "hallway"
  | "shadow"
  | "horde"
  | "window"
  | "alarm"
  | "engine"
  | "chaos"
  | "drive"
  | "bridge"
  | "sacrifice"
  | "realization"
  | "obstacle"
  | "runback"
  | "escape"
  | "shelter"
  | "glass"
  | "whisper"
  | "blackout"
  | "title";

export type TransitionKind = "cut" | "whip" | "flash" | "impact" | "dissolve";

export interface CameraKey {
  at: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  fov: number;
}

export interface Shot {
  id: string;
  index: number;
  kind: SceneKind;
  start: number;
  end: number;
  scene: string;
  title: string;
  desc: string;
  mood: MoodId;
  transition: TransitionKind;
  camera: CameraKey[];
  focus: "wide" | "medium" | "close";
  motion?: string;
}

export interface StoryBeat {
  id: string;
  label: string;
  start: number;
  end: number;
  headline: string;
  summary: string;
}

export interface Dialogue {
  id: string;
  start: number;
  end: number;
  speaker: string;
  character?: "mara" | "eli" | "kai" | "narrator" | "broadcast";
  text: string;
  kind: "dialogue" | "narration";
}

export interface StylePreset {
  id: StyleId;
  name: string;
  tag: string;
  description: string;
  swatches: string[];
  lineWeight: number;
  grain: number;
  wobble: number;
  softness: number;
  detail: number;
}

export const STYLE_PRESETS: StylePreset[] = [
  {
    id: "claude",
    name: "Claude Code",
    tag: "SIGNATURE",
    description:
      "Warm editorial ink, coral signals and expressive geometric characters. Crisp code-drawn linework, confident camera language and thoughtful negative space.",
    swatches: ["#f0e8da", "#ff6a3d", "#8aa29e", "#12151a"],
    lineWeight: 2.2,
    grain: 0.5,
    wobble: 0.45,
    softness: 0.35,
    detail: 0.9,
  },
  {
    id: "cinematic",
    name: "Cinematic 2.5D",
    tag: "FILM",
    description:
      "Volumetric lighting, atmospheric haze and painterly silhouettes. A moodier, texture-led interpretation with soft depth separation.",
    swatches: ["#0b1118", "#1d3b44", "#ff8a4c", "#c9d6d6"],
    lineWeight: 0.5,
    grain: 0.8,
    wobble: 0.2,
    softness: 0.9,
    detail: 1,
  },
  {
    id: "minimal",
    name: "Minimal Geometric",
    tag: "GRAPHIC",
    description:
      "Reduced forms, single-weight rules and exact geometry. Characters become elegant shape systems on a bone-white field.",
    swatches: ["#edeae3", "#17181a", "#e0432e", "#a9ada8"],
    lineWeight: 1.7,
    grain: 0.12,
    wobble: 0.08,
    softness: 0.1,
    detail: 0.55,
  },
  {
    id: "sketch",
    name: "Graphite Sketch",
    tag: "HAND-DRAWN",
    description:
      "Loose pencil contours, visible construction and cross-hatched shadow. Hand-drawn wobble brings rawness to every frame.",
    swatches: ["#e6dfd0", "#33322e", "#b5503b", "#8d8779"],
    lineWeight: 1.3,
    grain: 1,
    wobble: 1,
    softness: 0.25,
    detail: 0.8,
  },
  {
    id: "cartoon",
    name: "Bold Cartoon",
    tag: "ILLUSTRATED",
    description:
      "Saturated flats, chunky ink outlines and springy character animation. Every shape reads instantly, even at a dead sprint.",
    swatches: ["#191b2f", "#ffbe3d", "#ee5a4e", "#4ec8bb"],
    lineWeight: 3.2,
    grain: 0.25,
    wobble: 0.7,
    softness: 0.2,
    detail: 0.8,
  },
  {
    id: "flat",
    name: "Flat Vector",
    tag: "VECTOR",
    description:
      "Clean compound shapes, muted urban color and diagrams-first composition. A restrained, highly legible motion graphic look.",
    swatches: ["#222b33", "#d9c8a9", "#d96c3d", "#8097a0"],
    lineWeight: 0.8,
    grain: 0.15,
    wobble: 0.25,
    softness: 0.4,
    detail: 0.7,
  },
  {
    id: "hybrid",
    name: "3D × 2D Hybrid",
    tag: "VOLUME",
    description:
      "Real projected primitives meet graphic characters. Specular light and soft contact shadows give the 2.5D rig tangible weight.",
    swatches: ["#101423", "#6d5bd0", "#ff8557", "#79d7d1"],
    lineWeight: 1,
    grain: 0.4,
    wobble: 0.35,
    softness: 0.75,
    detail: 0.95,
  },
  {
    id: "experimental",
    name: "Experimental Signal",
    tag: "PROCEDURAL",
    description:
      "Chromatic offsets, generative interference and hard signal color. Composition rules loosen while the story engine keeps timing locked.",
    swatches: ["#06050a", "#ff2e88", "#24f0d2", "#f3f25e"],
    lineWeight: 1.2,
    grain: 1,
    wobble: 0.9,
    softness: 0.3,
    detail: 0.75,
  },
];

export const MOODS: { id: MoodId; name: string; note: string; tint: string }[] = [
  { id: "action", name: "Action", note: "cold steel / signal orange", tint: "#ff6a3d" },
  { id: "suspense", name: "Suspense", note: "cyan shadow / sodium red", tint: "#e04a3a" },
  { id: "mysterious", name: "Mysterious", note: "deep violet / ember", tint: "#8f7ad6" },
  { id: "sad", name: "Sad", note: "desaturated blue", tint: "#6e8faa" },
  { id: "peaceful", name: "Peaceful", note: "soft sage / dawn", tint: "#a8c0a2" },
  { id: "happy", name: "Happy", note: "warm amber", tint: "#f0b45c" },
];

export const STORY_BEATS: StoryBeat[] = [
  {
    id: "falls",
    label: "01 · The world falls",
    start: 0,
    end: 1.5,
    headline: "A city disappears in a single breath",
    summary: "Aerial dive over gridlock and smoke. The emergency broadcast cuts through.",
  },
  {
    id: "outbreak",
    label: "02 · The outbreak",
    start: 1.5,
    end: 3,
    headline: "Something is already in the street",
    summary: "A dropped bag. A turning head. The first sprint.",
  },
  {
    id: "survivors",
    label: "03 · The survivors",
    start: 3,
    end: 4.5,
    headline: "Three strangers, one door",
    summary: "Mara, Eli and Kai reach the alley. The metal door barely closes.",
  },
  {
    id: "no-escape",
    label: "04 · No escape",
    start: 4.5,
    end: 6,
    headline: "The dark has company",
    summary: "Flashlight, covered furniture, a moving shadow. The hallway is not empty.",
  },
  {
    id: "getaway",
    label: "05 · The getaway",
    start: 6,
    end: 7.5,
    headline: "Out through the glass",
    summary: "A window bursts. An alarm wakes the block. The engine catches.",
  },
  {
    id: "chaos",
    label: "06 · City chaos",
    start: 7.5,
    end: 9,
    headline: "No street is clean",
    summary: "Overrun intersections, smoke, helicopters. The car weaves through the remains.",
  },
  {
    id: "sacrifice",
    label: "07 · The sacrifice",
    start: 9,
    end: 10.5,
    headline: "The bridge is blocked",
    summary: "Eli steps out to clear the way. The horde keeps coming.",
  },
  {
    id: "escape",
    label: "08 · The escape",
    start: 10.5,
    end: 12,
    headline: "Across, not clear",
    summary: "The obstacle moves. The car launches. The camera rolls into a side track.",
  },
  {
    id: "twist",
    label: "09 · The twist",
    start: 12,
    end: 13.5,
    headline: "A shelter that isn't safe",
    summary: "Flickering emergency lights. A silhouette behind glass. One whispered line.",
  },
  {
    id: "cliffhanger",
    label: "10 · Cliffhanger",
    start: 13.5,
    end: 15,
    headline: "The last fifteen seconds",
    summary: "Blackout. Metal impact. One final flash. The title lands.",
  },
];

const k = (at: number, x: number, y: number, z: number, yaw: number, pitch: number, roll: number, fov: number): CameraKey => ({
  at,
  x,
  y,
  z,
  yaw,
  pitch,
  roll,
  fov,
});

interface ShotSeed {
  kind: SceneKind;
  start: number;
  end: number;
  scene: string;
  title: string;
  desc: string;
  mood: MoodId;
  transition: TransitionKind;
  camera: [CameraKey, CameraKey, ...CameraKey[]];
  focus: Shot["focus"];
  motion?: string;
}

const seeds: ShotSeed[] = [
  {
    kind: "aerial",
    start: 0,
    end: 0.5,
    scene: "GLOBAL EMERGENCY",
    title: "City, extreme wide",
    desc: "Aerial view of a gridlocked city — blocks, traffic, fires and emergency strobes.",
    mood: "action",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 9, 10, -6, -58, 0, 54), k(1, 1.4, 4.2, 5.1, 3, -36, -4, 47)],
  },
  {
    kind: "dive",
    start: 0.5,
    end: 1,
    scene: "GLOBAL EMERGENCY",
    title: "Between the towers",
    desc: "Camera dives the canyon between two skyscrapers, debris crossing the lens.",
    mood: "action",
    transition: "whip",
    focus: "wide",
    camera: [k(0, 1.4, 4.2, 5.1, 8, -26, -7, 44), k(1, -0.6, 0.4, 1.2, -4, 3, 4, 62)],
  },
  {
    kind: "screen",
    start: 1,
    end: 1.5,
    scene: "GLOBAL EMERGENCY",
    title: "The broadcast",
    desc: "A giant civic screen floods the street with a red public warning.",
    mood: "suspense",
    transition: "flash",
    focus: "medium",
    camera: [k(0, 0, 0, 0, 6, 2, 0, 40), k(1, 0.25, 0.2, 0.5, -2, 3, 1, 37)],
  },
  {
    kind: "street",
    start: 1.5,
    end: 1.82,
    scene: "THE OUTBREAK",
    title: "Abandoned high street",
    desc: "A dead shopping street. Litter moves. Parked cars hide more than shadow.",
    mood: "suspense",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 0.4, 1, -8, 2, -1, 50), k(1, 1.1, 0.4, 1.4, 5, 3, 1, 46)],
  },
  {
    kind: "emerge",
    start: 1.82,
    end: 2.14,
    scene: "THE OUTBREAK",
    title: "Between parked cars",
    desc: "Figures rise from the gaps between vehicles; one turns its head toward us.",
    mood: "action",
    transition: "impact",
    focus: "medium",
    camera: [k(0, 0, 0, 0, 0, 0, 0, 46), k(1, -0.3, 0, 0.8, -7, 1, -1, 42)],
  },
  {
    kind: "bag",
    start: 2.14,
    end: 2.38,
    scene: "THE OUTBREAK",
    title: "The dropped bag",
    desc: "Low angle. A paper bag bursts across wet asphalt as feet scatter out of frame.",
    mood: "suspense",
    transition: "cut",
    focus: "close",
    camera: [k(0, 0, 0.2, 0.3, 0, -12, 0, 38), k(1, 0.1, 0, 0.6, 3, -8, -2, 40)],
  },
  {
    kind: "zombie",
    start: 2.38,
    end: 2.68,
    scene: "THE OUTBREAK",
    title: "Turn",
    desc: "Extreme close-up. A pale face snaps toward camera, jaw slack, eyes empty.",
    mood: "suspense",
    transition: "impact",
    focus: "close",
    camera: [k(0, 0, 0, 0.2, 9, 2, 0, 34), k(1, 0, 0, 0.4, 0, 1, 1, 38)],
  },
  {
    kind: "whip",
    start: 2.68,
    end: 3,
    scene: "THE OUTBREAK",
    title: "Whip pan",
    desc: "Motion-blasted pan from the dead face to a group running for their lives.",
    mood: "action",
    transition: "whip",
    focus: "medium",
    camera: [k(0, 1, 0, 0.5, 44, 2, 0, 48), k(1, -1, 0, 1.2, -32, 3, -3, 54)],
  },
  {
    kind: "alley",
    start: 3,
    end: 3.72,
    scene: "THE SURVIVORS",
    title: "Alley sprint",
    desc: "Three survivors race between brick walls. Camera tracks beside them.",
    mood: "action",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 0.6, 1.4, 0, 3, 0, 52), k(1, 0.8, 0.4, 1.1, 4, 4, 2, 47)],
  },
  {
    kind: "door",
    start: 3.72,
    end: 4.5,
    scene: "THE SURVIVORS",
    title: "The metal door",
    desc: "Eli shoulders a fire door shut. Hands reach through. The latch catches.",
    mood: "action",
    transition: "impact",
    focus: "medium",
    camera: [k(0, 0, 0.2, 0.8, -4, 0, -1, 44), k(0.6, 0.2, 0.2, 0.4, 0, 0, 0, 48), k(1, 0, 0.1, 0.2, 2, 1, 0, 52)],
    motion: "door slam",
  },
  {
    kind: "hallway",
    start: 4.5,
    end: 5.05,
    scene: "NO ESCAPE",
    title: "Inside / flashlight",
    desc: "A cold beam discovers abandoned furniture under dust sheets.",
    mood: "mysterious",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 0.4, 1, 0, 1, 0, 50), k(1, 0.5, 0.3, 0.8, 2, 2, 1, 46)],
  },
  {
    kind: "shadow",
    start: 5.05,
    end: 5.4,
    scene: "NO ESCAPE",
    title: "Something behind",
    desc: "The flashlight finds a shadow with too many joints. It moves against the beam.",
    mood: "mysterious",
    transition: "cut",
    focus: "medium",
    camera: [k(0, 0, 0, 0.2, 0, 0, 0, 40), k(1, -0.4, 0.2, 0.5, 6, 1, 2, 43)],
  },
  {
    kind: "horde",
    start: 5.4,
    end: 6,
    scene: "NO ESCAPE",
    title: "End of the hall",
    desc: "A shape fills the far doorway. The camera pulls back fast as everyone turns.",
    mood: "suspense",
    transition: "impact",
    focus: "medium",
    camera: [k(0, 0, 0.2, 1.8, 0, 0, 0, 40), k(0.72, 0, 0.1, 1.5, -3, 0, 0, 44), k(1, 0, 0, 0.2, 7, -1, 3, 62)],
    motion: "fast pullback",
  },
  {
    kind: "window",
    start: 6,
    end: 6.32,
    scene: "THE GETAWAY",
    title: "Through the glass",
    desc: "Three bodies burst through a window, shards spinning toward the lens.",
    mood: "action",
    transition: "impact",
    focus: "wide",
    camera: [k(0, 0, 0.6, 1.6, 0, 2, 0, 50), k(1, 0.3, 0.2, 0.8, 2, 4, -2, 56)],
  },
  {
    kind: "alarm",
    start: 6.32,
    end: 6.92,
    scene: "THE GETAWAY",
    title: "Car alarm",
    desc: "An abandoned sedan wakes in amber strobes. Kai climbs in. Mara waves him on.",
    mood: "action",
    transition: "cut",
    focus: "medium",
    camera: [k(0, 0.6, 0.4, 1.2, -5, 2, 1, 46), k(1, -0.4, 0.3, 0.8, 6, 1, -1, 42)],
  },
  {
    kind: "engine",
    start: 6.92,
    end: 7.5,
    scene: "THE GETAWAY",
    title: "Ignition",
    desc: "Macro on the dash. Needle stabs. Warning lights die. Overhead cam returns.",
    mood: "action",
    transition: "whip",
    focus: "close",
    camera: [k(0, 0, 0, 0.1, 0, 0, 0, 32), k(1, 0.2, 0.1, 0.4, 8, 2, 2, 36)],
  },
  {
    kind: "chaos",
    start: 7.5,
    end: 8.15,
    scene: "CITY CHAOS",
    title: "Overrun grid",
    desc: "Top-down. Streams of infected pour through intersections; smoke bends in the wind.",
    mood: "action",
    transition: "flash",
    focus: "wide",
    camera: [k(0, 0, 8, 9, -12, -62, 4, 58), k(1, 2, 5, 6, 8, -42, -5, 50)],
  },
  {
    kind: "drive",
    start: 8.15,
    end: 9,
    scene: "CITY CHAOS",
    title: "Weave",
    desc: "The survivors' car carves between wrecks, taillights smearing through the rain.",
    mood: "action",
    transition: "whip",
    focus: "medium",
    camera: [k(0, -1.2, 0.3, 1.4, -14, 1, -2, 48), k(0.55, 0, 0.2, 0.9, 4, 2, 3, 52), k(1, 1.2, 0.1, 0.5, 12, 0, -2, 44)],
  },
  {
    kind: "bridge",
    start: 9,
    end: 9.42,
    scene: "THE SACRIFICE",
    title: "Blocked",
    desc: "The bridge is a dead end. A fallen barrier. A horde in the rear light.",
    mood: "suspense",
    transition: "impact",
    focus: "wide",
    camera: [k(0, 0, 1.2, 2.4, 0, -2, 0, 50), k(1, -0.6, 0.8, 1.7, -4, 0, 1, 47)],
  },
  {
    kind: "sacrifice",
    start: 9.42,
    end: 10.05,
    scene: "THE SACRIFICE",
    title: "Eli steps out",
    desc: "He crosses into the headlights and hauls at the fallen obstacle.",
    mood: "suspense",
    transition: "cut",
    focus: "medium",
    camera: [k(0, 0.4, 0.4, 1.2, -6, 0, 1, 42), k(1, -0.4, 0.3, 0.8, 7, 1, -1, 45)],
  },
  {
    kind: "realization",
    start: 10.05,
    end: 10.5,
    scene: "THE SACRIFICE",
    title: "Running out of time",
    desc: "Eli realizes the horde is behind him. A flare burns in each eye.",
    mood: "suspense",
    transition: "impact",
    focus: "close",
    camera: [k(0, 0, 0, 0.1, 0, 0, 0, 32), k(1, 0, 0, 0.25, 5, 1, 1, 35)],
  },
  {
    kind: "obstacle",
    start: 10.5,
    end: 10.95,
    scene: "THE ESCAPE",
    title: "Clear",
    desc: "Hands, grit, leverage. The barrier grinds aside in a spray of sparks.",
    mood: "action",
    transition: "cut",
    focus: "close",
    camera: [k(0, 0, 0.2, 0.3, -2, -4, 0, 38), k(1, 0.3, 0.1, 0.5, 5, 2, -2, 40)],
  },
  {
    kind: "runback",
    start: 10.95,
    end: 11.42,
    scene: "THE ESCAPE",
    title: "Run",
    desc: "Eli sprints for the door. The horde fills the street behind him.",
    mood: "action",
    transition: "whip",
    focus: "medium",
    camera: [k(0, 0.8, 0.3, 1.2, -12, 2, -2, 48), k(1, -0.8, 0.2, 0.7, 10, 3, 2, 52)],
  },
  {
    kind: "escape",
    start: 11.42,
    end: 12,
    scene: "THE ESCAPE",
    title: "Across",
    desc: "Overhead to side. The car accelerates over the bridge as the infected fall behind.",
    mood: "action",
    transition: "impact",
    focus: "wide",
    camera: [k(0, 0, 3.2, 4.2, 0, -44, 0, 54), k(0.6, 0.6, 1.4, 2.2, -16, -22, -6, 48), k(1, 1.1, 0.4, 1.1, -24, -4, -9, 42)],
  },
  {
    kind: "shelter",
    start: 12,
    end: 12.62,
    scene: "THE TWIST",
    title: "Underground / level 3",
    desc: "Bare concrete, one emergency lamp, three people breathing too loudly.",
    mood: "mysterious",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 0.3, 1.2, -4, 1, 0, 50), k(1, 0.6, 0.2, 0.7, 4, 2, 1, 46)],
  },
  {
    kind: "glass",
    start: 12.62,
    end: 13.1,
    scene: "THE TWIST",
    title: "Behind the glass",
    desc: "The lamp stutters. In the glass door, a fifth silhouette resolves.",
    mood: "mysterious",
    transition: "flash",
    focus: "medium",
    camera: [k(0, 0, 0.2, 0.5, 4, 0, 1, 41), k(1, -0.3, 0.1, 0.3, -3, 0, 0, 44)],
  },
  {
    kind: "whisper",
    start: 13.1,
    end: 13.5,
    scene: "THE TWIST",
    title: "We're not alone",
    desc: "A close whisper, lit only by a dying red emergency lamp.",
    mood: "mysterious",
    transition: "impact",
    focus: "close",
    camera: [k(0, 0, 0, 0.1, 0, 0, 0, 33), k(1, 0, 0, 0.2, 4, 1, 1, 36)],
  },
  {
    kind: "blackout",
    start: 13.5,
    end: 14.02,
    scene: "CLIFFHANGER",
    title: "Blackout / impact",
    desc: "The power dies. Metal tears in the dark. One last emergency flash.",
    mood: "suspense",
    transition: "cut",
    focus: "wide",
    camera: [k(0, 0, 0.2, 0.4, 0, 0, 0, 46), k(0.55, 0, 0, 0.2, -6, 0, 4, 58), k(1, 0, 0, 0.1, 0, 0, 0, 40)],
  },
  {
    kind: "title",
    start: 14.02,
    end: 15,
    scene: "CLIFFHANGER",
    title: "Title card",
    desc: "One final flare. The title lands with the last sub-bass hit.",
    mood: "action",
    transition: "flash",
    focus: "wide",
    camera: [k(0, 0, 0.2, 0.5, 0, 0, 0, 40), k(1, 0.2, 0.1, 0.2, 2, 0, 0, 37)],
  },
];

export const SHOTS: Shot[] = seeds.map((seed, index) => ({
  ...seed,
  id: `SH-${String(index + 1).padStart(2, "0")}`,
  index,
  camera: seed.camera,
}));

export const DIALOGUE: Dialogue[] = [
  {
    id: "d1",
    start: 0.12,
    end: 0.92,
    speaker: "NARRATOR",
    character: "narrator",
    text: "At 06:12, the city stopped answering.",
    kind: "narration",
  },
  {
    id: "d2",
    start: 2.72,
    end: 3.34,
    speaker: "MARA",
    character: "mara",
    text: "Leave it. Run!",
    kind: "dialogue",
  },
  {
    id: "d3",
    start: 3.82,
    end: 4.34,
    speaker: "ELI",
    character: "eli",
    text: "The door — now!",
    kind: "dialogue",
  },
  {
    id: "d4",
    start: 5.5,
    end: 5.94,
    speaker: "MARA",
    character: "mara",
    text: "Don't stop. Don't look back.",
    kind: "dialogue",
  },
  {
    id: "d5",
    start: 6.78,
    end: 7.22,
    speaker: "KAI",
    character: "kai",
    text: "It's running. Get in!",
    kind: "dialogue",
  },
  {
    id: "d6",
    start: 9.58,
    end: 10.06,
    speaker: "ELI",
    character: "eli",
    text: "I can move it.",
    kind: "dialogue",
  },
  {
    id: "d7",
    start: 10.72,
    end: 11.16,
    speaker: "MARA",
    character: "mara",
    text: "Eli, come on!",
    kind: "dialogue",
  },
  {
    id: "d8",
    start: 13.1,
    end: 13.5,
    speaker: "MARA",
    character: "mara",
    text: "We're not alone.",
    kind: "dialogue",
  },
];

export interface CastMember {
  key: "mara" | "eli" | "kai";
  name: string;
  role: string;
  age: string;
  note: string;
  hair: string;
  hairStyle: "curls" | "crop" | "beanie";
  skin: string;
  coat: string;
  shirt: string;
  pants: string;
  accent: string;
  height: number;
}

export const CAST: CastMember[] = [
  {
    key: "mara",
    name: "Mara Voss",
    role: "The protector",
    age: "29",
    note: "Improviser. Never drops the bag.",
    hair: "#1c1718",
    hairStyle: "curls",
    skin: "#b97850",
    coat: "#c8793f",
    shirt: "#e7ddc8",
    pants: "#242a2c",
    accent: "#ff6a3d",
    height: 1,
  },
  {
    key: "eli",
    name: "Eli Okafor",
    role: "The fixer",
    age: "31",
    note: "Runs toward the problem.",
    hair: "#151210",
    hairStyle: "crop",
    skin: "#70452f",
    coat: "#d9cfb8",
    shirt: "#3e5d5c",
    pants: "#1b2224",
    accent: "#ffb98c",
    height: 1.06,
  },
  {
    key: "kai",
    name: "Kai Mercer",
    role: "The kid",
    age: "17",
    note: "Fastest of the three. Still counting exits.",
    hair: "#5b3122",
    hairStyle: "beanie",
    skin: "#d7a27c",
    coat: "#376b68",
    shirt: "#e9e3d2",
    pants: "#2b3036",
    accent: "#d8453a",
    height: 0.9,
  },
];

export type CueCategory = "ambience" | "foley" | "impact" | "engine" | "music" | "alert";

export interface AudioCue {
  id: string;
  t: number;
  category: CueCategory;
  label: string;
  kind: string;
  gain: number;
}

export const AUDIO_CUES: AudioCue[] = [
  { id: "a1", t: 0.02, category: "ambience", label: "City bed / wind", kind: "wind", gain: 0.5 },
  { id: "a2", t: 0.06, category: "alert", label: "Emergency siren", kind: "siren", gain: 0.3 },
  { id: "a3", t: 0.5, category: "impact", label: "Dive rush", kind: "whoosh", gain: 0.55 },
  { id: "a4", t: 1.02, category: "alert", label: "Broadcast tone", kind: "beeps", gain: 0.28 },
  { id: "a5", t: 1.5, category: "impact", label: "Cut hit / street", kind: "impact", gain: 0.42 },
  { id: "a6", t: 1.82, category: "foley", label: "Shuffling dead", kind: "growl", gain: 0.3 },
  { id: "a7", t: 2.14, category: "foley", label: "Paper bag / impact", kind: "bag", gain: 0.5 },
  { id: "a8", t: 2.68, category: "impact", label: "Whip pan", kind: "whoosh", gain: 0.45 },
  { id: "a9", t: 3.02, category: "foley", label: "Footsteps ×3", kind: "steps", gain: 0.32 },
  { id: "a10", t: 4.18, category: "foley", label: "Metal door slam", kind: "metal", gain: 0.6 },
  { id: "a11", t: 4.52, category: "foley", label: "Flashlight click", kind: "click", gain: 0.25 },
  { id: "a12", t: 5.1, category: "ambience", label: "Interior drone", kind: "drone", gain: 0.3 },
  { id: "a13", t: 5.42, category: "impact", label: "Pullback hit", kind: "impact", gain: 0.5 },
  { id: "a14", t: 6.02, category: "foley", label: "Glass shatter", kind: "glass", gain: 0.55 },
  { id: "a15", t: 6.32, category: "alert", label: "Car alarm", kind: "alarm", gain: 0.3 },
  { id: "a16", t: 6.94, category: "engine", label: "Ignition / catch", kind: "ignition", gain: 0.55 },
  { id: "a17", t: 7.52, category: "ambience", label: "Helicopter / smoke", kind: "heli", gain: 0.3 },
  { id: "a18", t: 8.16, category: "engine", label: "Tyre slip", kind: "screech", gain: 0.35 },
  { id: "a19", t: 9.02, category: "foley", label: "Brake / barrier", kind: "brake", gain: 0.45 },
  { id: "a20", t: 9.9, category: "ambience", label: "Horde swell", kind: "horde", gain: 0.34 },
  { id: "a21", t: 10.52, category: "foley", label: "Barrier scrape", kind: "scrape", gain: 0.5 },
  { id: "a22", t: 11.14, category: "foley", label: "Run / heartbeat", kind: "heart", gain: 0.35 },
  { id: "a23", t: 11.44, category: "engine", label: "Acceleration", kind: "rev", gain: 0.5 },
  { id: "a24", t: 12.03, category: "foley", label: "Bunker door", kind: "heavyDoor", gain: 0.4 },
  { id: "a25", t: 12.72, category: "ambience", label: "Light flicker", kind: "electric", gain: 0.25 },
  { id: "a26", t: 13.1, category: "ambience", label: "Eerie tone", kind: "eerie", gain: 0.28 },
  { id: "a27", t: 13.52, category: "foley", label: "Power down", kind: "powerdown", gain: 0.4 },
  { id: "a28", t: 14.02, category: "impact", label: "Metallic impact", kind: "bigimpact", gain: 0.85 },
  { id: "a29", t: 14.38, category: "impact", label: "Title sub-boom", kind: "boom", gain: 0.75 },
];

export function formatTC(seconds: number, fps = 30): string {
  const total = Math.max(0, seconds);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = Math.floor(total % 60);
  const f = Math.floor((total % 1) * fps);
  return [h, m, s, f].map((v) => String(v).padStart(2, "0")).join(":");
}

export function formatShort(seconds: number): string {
  return `${seconds.toFixed(2)}s`;
}

export function shotAt(time: number): Shot {
  return (
    SHOTS.find((shot) => time >= shot.start && time < shot.end) ??
    SHOTS[SHOTS.length - 1]
  );
}

export function beatAt(time: number): StoryBeat {
  return STORY_BEATS.find((beat) => time >= beat.start && time < beat.end) ?? STORY_BEATS[STORY_BEATS.length - 1];
}

export function activeDialogue(time: number): Dialogue | undefined {
  return DIALOGUE.find((line) => time >= line.start && time <= line.end);
}
